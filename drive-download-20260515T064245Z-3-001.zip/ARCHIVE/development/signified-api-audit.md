# Signified API Audit — Organized by Feature

> Generated 2026-04-04. MVP is text-only in Field. Palette still supports text, image, video, music references.
> APIs marked with * are already configured/integrated in signified2 or signified3.

**Priority:** P1 = critical for launch, P2 = high value, P3 = nice to have, P4 = post-MVP/stretch

---

## PALETTE SEARCH

The core reference library. Users search across external sources to collect influences and research material (text, image, video, music).

| API | Priority | Auth Type | General Data (no account needed) | Account-Specific Data (signed in) | Notes | Comments |
|-----|----------|-----------|----------------------------------|-----------------------------------|-------|----------|
| **Open Library*** | P1 | None | Books, authors, editions, subjects, covers, full text (some) | N/A | Already integrated | |
| **Wikipedia*** | P1 | None | Articles, summaries, images, categories, cross-references | N/A | Already integrated | |
| **Met Museum*** | P1 | None | 470k+ objects, high-res images, artist info, medium, classification, date, geography, tags | N/A | Already integrated | |
| **MusicBrainz*** | P1 | None | Artist/release/recording search, credits, labels, genres, cover art | N/A | Already integrated | |
| **Wikimedia Commons*** | P1 | None | Freely licensed images, audio, video, documents | N/A | Already integrated | |
| **Wikidata*** | P1 | None | Structured entity data, relationships, properties, cross-references | N/A | Already integrated | |
| **Internet Archive*** | P1 | None | Full films, audio, books, magazines, TV clips, Wayback Machine | N/A | Already integrated | |
| **TMDB*** | P1 | API Key | Search movies/shows/people, full cast/crew, images, trailers, reviews, keywords, similar films, discover by genre/year/rating, trending, collections | Rated movies/shows, watchlist, favorites, custom lists | Massive film/TV metadata — essential for any visual art palette | |
| **Spotify*** | P1 | OAuth2 | Search artists/tracks/albums, audio features (tempo/energy/valence), genre seeds, new releases, related artists | Top artists/tracks, saved albums, playlists, listening history, recently played, followed artists | Best music search + rich audio metadata | |
| **YouTube*** | P1 | OAuth2 | Search videos/channels/playlists, trending, categories, captions/transcripts, video metadata | Subscriptions, liked videos, playlists, watch history, own uploads | Video essays, performances, lectures, music videos, documentaries | |
| **Genius*** | P2 | OAuth2 | Search songs, full lyrics, crowdsourced annotations/meaning, artist bios, album art | User's own annotations, followed artists | Lyrics as text references, meaning analysis | |
| **Flickr*** | P2 | API Key | Search photos, explore/interestingness, museum commons, tags, EXIF data, geo-tagged photos | Favorites, photostream, albums, groups | Photography — strong commons/museum collection | |
| **Are.na*** | P2 | OAuth2 | Search channels/blocks/users, public channels, connected blocks | Own channels, saved blocks, connections, followers | Curated reference boards — very aligned with Palette's purpose | |
| **Discogs*** | P2 | API Key | Search releases/artists/labels, full discographies, credits, genre/style taxonomy, marketplace | Collection (owned records), wantlist | Physical music metadata, vinyl culture | |
| **Rijksmuseum** | P2 | API Key | 700k+ artworks, high-res images, colors, materials, object types, artists, periods | N/A | Dutch masters + major European art | |
| **Art Institute of Chicago** | P2 | None | 100k+ artworks, high-res images, artists, styles, classifications, color data, similar artworks | N/A | Free, excellent API, includes color-based similarity | |
| **Unsplash** | P2 | API Key | Search photos, curated collections, topics, color search, similar photos | Liked photos, collections | High-quality photography, color-based search | |
| **Google Books** | P2 | API Key | Search books, previews, metadata, subjects, full text snippets | Bookshelves, annotations | Broader book coverage than Open Library, text snippets useful | |
| **Europeana** | P2 | API Key | 50M+ cultural heritage objects from European museums — images, text, sound, video | N/A | Massive cross-cultural, multi-museum collection | |
| **Project Gutenberg** | P2 | None | 70k+ free full-text ebooks, metadata | N/A | Classic literature — full texts available | |
| **Last.fm*** | P2 | API Key | Global charts, artist info/bio/tags, similar artists, top tags, tag-based search | Top artists/albums/tracks (all time + time ranges), scrobbles, loved tracks | Deep music discovery via tags + similar artists | |
| **SoundCloud*** | P2 | OAuth2 | Search tracks/users/playlists, trending, genre charts | Liked tracks, playlists, followed artists, reposts | Indie/underground/experimental music | |
| **Pinterest*** | P3 | OAuth2 | Search pins, visual similar pins, trending | Boards, saved pins, followers | Visual references — but limited API | |
| **Artsy** | P3 | OAuth2 | Search artworks/artists/shows/fairs, genes (art categories), similar artworks, auction results | Followed artists, saved artworks | Contemporary art discovery | |
| **Reddit** | P3 | OAuth2 | Search posts/comments/subreddits, wikis, trending, hot/top | Saved posts, upvoted, subscriptions | Niche community discourse and references | |
| **Vimeo** | P3 | OAuth2 | Search videos, categories, channels, staff picks | Liked videos, watch later, own uploads | Art films, short films, experimental video | |
| **Podcast Index** | P3 | API Key | Search podcasts/episodes, trending, categories, some transcripts | N/A | Podcast episodes as text/audio references | |
| **Bluesky** | P3 | App Password | Search posts/users, custom feeds, trending | Posts, likes, reposts, follows, lists | Current creative discourse | |
| **OpenAlex** | P3 | None | 250M+ academic works, authors, institutions, concepts, topics | N/A | Academic/theory research — philosophy, art theory, criticism | |
| **CrossRef** | P4 | None | Academic papers, citations, DOIs, journal metadata | N/A | Scholarly references — more niche | |
| **Cooper Hewitt** | P4 | API Key | 200k+ design objects, exhibitions, people, types, periods, colors | N/A | Design history | |
| **Harvard Art Museums** | P4 | API Key | 250k+ objects, color data, classification, technique, culture | N/A | Fine art, includes color-based data | |
| **DeviantArt** | P4 | OAuth2 | Browse/search deviations, popular, tags, categories | Favorites, gallery, collections | Digital/illustration art — community skews young | |
| **Tumblr** | P4 | OAuth2 | Search tags, trending, blog content | Liked posts, following, drafts | Art/culture micro-blogs | |

---

## PALETTE RECOMMENDATIONS

Suggesting related or new references based on user's connected accounts and existing palette. Pulls from account data to surface things the user hasn't found yet.

| API | Priority | Auth Type | General Data (no account needed) | Account-Specific Data (signed in) | Notes | Comments |
|-----|----------|-----------|----------------------------------|-----------------------------------|-------|----------|
| **Spotify*** | P1 | OAuth2 | Recommendations engine (seed artists/tracks/genres + tuneable audio features), related artists, new releases | Top artists/tracks (short/medium/long term), recently played, saved library, followed artists | Best recommendation engine of any API — can seed from user taste + palette items | |
| **TMDB*** | P1 | API Key | Similar movies/shows, discover endpoint (filter by genre/year/rating/keyword), trending, popular | Rated items, watchlist, favorites | Discover endpoint is extremely powerful for filtered recommendations | |
| **Last.fm*** | P2 | API Key | Similar artists, top tags, tag-based discovery, global charts | Top artists/albums/tracks across time periods, scrobble history | Long-term listening patterns reveal deep taste — better signal than Spotify for some users | |
| **Are.na*** | P2 | OAuth2 | Connected blocks (shows what else is linked to same concepts) | User's channels, blocks, connections | Connection graph is unique — "people who saved X also saved Y" | |
| **Art Institute of Chicago** | P2 | None | Similar artworks feature, style/classification-based browsing | N/A | Built-in similarity — can recommend art based on palette items | |
| **YouTube*** | P2 | OAuth2 | Related videos, trending by category | Subscriptions, liked videos, watch history | Related videos algo surfaces adjacent content | |
| **Trakt*** | P2 | OAuth2 | Recommendations, anticipated, trending/popular | Watch history, ratings, watchlist, stats (top genres, hours watched) | Richer viewing stats than TMDB — better for taste profiling | |
| **Discogs*** | P3 | API Key | Similar releases, label catalogs, style/genre browsing | Collection, wantlist | "If you own this record, explore this label" | |
| **Rijksmuseum** | P3 | API Key | Browse by period, material, type, artist — faceted discovery | N/A | Period/material-based art recs | |
| **Pinterest*** | P3 | OAuth2 | Visual similar pins | Boards, saved pins | Visual similarity engine — "more like this" | |
| **Flickr*** | P3 | API Key | Interestingness algorithm, similar photos | Favorites | Curated photography discovery | |
| **Unsplash** | P3 | API Key | Similar photos, curated topics, trending | Liked photos, collections | Photo similarity + editorial curation | |
| **SoundCloud*** | P3 | OAuth2 | Related tracks, trending | Likes, playlists, follows | Indie music recs from likes/follows | |
| **Genius*** | P3 | OAuth2 | Related songs via annotations, song relationships | Followed artists | Lyrical/thematic connections between songs | |
| **Google Books** | P3 | API Key | Related books by subject/author | Bookshelves | "Readers of X also read Y" | |
| **Bluesky** | P4 | App Password | Custom algorithmic feeds (community-curated) | Follows, likes | Creative community feeds as discovery | |
| **Reddit** | P4 | OAuth2 | Subreddit-based discovery, related subreddits | Saved, subscriptions | Niche community recs | |

---

## AUDIENCE FINDER

Matching a user's Signified Objects (title, medium, description, audience) to submission opportunities, exhibitions, festivals, grants, venues, and communities.

| API | Priority | Auth Type | General Data (no account needed) | Account-Specific Data (signed in) | Notes | Comments |
|-----|----------|-----------|----------------------------------|-----------------------------------|-------|----------|
| **Eventbrite*** | P1 | API Key | Search events by keyword/location/category/date, venues, formats, categories | Owned events, orders, organizations | Exhibitions, open mics, art walks, performances, workshops — searchable by location + category | |
| **Google Maps / Places** | P1 | API Key | Venue search (galleries, theaters, bookstores, performance spaces), ratings, hours, contact info, photos, nearby search | N/A | "Find galleries near me" or "theaters in Brooklyn" — essential for location-based audience discovery | |
| **Artsy** | P2 | OAuth2 | Shows, fairs, galleries (with locations and dates), artists' exhibition histories | Followed artists, inquiry history | Gallery and fair database — match art objects to appropriate venues | |
| **TMDB*** | P2 | API Key | Production companies, festival info (some), genre/keyword taxonomy | N/A | Festival matching for film — use genres/keywords to find relevant festivals | |
| **Submittable*** | P2 | OAuth2 (org-only) | Discover page (public submission opportunities) | Submissions, forms (org accounts only) | Limited API access — Discover page is main value | |
| **Meetup** | P2 | OAuth2 | Search groups/events by topic/location, categories | RSVPs, group memberships | Creative meetups, writing groups, open studios, workshops | |
| **YouTube*** | P2 | OAuth2 | Channel info, about pages, submission guidelines (via descriptions) | N/A | Channels accepting submissions, content partnerships | |
| **Bluesky** | P3 | App Password | Search posts/users, community feeds | Follows, posts | Creative community discovery — find who's looking for collaborators or submissions | |
| **Reddit** | P3 | OAuth2 | Subreddit search, post search | Subscriptions | r/filmmakers, r/screenwriting, r/poetry etc. — communities that share/critique work | |
| **Mastodon** | P3 | OAuth2 | Search hashtags/accounts, local timelines | Follows, bookmarks | Art-focused instances, creative communities | |
| **LinkedIn** | P4 | OAuth2 (restricted) | Company search (limited), job listings | Profile, connections | Creative industry jobs, gallery connections — API very restricted | |
| **Foundation Directory (Candid)** | P4 | API Key (paid) | Grant opportunities, foundations, arts funding data | N/A | Grant discovery for artists — paid service | |

**No-API platforms (link-out only):**
- **FilmFreeway** — Film festival submissions (P1 for filmmakers, no API)
- **CaFÉ (callforentry.org)** — Visual art calls, residencies, grants (P1 for visual artists, no API)
- **Duotrope** — Literary market listings, acceptance rates (P2 for writers, paywall, no API)
- **Wooloo** — Art opportunities (P3, no API)

---

## COMPASS CONTEXT ENRICHMENT

Any connected service can feed signal into the Compass system prompt, giving the AI a richer understanding of the artist's taste, influences, and creative identity.

| API | Priority | Auth Type | General Data (no account needed) | Account-Specific Data (signed in) | Notes | Comments |
|-----|----------|-----------|----------------------------------|-----------------------------------|-------|----------|
| **Spotify*** | P1 | OAuth2 | Audio features (energy, valence, tempo, danceability per track) | Top artists/tracks (time ranges), listening history, saved library, followed artists | Musical taste profile — genres, moods, evolution over time. Compass can reference "your affinity for minor-key ambient" etc. | |
| **Are.na*** | P1 | OAuth2 | Channel descriptions, block content | User's channels (titled research boards) | Research boards reveal creative thinking structure — Compass sees how user organizes ideas | |
| **Last.fm*** | P2 | API Key | Artist bios, tags | Scrobble history (years of data), top artists by period | Longest time-range taste data available — shows evolution of influences | |
| **TMDB*** | P2 | API Key | Film/show metadata, themes, keywords | Rated items, watchlist | Viewing taste as creative influence signal | |
| **Trakt*** | P2 | OAuth2 | N/A | Full watch history, ratings, stats (top genres, hours watched) | Richer viewing statistics than TMDB — time investment signals | |
| **Notion*** | P2 | OAuth2 | N/A | Pages, databases (user's research/notes) | Import user's organized thinking directly — outlines, research notes, project plans | |
| **YouTube*** | P2 | OAuth2 | Video transcripts/captions | Subscriptions, liked videos | What channels they follow reveals intellectual/creative interests | |
| **Genius*** | P3 | OAuth2 | Lyrics, annotations | Followed artists, own annotations | Lyrical interests, what meanings the user engages with | |
| **Discogs*** | P3 | API Key | N/A | Record collection | Physical media collection as cultural signal | |
| **Reddit** | P3 | OAuth2 | N/A | Subscriptions, saved posts | Community memberships reveal niche interests | |
| **Bluesky** | P4 | App Password | N/A | Posts, likes | Public creative identity and discourse | |
| **Google Books** | P4 | API Key | N/A | Bookshelves, annotations | Reading taste and highlighted passages | |

---

## CONFIGURE ART OBJECT (auto-fill metadata)

Helping users classify their work with accurate metadata — medium, genre, audience, influences. APIs that provide taxonomies and classification systems.

| API | Priority | Auth Type | General Data (no account needed) | Account-Specific Data (signed in) | Notes | Comments |
|-----|----------|-----------|----------------------------------|-----------------------------------|-------|----------|
| **Anthropic Claude*** | P1 | API Key | Text analysis, classification, entity extraction, summarization | N/A | Already used — auto-fill from content analysis | |
| **TMDB*** | P2 | API Key | Genre taxonomy, keyword system, production metadata | N/A | Genre/keyword lists useful for classifying film/video art objects | |
| **Met Museum*** | P2 | None | Medium vocabulary (oil on canvas, gelatin silver print, etc.), classification system, department categories | N/A | Art medium taxonomy — the canonical vocabulary for describing physical art | |
| **MusicBrainz*** | P2 | None | Release types, recording relationships, genre tags | N/A | Music classification system — types, formats, relationships | |
| **Discogs*** | P3 | API Key | Genre/style taxonomy (very detailed for music), format types | N/A | Most granular music genre/style classification available | |
| **Wikidata*** | P3 | None | Structured entity properties, occupation types, genre classifications | N/A | Standardized vocabulary for any creative domain | |
| **Artsy** | P3 | OAuth2 | "Genes" (art categories like "Abstract Expressionism", "Found Objects", "Feminist Art") | N/A | Contemporary art categorization — nuanced and modern | |
| **Rijksmuseum** | P4 | API Key | Material types, technique vocabulary, object type classification | N/A | European art classification — overlaps with Met but adds Dutch-specific terms | |

---

## FIELD (text-only MVP)

With Field limited to text, these APIs support the writing/editing experience.

| API | Priority | Auth Type | General Data (no account needed) | Account-Specific Data (signed in) | Notes | Comments |
|-----|----------|-----------|----------------------------------|-----------------------------------|-------|----------|
| **Anthropic Claude*** | P1 | API Key | Text generation, editing, analysis, feedback, formatting | N/A | Already integrated — Lab tools (Machine, Dialog, Prompt) all serve Field | |
| **Google Drive** | P3 | OAuth2 | N/A | Documents, folders, sharing, revisions, comments | Import/export text documents — useful for users who draft elsewhere | |
| **Notion*** | P3 | OAuth2 | N/A | Pages, databases, blocks | Import notes/outlines into Field, export art objects to Notion | |
| **Google Fonts** | P4 | API Key | Font families, styles, categories, specimen | N/A | Expanded typography options for the text editor | |
| **Dropbox** | P4 | OAuth2 | N/A | Files, folders | Import/export text files | |

---

## PROJECTS (export & sync)

Saving, exporting, and syncing finished Signified Objects.

| API | Priority | Auth Type | General Data (no account needed) | Account-Specific Data (signed in) | Notes | Comments |
|-----|----------|-----------|----------------------------------|-----------------------------------|-------|----------|
| **Google Drive** | P3 | OAuth2 | N/A | Create/update files, folder organization | Auto-backup art objects, export as Google Docs | |
| **Notion*** | P3 | OAuth2 | N/A | Create pages/database entries | Export Signified Objects to a Notion database — structured archive | |
| **Dropbox** | P4 | OAuth2 | N/A | File upload, sharing links | Backup/export art objects | |
| **Airtable** | P4 | OAuth2 | N/A | Bases, tables, records | Structured art object database — good for tracking submissions | |

---

## FRAME / KALEIDOSCOPE (identity & account management)

Service connection dashboard and user creative identity.

| API | Priority | Auth Type | General Data (no account needed) | Account-Specific Data (signed in) | Notes | Comments |
|-----|----------|-----------|----------------------------------|-----------------------------------|-------|----------|
| **Spotify*** | P2 | OAuth2 | N/A | Profile, display name, avatar, follower count | Identity display in Kaleidoscope | |
| **YouTube*** | P2 | OAuth2 | N/A | Channel name, avatar, subscriber count | Identity display | |
| **Are.na*** | P2 | OAuth2 | N/A | Username, avatar, channel count | Identity display | |
| **Instagram*** | P3 | OAuth2 | N/A | Profile, media count, bio | Creative identity — portfolio presence | |
| **Pinterest*** | P3 | OAuth2 | N/A | Profile, board count | Identity display | |
| **Trakt*** | P3 | OAuth2 | N/A | Profile, stats | Identity display | |
| **Last.fm*** | P3 | API Key | N/A | Profile, playcount, avatar | Identity display | |
| **SoundCloud*** | P3 | OAuth2 | N/A | Profile, track count, followers | Identity display | |
| **Bluesky** | P4 | App Password | N/A | Profile, handle, avatar, follower count | Identity display | |
| **Mastodon** | P4 | OAuth2 | N/A | Profile, handle, avatar | Identity display | |

---

## AI SERVICES (beyond Claude)

Alternative or supplementary AI for specific tasks.

| API | Priority | Auth Type | General Data (no account needed) | Account-Specific Data (signed in) | Notes | Comments |
|-----|----------|-----------|----------------------------------|-----------------------------------|-------|----------|
| **Anthropic Claude*** | P1 | API Key | Conversational AI, analysis, generation, classification, summarization | N/A | Core AI — Compass, Lab, Audience Finder, Configure Art Object, Palette Organize | |
| **Google Cloud Vision** | P3 | API Key | Image labels, OCR, color analysis, similar images, safe search | N/A | Auto-tag palette images, detect medium/content, color extraction for recommendations | |
| **OpenAI (GPT)** | P4 | API Key | Text generation, embeddings | N/A | Alternative text AI — mostly redundant with Claude | |
| **Stability AI** | P4 | API Key | Image generation, image-to-image, upscaling | N/A | Post-MVP when image medium returns to Field | |
| **Replicate** | P4 | API Key | Run open-source ML models (many modalities) | N/A | Post-MVP — flexible access to many generation models | |

---

## PRIORITY SUMMARY

### P1 — Ship with these (or have them ready)
- **Already integrated:** Open Library, Wikipedia, Met Museum, MusicBrainz, Wikimedia Commons, Wikidata, Internet Archive, Anthropic Claude
- **Already configured (need activation):** Spotify, YouTube, TMDB, Are.na, Eventbrite
- **New:** Google Maps/Places

### P2 — High value, next wave
- Genius, Flickr, Discogs, Last.fm, SoundCloud, Pinterest, Trakt, Notion
- Rijksmuseum, Art Institute of Chicago, Unsplash, Google Books, Europeana, Project Gutenberg
- Artsy, Meetup, Submittable

### P3 — Nice to have
- Reddit, Bluesky, Mastodon, Vimeo, Podcast Index, Google Drive, Google Cloud Vision, Colormind

### P4 — Post-MVP / stretch
- DeviantArt, Tumblr, Dribbble, Cooper Hewitt, Harvard Art Museums, OpenAlex, CrossRef
- LinkedIn, Foundation Directory, Airtable, Dropbox, Google Fonts
- OpenAI, Stability AI, Replicate, ElevenLabs
