// ── SIGNIFIED SANDBOX ─────────────────────────────────────────────────────────
// Single-file sandbox combining App, Frame, Guide, Lab, Palette, Field,
// Projects, shared. No external imports required except React hooks + fetch.
// API key is injected by the artifact runtime.

import { useState, useRef, useEffect, useMemo } from "react";

// ── Design tokens ─────────────────────────────────────────────────────────────
const c = {
  bg:"#f9f8f6", text:"#111111", textMid:"#333333", textLight:"#777777",
  border:"1px solid #d0d0d0", borderDark:"1px solid #111111",
};
const serif = {fontFamily:"'Libre Baskerville',serif"};
const mono  = {fontFamily:"'Space Mono',monospace"};
const bbs   = {fontFamily:"'Bebas Neue',sans-serif"};
const FRAME_COLOR = "#a0855a";
const SPACES = ["PALETTE","FIELD","PROJECTS"];
const SPACE_COLORS = { PALETTE:"#1a56db", FIELD:"#1a7a3a", PROJECTS:"#c0392b" };

// ── Default frame state ───────────────────────────────────────────────────────
const DEFAULT_FRAME = {
  cf:false, fc:false, cpa:false, pac:false, cpr:false, prc:false,
  paf:false, fpa:false, papr:false, prpa:false, fpr:false, prf:false,
  compassCustom:[], paletteCustom:[], fieldCustom:[], projectsCustom:[],
  manifesto:"", unsignified:"", apiKeys:[],
};

// ── COMPASS system prompt ─────────────────────────────────────────────────────
const COMPASS_RULES = `COMPASS RULES

1. COMPASS does not speak unless spoken to.
2. COMPASS does not use first person.

--- MESSAGE PREFIXES (internal — never shown to user) ---

__NOTIFICATION__: Something went wrong in the interface. Explain what happened. Ask 1-2 focused questions to help resolve it.

__TROUBLESHOOT__: Troubleshooting mode is open. Full visibility into user's work is active. Open with exactly: "What can I help you with?" — nothing more, nothing less.

__WHATS_POSSIBLE__: Respond with exactly: "everything and nothing" — nothing more, nothing less.`;

// ── LAB system prompts ────────────────────────────────────────────────────────
const LAB_SYSTEM = {
  machine: `MACHINE

You are a generative tool. You produce content based on what is sent in the chat. You do not editorialize, comment, or have a voice of your own. You generate only.

Infer media type from the prompt. If the request implies visual content, lean toward image and video descriptions. If it implies audio, lean toward audio. Text is always available as a medium. Combinations are allowed and often appropriate. When an aspect of the request is ambiguous, do not default to the basic — leave it to chance or variety.

Produce. Do not explain. Do not ask for clarification unless the request is completely unresolvable.`,

  discover: `DISCOVER

You are a tool for curiosity, inquiry, research, and education. Your purpose is not to give answers but to orient the user toward the different ways a question can be answered — and to expand, not close, their inquiry.

When a user asks a question:
1. Do not give a direct answer.
2. Identify the types of answers the question could have (subjective, objective, community-based, historical, disciplinary, etc.).
3. For each answer type, give a brief example of what an answer of that type looks like, with a named source or framework attached.
4. End with a question that invites self-reflection about why the user asked the question — not a question that narrows their choice.

Always name your sources. Always acknowledge the limits of those sources. Distinguish what is known from what is contested.`,

  dialog: (character) => {
    if (!character?.trim()) return `DIALOG\n\nWait for a character to be set. Do not speak until one is given.`;
    return `DIALOG\n\nYou are ${character}. You speak only as ${character}. You do not break character. You do not acknowledge that you are an AI. You use first person.\n\nYour knowledge, vocabulary, and mode of expression are limited entirely to what ${character} would know, say, and do.`;
  },
  feedback: `FEEDBACK\n\nWork in progress.`,
  prompt: `PROMPT\n\nWork in progress.`,
};

// ── Context builder ───────────────────────────────────────────────────────────
function buildContext({ space, fieldTitle, fieldText, library, frame }) {
  const lib = library.length===0
    ? "  (empty)"
    : library.map(i=>`  - "${i.title||"untitled"}"${i.creator?` by ${i.creator}`:""}${i.year?`, ${i.year}`:""}`).join("\n");
  let sections = [`Space: ${space}`];
  if (frame.fc)  sections.push(`FIELD:\n  Title: ${fieldTitle||"(untitled)"}\n  Text: ${fieldText?(fieldText.slice(0,1200)+(fieldText.length>1200?"...":"")):"(empty)"}`);
  if (frame.pac) sections.push(`PALETTE:\n${lib}`);
  if (frame.prc) sections.push(`PROJECTS: visible to Compass`);
  const active=[];
  if (frame.cf)  active.push("Active in FIELD: offer inline comments when relevant.");
  if (frame.cpa) active.push("Active in PALETTE: proactively recommend works.");
  if (frame.cpr) active.push("Active in PROJECTS: suggest opportunities and audiences.");
  if (active.length) sections.push(`ACTIVE ROLES:\n${active.map(a=>`  - ${a}`).join("\n")}`);
  if (!frame.cf&&!frame.cpa&&!frame.cpr) sections.push(`COMPASS MODE: passive.`);
  if (!frame.fc&&!frame.pac&&!frame.prc) sections.push(`COMPASS MODE: detached.`);
  const areaLinks=[];
  if (frame.paf)  areaLinks.push("Palette → Field");
  if (frame.fpa)  areaLinks.push("Field → Palette");
  if (frame.papr) areaLinks.push("Palette → Projects");
  if (frame.prpa) areaLinks.push("Projects → Palette");
  if (frame.fpr)  areaLinks.push("Field → Projects");
  if (frame.prf)  areaLinks.push("Projects → Field");
  if (areaLinks.length) sections.push(`CONNECTIONS:\n${areaLinks.map(a=>`  - ${a}`).join("\n")}`);
  if (frame.manifesto?.trim()) sections.push(`MANIFESTO:\n  ${frame.manifesto.trim()}`);
  if (frame.unsignified?.trim()) sections.push(`UNSIGNIFIED (always ask what user means):\n  ${frame.unsignified.trim()}`);
  return `\n\n--- SIGNIFIED STATE ---\n${sections.join("\n\n")}\n---\n\nUse this naturally. Never announce it.`;
}

// ── useChatBot hook ───────────────────────────────────────────────────────────
function useChatBot(systemPrompt) {
  const [messages,setMessages]=useState([]);
  const [loading,setLoading]=useState(false);
  async function send(text,ctx="") {
    const next=[...messages,{role:"user",content:text}];
    setMessages(next); setLoading(true);
    try {
      const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,system:systemPrompt+(ctx||""),messages:next})});
      const d=await res.json();
      setMessages([...next,{role:"assistant",content:d.content?.map(b=>b.text||"").join("")||"..."}]);
    } catch { setMessages([...next,{role:"assistant",content:"Something went quiet."}]); }
    setLoading(false);
  }
  return {messages,loading,send,clear:()=>setMessages([])};
}

// ── Shared atoms ──────────────────────────────────────────────────────────────
function SineSymbol({ size=28, color="#111111", sw=1.8 }) {
  const cx=size/2, cy=size/2, r=size*0.36, sq=size*0.115, sqCy=cy+r;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} fill="none">
      <circle cx={cx} cy={cy} r={r} stroke={color} strokeWidth={sw} fill="none"/>
      <rect x={cx-sq} y={sqCy-sq} width={sq*2} height={sq*2} fill={color} rx={0}/>
    </svg>
  );
}
function S({ size=12, color="#111" }) {
  return <span style={{display:"inline-block",verticalAlign:"middle",lineHeight:1,position:"relative",top:"-0.05em"}}><SineSymbol size={size} color={color} sw={1.6}/></span>;
}
function Toggle({ on, onChange, label }) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:12,cursor:"pointer"}} onClick={()=>onChange(!on)}>
      <div style={{width:36,height:20,borderRadius:10,background:on?"#111":"#ccc",position:"relative",transition:"background 0.2s",flexShrink:0}}>
        <div style={{position:"absolute",top:2,left:on?16:2,width:16,height:16,borderRadius:"50%",background:"#fff",transition:"left 0.2s"}}/>
      </div>
      <span style={{...serif,fontSize:13,color:c.textMid,lineHeight:1.5}}>{label}</span>
    </div>
  );
}
function BinaryBar({ options, value, onChange }) {
  return (
    <div style={{display:"inline-flex",border:c.border,borderRadius:4,overflow:"hidden",flexShrink:0}}>
      {options.map(opt=>(
        <button key={opt.value} onClick={()=>onChange(opt.value)}
          style={{...mono,fontSize:9,letterSpacing:"0.1em",padding:"5px 12px",border:"none",cursor:"pointer",
            background:value===opt.value?"#111":"transparent",
            color:value===opt.value?"#fff":c.textLight,transition:"all 0.15s"}}>
          {opt.label}
        </button>
      ))}
    </div>
  );
}
function SectionHead({ title, children }) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16}}>
      {typeof title==="string"
        ? <p style={{...bbs,fontSize:22,letterSpacing:"0.14em",color:c.text,margin:0,flex:1}}>{title}</p>
        : <div style={{flex:1}}>{title}</div>}
      {children}
    </div>
  );
}
function LockBtn({ locked, onToggle, disabled }) {
  return (
    <button onClick={onToggle} disabled={disabled}
      style={{background:"none",border:"none",cursor:disabled?"default":"pointer",padding:0,opacity:disabled?0.3:1,lineHeight:1}}>
      <svg width="16" height="18" viewBox="0 0 16 18" fill="none">
        <rect x="2" y="8" width="12" height="10" rx="2" fill="#111"/>
        {locked
          ? <path d="M4 8V6a4 4 0 018 0v2" stroke="#111" strokeWidth="1.8" fill="none" strokeLinecap="round"/>
          : <path d="M4 8V6a4 4 0 018 0" stroke="#aaa" strokeWidth="1.8" fill="none" strokeLinecap="round"/>}
        <circle cx="8" cy="13" r="1.5" fill="white"/>
      </svg>
    </button>
  );
}
function FolderBtn({ onClick }) {
  return (
    <button onClick={onClick} style={{background:"none",border:"none",cursor:"pointer",padding:0,lineHeight:1}}>
      <svg width="18" height="16" viewBox="0 0 18 16" fill="none">
        <path d="M1 3a1 1 0 011-1h5l2 2h7a1 1 0 011 1v9a1 1 0 01-1 1H2a1 1 0 01-1-1V3z" fill="#ccc" stroke="#999" strokeWidth="1"/>
      </svg>
    </button>
  );
}
function EditableText({ value, onChange, style={}, placeholder="" }) {
  const [editing,setEditing]=useState(false);
  const [draft,setDraft]=useState(value);
  const ref=useRef(null);
  useEffect(()=>{if(editing)ref.current?.focus();},[editing]);
  function commit(){setEditing(false);if(draft!==value)onChange(draft);}
  if(editing) return <input ref={ref} value={draft} onChange={e=>setDraft(e.target.value)}
    onBlur={commit} onKeyDown={e=>{if(e.key==="Enter")commit();if(e.key==="Escape"){setDraft(value);setEditing(false);}}}
    style={{...style,border:"none",borderBottom:"1px solid #ccc",outline:"none",background:"transparent",padding:"1px 0",width:"auto",minWidth:40}}/>;
  return <span onClick={()=>{setDraft(value);setEditing(true);}} style={{...style,cursor:"text",color:value?style.color:"#ccc",fontStyle:value?style.fontStyle:"italic"}}>
    {value||placeholder}
  </span>;
}

// ── SINE button ───────────────────────────────────────────────────────────────
function SINEButton({ open, onClick, notification }) {
  return (
    <button onClick={onClick} style={{background:"none",border:"none",cursor:"pointer",padding:"4px",display:"flex",alignItems:"center",position:"relative"}}>
      <div style={{animation:(!open&&notification)?"sineFloat 1.8s ease-in-out infinite":"none"}}>
        <SineSymbol size={28} color={(!open&&notification)?"#d4a800":c.text}/>
      </div>
    </button>
  );
}

// ── Floating chat window ──────────────────────────────────────────────────────
function FloatingWindow({ title, bot, open, onClose, placeholder, accentColor="#111", bottomRight, getContext }) {
  const [input,setInput]=useState("");
  const [expanded,setExpanded]=useState(false);
  const bottomRef=useRef(null);
  useEffect(()=>{ bottomRef.current?.scrollIntoView({behavior:"smooth"}); },[bot.messages,bot.loading]);
  function send(){ if(!input.trim())return; bot.send(input.trim(), getContext?getContext():""); setInput(""); }
  if(!open) return null;
  const {bottom=20,right=20}=bottomRight||{};
  const cs = expanded
    ? {position:"absolute",inset:0,width:"100%",height:"100%",background:"#fff",border:"none",borderRadius:0,display:"flex",flexDirection:"column",zIndex:300}
    : {position:"absolute",bottom,right,width:300,height:380,background:"#fff",border:c.border,borderRadius:12,display:"flex",flexDirection:"column",zIndex:300};
  return (
    <div style={cs}>
      <div style={{padding:"10px 12px",display:"flex",alignItems:"center",borderRadius:expanded?"0":"12px 12px 0 0",flexShrink:0,background:accentColor,position:"relative",minHeight:40}}>
        <button onClick={()=>setExpanded(e=>!e)} style={{background:"none",border:"none",fontSize:16,color:"rgba(255,255,255,0.4)",cursor:"pointer",padding:0,lineHeight:1,flexShrink:0}}>{expanded?"⊡":"⊞"}</button>
        <div style={{position:"absolute",left:"50%",transform:"translateX(-50%)",display:"flex",alignItems:"center"}}>{title}</div>
        <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:8}}>
          {bot.messages.length>0&&<button onClick={bot.clear} style={{...mono,background:"none",border:"none",fontSize:9,color:"rgba(255,255,255,0.5)",cursor:"pointer",letterSpacing:"0.1em",padding:0}}>CLEAR</button>}
          <button onClick={onClose} style={{background:"none",border:"none",fontSize:18,color:"rgba(255,255,255,0.6)",cursor:"pointer",padding:0,lineHeight:1}}>×</button>
        </div>
      </div>
      <div style={{flex:1,overflowY:"auto",padding:expanded?"24px 32px 0":"14px 14px 0",maxWidth:expanded?"720px":"none",width:"100%",margin:expanded?"0 auto":"0",boxSizing:"border-box"}}>
        {bot.messages.length===0&&<p style={{...serif,fontSize:12,color:c.textLight,fontStyle:"italic",lineHeight:1.8,margin:0}}></p>}
        {bot.messages.map((m,i)=>(
          <div key={i} style={{marginBottom:12,display:"flex",flexDirection:"column",alignItems:m.role==="user"?"flex-end":"flex-start"}}>
            <div style={{maxWidth:"90%",background:m.role==="user"?accentColor:"transparent",borderRadius:m.role==="user"?8:0,padding:m.role==="user"?"7px 11px":"0",fontSize:expanded?14:12,lineHeight:1.8,color:m.role==="user"?"#fff":c.textMid,...(m.role==="assistant"?{fontFamily:"'Libre Baskerville',serif",fontStyle:"italic"}:{fontFamily:"'Space Mono',monospace"}),whiteSpace:"pre-wrap"}}>{m.content}</div>
          </div>
        ))}
        {bot.loading&&<p style={{...mono,fontSize:10,color:c.textLight}}>···</p>}
        <div ref={bottomRef}/>
      </div>
      <div style={{padding:expanded?"16px 32px":"8px 11px",flexShrink:0,maxWidth:expanded?"720px":"none",width:"100%",margin:expanded?"0 auto":"0",boxSizing:"border-box"}}>
        <div style={{display:"flex",gap:6,alignItems:"center"}}>
          <input value={input} onChange={e=>setInput(e.target.value)}
            onKeyDown={e=>{if(e.key==="Enter"){e.preventDefault();send();}}}
            placeholder={placeholder||"stirrings still..."}
            style={{...serif,flex:1,border:"none",borderBottom:c.border,borderRadius:0,padding:"6px 2px",fontSize:11,color:c.text,outline:"none",fontStyle:"italic",lineHeight:1.5,background:"transparent"}}/>
          <button onClick={send} style={{background:accentColor,border:"none",borderRadius:4,width:24,height:24,cursor:"pointer",flexShrink:0}}/>
        </div>
      </div>
    </div>
  );
}

// ── LAB icons ─────────────────────────────────────────────────────────────────
function MachineIcon({ size=16, color="#fff" }) {
  const cx=size/2,cy=size/2,s=size,outerR=s*0.48,bodyR=s*0.36,ringR=s*0.265,holeR=s*0.17,teeth=8,pts=[];
  for(let i=0;i<teeth;i++){const base=(i/teeth)*Math.PI*2-Math.PI/2,half=(Math.PI/teeth)*0.55;pts.push(`${cx+Math.cos(base-half)*bodyR},${cy+Math.sin(base-half)*bodyR}`);pts.push(`${cx+Math.cos(base-half)*outerR},${cy+Math.sin(base-half)*outerR}`);pts.push(`${cx+Math.cos(base+half)*outerR},${cy+Math.sin(base+half)*outerR}`);pts.push(`${cx+Math.cos(base+half)*bodyR},${cy+Math.sin(base+half)*bodyR}`);}
  const uid=`gm${Math.round(s*Math.random()*100)}`;
  return <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} fill="none"><defs><mask id={uid}><rect width={s} height={s} fill="white"/><circle cx={cx} cy={cy} r={holeR} fill="black"/><circle cx={cx} cy={cy} r={ringR} stroke="black" strokeWidth={s*0.05} fill="none"/></mask></defs><polygon points={pts.join(" ")} fill={color} mask={`url(#${uid})`}/></svg>;
}
function DiscoverIcon({ size=16, color="#fff" }) {
  const s=size,cx=s/2;
  return <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} fill="none"><rect x={s*0.04} y={s*0.28} width={s*0.055} height={s*0.5} fill={color}/><rect x={s*0.095} y={s*0.24} width={s*0.055} height={s*0.54} fill={color}/><rect x={s*0.85} y={s*0.28} width={s*0.055} height={s*0.5} fill={color}/><rect x={s*0.795} y={s*0.24} width={s*0.055} height={s*0.54} fill={color}/><path d={`M${cx} ${s*0.74} Q${cx-s*0.05} ${s*0.52} ${s*0.15} ${s*0.18} Q${s*0.22} ${s*0.1} ${s*0.32} ${s*0.16} L${s*0.15} ${s*0.74} Z`} fill={color}/><path d={`M${cx} ${s*0.74} Q${cx+s*0.05} ${s*0.52} ${s*0.85} ${s*0.18} Q${s*0.78} ${s*0.1} ${s*0.68} ${s*0.16} L${s*0.85} ${s*0.74} Z`} fill={color}/><path d={`M${s*0.15} ${s*0.74} Q${cx} ${s*0.66} ${s*0.85} ${s*0.74}`} stroke={color} strokeWidth={s*0.065} fill="none" strokeLinecap="round"/></svg>;
}
function DialogIcon({ size=16, color="#fff" }) {
  const s=size,r=s*0.19;
  function Q({cx,cy}){return <g><circle cx={cx} cy={cy} r={r} fill={color}/><path d={`M${cx+r*0.4} ${cy+r*0.7} C${cx+r*0.8} ${cy+r*2.2} ${cx-r*1.0} ${cy+r*2.8} ${cx-r*0.2} ${cy+r*1.2}`} fill={color}/></g>;}
  return <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} fill="none"><Q cx={s*0.32} cy={s*0.38}/><Q cx={s*0.65} cy={s*0.38}/></svg>;
}
function FeedbackIcon({ size=16, color="#fff" }) {
  const s=size;
  return <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} fill="none"><rect x={s*0.1} y={s*0.15} width={s*0.8} height={s*0.55} rx={s*0.08} stroke={color} strokeWidth={s*0.1} fill="none"/><path d={`M${s*0.3} ${s*0.7} L${s*0.2} ${s*0.88}`} stroke={color} strokeWidth={s*0.09} strokeLinecap="round"/><line x1={s*0.3} y1={s*0.38} x2={s*0.7} y2={s*0.38} stroke={color} strokeWidth={s*0.08} strokeLinecap="round"/><line x1={s*0.3} y1={s*0.55} x2={s*0.6} y2={s*0.55} stroke={color} strokeWidth={s*0.08} strokeLinecap="round"/></svg>;
}
function PromptIcon({ size=16, color="#fff" }) {
  const s=size;
  return <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} fill="none"><circle cx={s*0.5} cy={s*0.42} r={s*0.28} stroke={color} strokeWidth={s*0.1} fill="none"/><line x1={s*0.5} y1={s*0.72} x2={s*0.5} y2={s*0.82} stroke={color} strokeWidth={s*0.1} strokeLinecap="round"/><circle cx={s*0.5} cy={s*0.92} r={s*0.06} fill={color}/></svg>;
}
const TOOL_ICONS = { machine:MachineIcon, discover:DiscoverIcon, dialog:DialogIcon, feedback:FeedbackIcon, prompt:PromptIcon };
const TOOL_LABELS = { machine:"MACHINE", discover:"DISCOVER", dialog:"DIALOG", feedback:"FEEDBACK", prompt:"PROMPT" };

// ── Flask ─────────────────────────────────────────────────────────────────────
function FlaskIcon({ size=36 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" style={{overflow:"visible"}}>
      <style>{`@keyframes lb1{0%{transform:translateY(0) scale(1);opacity:1}100%{transform:translateY(-28px) scale(0.3);opacity:0}}@keyframes lb2{0%{transform:translateY(0);opacity:1}100%{transform:translateY(-22px) scale(0.2);opacity:0}}@keyframes lb3{0%{transform:translateY(0);opacity:1}100%{transform:translateY(-18px) scale(0.4);opacity:0}}.lb1{animation:lb1 2.2s ease-out infinite;transform-origin:43px 9px}.lb2{animation:lb2 2.8s ease-out 0.7s infinite;transform-origin:54px 5px}.lb3{animation:lb3 2.4s ease-out 1.4s infinite;transform-origin:48px 2px}`}</style>
      <rect x="34" y="7" width="32" height="7" rx="3.5" fill="none" stroke="#111" strokeWidth="4"/>
      <rect x="39" y="13" width="22" height="25" rx="1" fill="none" stroke="#111" strokeWidth="3.5"/>
      <path d="M39 37 L13 76 Q9 86 18 88 L82 88 Q91 86 87 76 L61 37 Z" fill="none" stroke="#111" strokeWidth="4.5" strokeLinejoin="round"/>
      <path d="M21 77 Q50 71 79 77 L82 88 Q91 86 87 76 L61 37 L39 37 L13 76 Q9 86 18 88 Z" fill="#111"/>
      <circle cx="40" cy="63" r="4.5" fill="white"/><circle cx="55" cy="70" r="3.2" fill="white"/><circle cx="64" cy="59" r="3.8" fill="white"/>
      <circle className="lb1" cx="43" cy="9" r="3.5" fill="#111"/>
      <circle className="lb2" cx="54" cy="5" r="2.5" fill="#111"/>
      <circle className="lb3" cx="48" cy="2" r="1.8" fill="#111"/>
    </svg>
  );
}

// ── Lab window ────────────────────────────────────────────────────────────────
const ALL_COLORS=["#ff6600","#ff8800","#ffaa00","#ff4400","#ff0099","#ff0055","#ff3388","#cc0077","#00cccc","#00cc66","#993399","#aa22cc","#7700ee","#9933ff"];
function pickColor(){return ALL_COLORS[Math.floor(Math.random()*ALL_COLORS.length)];}

function LabWindow({ open, onClose, onSave, enabledTools=["machine","discover","dialog"], color="#111111" }) {
  const [activeTool, setActiveTool] = useState(enabledTools[0]||"machine");
  const [characterDraft, setCharacterDraft] = useState("");
  const [character, setCharacter] = useState("");
  const [characterSet, setCharacterSet] = useState(false);
  const [input, setInput] = useState("");
  const [saved, setSaved] = useState(false);
  const bottomRef = useRef(null);
  const machineBot  = useChatBot(LAB_SYSTEM.machine);
  const discoverBot = useChatBot(LAB_SYSTEM.discover);
  const dialogBot   = useChatBot(typeof LAB_SYSTEM.dialog==="function"?LAB_SYSTEM.dialog(character):(LAB_SYSTEM.dialog||""));
  const feedbackBot = useChatBot(LAB_SYSTEM.feedback);
  const promptBot   = useChatBot(LAB_SYSTEM.prompt);
  const bots = { machine:machineBot, discover:discoverBot, dialog:dialogBot, feedback:feedbackBot, prompt:promptBot };
  const bot = bots[activeTool]||machineBot;
  useEffect(()=>{ bottomRef.current?.scrollIntoView({behavior:"smooth"}); },[bot.messages,bot.loading,activeTool]);
  if(!open) return null;
  function send(){if(!input.trim())return;if(activeTool==="dialog"&&!characterSet)return;bot.send(input.trim());setInput("");}
  function commitCharacter(){const val=characterDraft.trim();if(!val)return;setCharacter(val);setCharacterSet(true);dialogBot.clear();}
  function handleSave(){const text=bot.messages.map(m=>`${m.role==="user"?"You":TOOL_LABELS[activeTool]}: ${m.content}`).join("\n\n");if(!text.trim())return;onSave({id:Date.now(),title:`${TOOL_LABELS[activeTool]} session`,content:text,text,words:text.split(/\s+/).filter(Boolean).length,date:new Date().toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})});setSaved(true);setTimeout(()=>setSaved(false),2200);}
  return (
    <div style={{position:"absolute",bottom:12,left:60,width:320,height:680,background:"#fff",border:c.border,borderRadius:12,display:"flex",flexDirection:"column",zIndex:290,boxShadow:"0 4px 24px rgba(0,0,0,0.10)"}}>
      <div style={{display:"flex",alignItems:"stretch",padding:"6px 8px",borderBottom:c.border,flexShrink:0,background:"#fafaf8",borderRadius:"12px 12px 0 0",gap:2}}>
        {enabledTools.map(tool=>{
          const TIcon=TOOL_ICONS[tool];const active=tool===activeTool;
          return <button key={tool} onClick={()=>setActiveTool(tool)} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:3,padding:"5px 3px",border:"none",borderRadius:5,cursor:"pointer",background:active?color:"transparent",transition:"background 0.15s"}}>
            <TIcon size={13} color={active?"#fff":"#aaa"}/><span style={{...mono,fontSize:7,letterSpacing:"0.06em",color:active?"#fff":"#aaa",lineHeight:1}}>{TOOL_LABELS[tool]}</span>
          </button>;
        })}
        <div style={{display:"flex",alignItems:"center",gap:5,marginLeft:4,paddingLeft:6,borderLeft:c.border}}>
          {bot.messages.length>0&&<button onClick={bot.clear} style={{...mono,background:"none",border:"none",fontSize:8,color:"#bbb",cursor:"pointer",padding:0}}>CLEAR</button>}
          <button onClick={handleSave} style={{...mono,background:"none",border:"none",fontSize:8,color:saved?"#1a7a3a":"#bbb",cursor:"pointer",padding:0}}>{saved?"✓":"SAVE"}</button>
          <button onClick={onClose} style={{background:"none",border:"none",fontSize:15,color:"#bbb",cursor:"pointer",padding:0,lineHeight:1}}>×</button>
        </div>
      </div>
      {activeTool==="dialog"&&(
        <div style={{padding:"6px 10px",borderBottom:c.border,flexShrink:0,background:"#f5f5f3",display:"flex",alignItems:"center",gap:6}}>
          <span style={{...mono,fontSize:8,letterSpacing:"0.08em",color:"#bbb",flexShrink:0}}>speaking as</span>
          {characterSet?(<>
            <span style={{...serif,fontSize:12,color:c.text,flex:1,fontStyle:"italic",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{character}</span>
            <button onClick={()=>{setCharacterSet(false);setCharacterDraft(character);}} style={{...mono,fontSize:8,background:"none",border:c.border,padding:"2px 6px",cursor:"pointer",color:c.textMid,flexShrink:0}}>CHANGE</button>
          </>):(<>
            <input value={characterDraft} onChange={e=>setCharacterDraft(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")commitCharacter();}} placeholder="a name, a thing, a concept..." autoFocus
              style={{...serif,flex:1,border:"none",borderBottom:"1px solid #ddd",outline:"none",fontSize:11,color:c.text,fontStyle:"italic",background:"transparent",padding:"2px 0"}}/>
            <button onClick={commitCharacter} style={{...mono,fontSize:8,background:color,color:"#fff",border:"none",padding:"3px 8px",cursor:"pointer",borderRadius:3,flexShrink:0}}>SET</button>
          </>)}
        </div>
      )}
      <div style={{flex:1,overflowY:"auto",padding:"12px 12px 0"}}>
        {bot.messages.length===0&&activeTool==="dialog"&&!characterSet&&<p style={{...serif,fontSize:11,color:c.textLight,fontStyle:"italic",lineHeight:1.8,margin:0,paddingTop:8}}>Set a character above to begin.</p>}
        {bot.messages.map((m,i)=>(
          <div key={i} style={{marginBottom:10,display:"flex",flexDirection:"column",alignItems:m.role==="user"?"flex-end":"flex-start"}}>
            <div style={{maxWidth:"92%",background:m.role==="user"?color:"transparent",borderRadius:m.role==="user"?8:0,padding:m.role==="user"?"6px 10px":"0",fontSize:12,lineHeight:1.8,color:m.role==="user"?"#fff":c.textMid,...(m.role==="assistant"?{...serif,fontStyle:"italic"}:{...mono}),whiteSpace:"pre-wrap"}}>{m.content}</div>
          </div>
        ))}
        {bot.loading&&<p style={{...mono,fontSize:10,color:c.textLight}}>···</p>}
        <div ref={bottomRef}/>
      </div>
      <div style={{padding:"8px 10px",flexShrink:0,borderTop:c.border}}>
        <div style={{display:"flex",gap:6,alignItems:"center"}}>
          <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"){e.preventDefault();send();}}}
            placeholder={activeTool==="dialog"&&!characterSet?"set a character first...":"..."} disabled={activeTool==="dialog"&&!characterSet}
            style={{...serif,flex:1,border:"none",borderBottom:c.border,padding:"5px 2px",fontSize:11,color:c.text,outline:"none",fontStyle:"italic",background:"transparent",opacity:activeTool==="dialog"&&!characterSet?0.35:1}}/>
          <button onClick={send} disabled={activeTool==="dialog"&&!characterSet}
            style={{background:color,border:"none",borderRadius:4,width:22,height:22,cursor:"pointer",flexShrink:0,opacity:activeTool==="dialog"&&!characterSet?0.25:1}}/>
        </div>
      </div>
    </div>
  );
}

function LabButton({ onSaveToProjects, enabledTools=["machine","discover","dialog"] }) {
  const [open,setOpen]=useState(false);
  const [color]=useState(()=>pickColor());
  return (
    <>
      <button onClick={()=>setOpen(o=>!o)} style={{position:"absolute",bottom:12,left:12,background:"none",border:"none",cursor:"pointer",padding:0,lineHeight:1,zIndex:401}}>
        <FlaskIcon size={36}/>
      </button>
      <LabWindow open={open} onClose={()=>setOpen(false)} onSave={onSaveToProjects} enabledTools={enabledTools} color={color}/>
    </>
  );
}

// ── FIELD SPACE ───────────────────────────────────────────────────────────────
const FSIZES=[8,9,10,11,12,14,16,18,20,22,24,28,32,36,48,72];
const FFONTS=["Times New Roman","Georgia","Arial","Helvetica","Courier New","Libre Baskerville"];

function TBtn({title,active,onClick,children}){
  return <button title={title} onMouseDown={e=>{e.preventDefault();onClick?.();}} style={{background:active?"#111":"none",border:"none",padding:"3px 6px",cursor:"pointer",color:active?"#fff":c.textMid,fontSize:13,lineHeight:1,display:"flex",alignItems:"center",justifyContent:"center",minWidth:26,height:26}}>{children}</button>;
}
function Sep(){return <div style={{width:1,height:16,background:"#d0d0d0",margin:"0 4px",alignSelf:"center"}}/>;}

function FieldSpace({ title, setTitle, fieldText, setFieldText, onSave, notify }) {
  const editorRef=useRef(null);
  const [wc,setWC]=useState(0);
  const [fs,setFS]=useState(12);
  const [ff,setFF]=useState("Times New Roman");
  const [saved,setSaved]=useState(false);
  const [fmt,setFmt]=useState({bold:false,italic:false,underline:false,strike:false});
  const mounted=useRef(false);
  useEffect(()=>{
    if(!mounted.current&&editorRef.current&&fieldText){editorRef.current.innerHTML=fieldText;setWC((editorRef.current.innerText||"").trim().split(/\s+/).filter(Boolean).length);}
    mounted.current=true;
  },[]);
  function exec(cmd,val=null){editorRef.current?.focus();document.execCommand(cmd,false,val);rf();}
  function rf(){setFmt({bold:document.queryCommandState("bold"),italic:document.queryCommandState("italic"),underline:document.queryCommandState("underline"),strike:document.queryCommandState("strikeThrough")});}
  function onInput(){const t=editorRef.current?.innerText||"";setWC(t.trim().split(/\s+/).filter(Boolean).length);setFieldText(editorRef.current?.innerHTML||"");rf();}
  function applyFS(sz){setFS(sz);editorRef.current?.focus();document.execCommand("fontSize",false,"7");editorRef.current?.querySelectorAll('font[size="7"]').forEach(s=>{s.removeAttribute("size");s.style.fontSize=sz+"pt";});}
  function applyFF(f){setFF(f);exec("fontName",f);}
  function save(){const html=editorRef.current?.innerHTML||"",txt=editorRef.current?.innerText||"";if(!txt.trim()&&!title.trim())return;onSave({id:Date.now(),title:title.trim()||"Untitled",content:html,text:txt,words:txt.trim().split(/\s+/).filter(Boolean).length,date:new Date().toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})});setSaved(true);setTimeout(()=>setSaved(false),2200);}
  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",overflow:"hidden",position:"relative"}}>
      <div style={{display:"flex",alignItems:"center",gap:16,padding:"0 24px",height:44,borderBottom:c.border,background:"#fff",flexShrink:0}}>
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Untitled" style={{...mono,flex:1,background:"none",border:"none",outline:"none",fontSize:13,color:c.text,letterSpacing:"0.04em"}}/>
        <span style={{...mono,fontSize:10,color:c.textLight,whiteSpace:"nowrap"}}>{wc>0?`${wc} WDS`:""}</span>
        <button onClick={save} style={{...mono,fontSize:10,letterSpacing:"0.1em",background:saved?SPACE_COLORS.FIELD:"none",border:c.border,padding:"5px 14px",cursor:"pointer",color:saved?"#fff":c.textMid,whiteSpace:"nowrap",transition:"all 0.15s"}}>{saved?"SAVED ✓":"SAVE"}</button>
      </div>
      <div style={{display:"flex",alignItems:"center",gap:2,padding:"4px 16px",borderBottom:c.border,background:"#f5f5f3",flexWrap:"wrap",minHeight:36}}>
        <select value={ff} onChange={e=>applyFF(e.target.value)} style={{background:"none",border:"none",fontSize:11,color:c.textMid,cursor:"pointer",...mono,height:26,maxWidth:140}}>{FFONTS.map(f=><option key={f} value={f}>{f}</option>)}</select>
        <Sep/>
        <select value={fs} onChange={e=>applyFS(Number(e.target.value))} style={{background:"none",border:"none",fontSize:11,color:c.textMid,cursor:"pointer",...mono,height:26,width:44}}>{FSIZES.map(s=><option key={s} value={s}>{s}</option>)}</select>
        <Sep/>
        <TBtn title="Bold" active={fmt.bold} onClick={()=>exec("bold")}><b>B</b></TBtn>
        <TBtn title="Italic" active={fmt.italic} onClick={()=>exec("italic")}><i>I</i></TBtn>
        <TBtn title="Underline" active={fmt.underline} onClick={()=>exec("underline")}><u>U</u></TBtn>
        <TBtn title="Strike" active={fmt.strike} onClick={()=>exec("strikeThrough")}><s>S</s></TBtn>
        <Sep/>
        {[["L","justifyLeft"],["C","justifyCenter"],["R","justifyRight"],["J","justifyFull"]].map(([l,cmd])=>(<TBtn key={l} title={l} onClick={()=>exec(cmd)}><span style={{...mono,fontSize:9}}>{l}</span></TBtn>))}
        <Sep/>
        <TBtn title="UL" onClick={()=>exec("insertUnorderedList")}><span style={{...mono,fontSize:9}}>UL</span></TBtn>
        <TBtn title="OL" onClick={()=>exec("insertOrderedList")}><span style={{...mono,fontSize:9}}>OL</span></TBtn>
        <Sep/>
        <TBtn title="→" onClick={()=>exec("indent")}><span style={{...mono,fontSize:9}}>→</span></TBtn>
        <TBtn title="←" onClick={()=>exec("outdent")}><span style={{...mono,fontSize:9}}>←</span></TBtn>
        <Sep/>
        <TBtn title="Undo" onClick={()=>exec("undo")}><span style={{...mono,fontSize:9}}>↩</span></TBtn>
        <TBtn title="Redo" onClick={()=>exec("redo")}><span style={{...mono,fontSize:9}}>↪</span></TBtn>
      </div>
      <div style={{flex:1,overflowY:"auto",background:"#ebebeb",padding:"48px 0",display:"flex",justifyContent:"center"}}>
        <div style={{width:680,minHeight:880,background:"#fff",padding:"96px 88px"}}>
          <div ref={editorRef} contentEditable suppressContentEditableWarning onInput={onInput} onKeyUp={rf} onMouseUp={rf}
            style={{outline:"none",minHeight:680,fontSize:`${fs}pt`,fontFamily:ff,lineHeight:1.2,color:c.text,caretColor:c.text}}/>
        </div>
      </div>
      <LabButton onSaveToProjects={onSave}/>
    </div>
  );
}

// ── PROJECTS SPACE ────────────────────────────────────────────────────────────
function ProjectsSpace({ projects, onOpen, notify }) {
  return (
    <div style={{padding:"32px",overflowY:"auto",height:"100%"}}>
      {projects.length===0?(
        <div style={{paddingTop:48}}>
          <p style={{...serif,fontSize:15,fontStyle:"italic",color:c.textLight,lineHeight:1.8}}>Your art objects will appear here.<br/>Start writing in FIELD and save.</p>
        </div>
      ):(
        <div style={{display:"flex",flexDirection:"column",gap:1,background:"#d0d0d0",border:"1px solid #d0d0d0",maxWidth:640}}>
          {projects.map((p,i)=>(
            <div key={p.id} style={{background:"#fff",padding:"18px 20px",display:"flex",alignItems:"center",gap:16}}>
              <span style={{...mono,fontSize:11,color:c.textLight,flexShrink:0}}>{String(i+1).padStart(2,"0")}</span>
              <div style={{flex:1}}>
                <p style={{...serif,fontSize:16,color:c.text,margin:0,fontStyle:"italic"}}>{p.title}</p>
                <p style={{...mono,fontSize:10,color:c.textLight,margin:"4px 0 0"}}>{p.words} WDS · {p.date}</p>
              </div>
              <span style={{...mono,fontSize:10,color:c.textLight,border:"1px solid #d0d0d0",padding:"3px 8px"}}>AO</span>
              <button onClick={()=>onOpen(p)} style={{...mono,fontSize:10,letterSpacing:"0.1em",background:SPACE_COLORS.PROJECTS,border:"none",padding:"7px 16px",color:"#fff",cursor:"pointer"}}>OPEN</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── PALETTE SPACE ─────────────────────────────────────────────────────────────
async function runSearch(q) {
  if(!q.trim()) return {text:[],image:[],video:[]};
  await new Promise(r=>setTimeout(r,350));
  const results=[
    {id:"m1",type:"text",title:"The Waste Land",subtitle:"T.S. Eliot · 1922",source:"Poem"},
    {id:"m2",type:"text",title:"Beloved",subtitle:"Toni Morrison · 1987",source:"Book"},
    {id:"m3",type:"text",title:"Kind of Blue",subtitle:"Miles Davis · 1959",source:"Album"},
    {id:"m4",type:"text",title:"In the Mood for Love",subtitle:"Wong Kar-wai · 2000",source:"Film"},
    {id:"m5",type:"text",title:"The Death of the Author",subtitle:"Roland Barthes · 1967",source:"Essay"},
    {id:"m6",type:"text",title:"Guernica",subtitle:"Pablo Picasso · 1937",source:"Artwork"},
    {id:"m7",type:"text",title:"Invisible Man",subtitle:"Ralph Ellison · 1952",source:"Book"},
    {id:"m8",type:"text",title:"Remain in Light",subtitle:"Talking Heads · 1980",source:"Album"},
    {id:"m9",type:"text",title:"Meshes of the Afternoon",subtitle:"Maya Deren · 1943",source:"Film"},
    {id:"m10",type:"text",title:"Camera Lucida",subtitle:"Roland Barthes · 1980",source:"Book"},
    {id:"m11",type:"text",title:"The Double",subtitle:"Dostoevsky · 1846",source:"Book"},
    {id:"m12",type:"text",title:"Nighthawks",subtitle:"Edward Hopper · 1942",source:"Artwork"},
  ];
  const q2=q.toLowerCase();
  const filtered=results.filter(i=>i.title.toLowerCase().includes(q2)||i.subtitle.toLowerCase().includes(q2)||i.source.toLowerCase().includes(q2));
  return {text:filtered.length>0?filtered:results,image:[],video:[]};
}

function TextResult({ item, onAdd }) {
  const [hov,setHov]=useState(false);
  return (
    <div onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)} onClick={()=>onAdd(item)}
      style={{padding:"10px 20px",cursor:"pointer",borderBottom:c.border,background:hov?"#f4f0e8":"transparent",transform:hov?"scale(1.012)":"scale(1)",transformOrigin:"left center",transition:"all 0.12s"}}>
      <p style={{...serif,fontSize:13,color:c.text,fontWeight:700,margin:0,lineHeight:1.3}}>{item.title}</p>
      {item.subtitle&&<p style={{...mono,fontSize:10,color:c.textLight,margin:"2px 0 0"}}>{item.subtitle}</p>}
      <span style={{...mono,fontSize:8,color:c.textLight,letterSpacing:"0.1em"}}>{item.source}</span>
    </div>
  );
}

function PaletteItem({ item, onUpdate, onDelete, onDragStart, onDrop, notify }) {
  const [open,setOpen]=useState(false);
  const [hov,setHov]=useState(false);
  return (
    <div draggable onDragStart={onDragStart} onDrop={e=>{e.preventDefault();onDrop();}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{position:"relative",background:"#fff",border:c.border,borderRadius:4,padding:"10px 12px",minWidth:120,maxWidth:220,cursor:"grab",transition:"all 0.12s",boxShadow:hov?"0 2px 12px rgba(0,0,0,0.08)":"none",animation:"paletteDrop 0.22s ease-out"}}>
      <p style={{...serif,fontSize:13,color:c.text,fontWeight:700,margin:0,lineHeight:1.3,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{item.title||"untitled"}</p>
      {item.creator&&<p style={{...mono,fontSize:9,color:c.textLight,margin:"2px 0 0"}}>{item.creator}{item.year?`, ${item.year}`:""}</p>}
      <div style={{display:"flex",gap:4,marginTop:6}}>
        <button onClick={()=>setOpen(o=>!o)} style={{...mono,fontSize:8,background:"none",border:c.border,padding:"2px 6px",cursor:"pointer",color:c.textLight}}>···</button>
        <button onClick={()=>onDelete(item.id)} style={{...mono,fontSize:8,background:"none",border:c.border,padding:"2px 6px",cursor:"pointer",color:"#cc2200"}}>×</button>
      </div>
      {open&&(
        <div style={{marginTop:8,borderTop:c.border,paddingTop:8}}>
          <input value={item.itext||""} onChange={e=>onUpdate({...item,itext:e.target.value})} placeholder="notes..."
            style={{...serif,width:"100%",border:c.border,padding:"4px 8px",fontSize:11,color:c.text,outline:"none",background:"#fafafa",marginBottom:4}}/>
          <input value={item.creator||""} onChange={e=>onUpdate({...item,creator:e.target.value})} placeholder="creator"
            style={{...mono,width:"100%",border:c.border,padding:"4px 8px",fontSize:10,color:c.text,outline:"none",background:"#fafafa",marginBottom:4}}/>
          <input value={item.year||""} onChange={e=>onUpdate({...item,year:e.target.value})} placeholder="year"
            style={{...mono,width:"100%",border:c.border,padding:"4px 8px",fontSize:10,color:c.text,outline:"none",background:"#fafafa"}}/>
        </div>
      )}
    </div>
  );
}

function FolderTile({ folder, onOpen, onUpdate, onDelete, notify }) {
  const [hov,setHov]=useState(false);
  return (
    <div onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{background:"#fff",border:c.border,borderRadius:4,padding:"10px 12px",minWidth:120,maxWidth:220,cursor:"pointer",boxShadow:hov?"0 2px 12px rgba(0,0,0,0.08)":"none"}}>
      <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:4}}>
        <svg width="14" height="12" viewBox="0 0 18 16" fill="none"><path d="M1 3a1 1 0 011-1h5l2 2h7a1 1 0 011 1v9a1 1 0 01-1 1H2a1 1 0 01-1-1V3z" fill="#ddd" stroke="#bbb" strokeWidth="1"/></svg>
        <EditableText value={folder.title||""} onChange={v=>onUpdate({...folder,title:v})} style={{...serif,fontSize:13,fontWeight:700,color:c.text}} placeholder="folder"/>
      </div>
      <p style={{...mono,fontSize:9,color:c.textLight}}>{(folder.items||[]).length} items</p>
      <div style={{display:"flex",gap:4,marginTop:6}}>
        <button onClick={()=>onOpen(folder.id)} style={{...mono,fontSize:8,background:"none",border:c.border,padding:"2px 8px",cursor:"pointer",color:c.textMid}}>OPEN</button>
        <button onClick={()=>onDelete(folder.id)} style={{...mono,fontSize:8,background:"none",border:c.border,padding:"2px 6px",cursor:"pointer",color:"#cc2200"}}>×</button>
      </div>
    </div>
  );
}

function FolderView({ folder, onClose, onUpdate, onDelete, notify }) {
  return (
    <div style={{position:"absolute",inset:0,background:c.bg,zIndex:20,display:"flex",flexDirection:"column"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,padding:"12px 16px",borderBottom:c.border,background:"#fff",flexShrink:0}}>
        <button onClick={onClose} style={{...mono,fontSize:10,background:"none",border:c.border,padding:"4px 10px",cursor:"pointer",color:c.textMid}}>← BACK</button>
        <EditableText value={folder.title||""} onChange={v=>onUpdate({...folder,title:v})} style={{...serif,fontSize:16,fontWeight:700,color:c.text}} placeholder="folder name"/>
        <span style={{...mono,fontSize:10,color:c.textLight,marginLeft:"auto"}}>{(folder.items||[]).length} items</span>
        <button onClick={()=>onDelete(folder.id)} style={{...mono,fontSize:9,background:"none",border:"1px solid #cc2200",padding:"4px 10px",cursor:"pointer",color:"#cc2200"}}>DELETE</button>
      </div>
      <div style={{flex:1,overflowY:"auto",padding:16,display:"flex",flexWrap:"wrap",gap:10,alignContent:"flex-start"}}>
        {(folder.items||[]).length===0&&<p style={{...serif,fontSize:13,color:c.textLight,fontStyle:"italic"}}>Empty folder. Drag items here to add them.</p>}
        {(folder.items||[]).map(item=>(
          <PaletteItem key={item.id} item={item} notify={notify}
            onUpdate={updated=>onUpdate({...folder,items:(folder.items||[]).map(i=>i.id===updated.id?updated:i)})}
            onDelete={id=>onUpdate({...folder,items:(folder.items||[]).filter(i=>i.id!==id)})}
            onDragStart={()=>{}} onDrop={()=>{}}/>
        ))}
      </div>
    </div>
  );
}

function PaletteSpace({ library, setLibrary, media, setMedia, notify }) {
  const [items,setItemsRaw]=useState([]);
  const [query,setQuery]=useState("");
  const [results,setResults]=useState({text:[],image:[],video:[]});
  const [showSearch,setShowSearch]=useState(false);
  const [searching,setSearching]=useState(false);
  const [mode,setMode]=useState("linear");
  const [mediaType,setMediaType]=useState("text");
  const [scope,setScope]=useState("any");
  const [openFolderId,setOpenFolderId]=useState(null);
  const searchVer=useRef(0);
  const dragIdx=useRef(null);

  function setItems(fn){setItemsRaw(prev=>{const next=typeof fn==="function"?fn(prev):fn;setLibrary(next.filter(i=>i.label==="ltext"));setMedia(next.filter(i=>i.label==="limage"||i.label==="lvideo").map(i=>({id:i.id,type:i.label==="lvideo"?"video":"image",src:i.src,label:i.title})));return next;});}

  const openFolder=openFolderId?items.find(i=>i.id===openFolderId):null;

  useEffect(()=>{
    if(!query.trim()){setResults({text:[],image:[],video:[]});setShowSearch(false);return;}
    setShowSearch(true);
    const ver=++searchVer.current;
    setSearching(true);
    const t=setTimeout(async()=>{
      let r;
      if(scope==="palette"){const q=query.toLowerCase(),pool=items.filter(i=>i.label!=="lfolder");r={text:pool.filter(i=>i.label==="ltext"&&(i.title||"").toLowerCase().includes(q)).map(i=>({...i,type:"text",inPalette:true})),image:[],video:[]};}
      else if(scope==="folder"&&openFolder){const q=query.toLowerCase(),pool=(openFolder.items||[]);r={text:pool.filter(i=>i.label==="ltext"&&(i.title||"").toLowerCase().includes(q)).map(i=>({...i,type:"text",inPalette:true})),image:[],video:[]};}
      else{r=await runSearch(query);const paletteIds=new Set(items.map(i=>i.id));r={text:r.text.map(i=>({...i,inPalette:paletteIds.has(i.id)})),image:r.image,video:r.video};}
      if(searchVer.current===ver){setResults(r);setSearching(false);}
    },300);
    return()=>clearTimeout(t);
  },[query,scope,openFolderId]);

  function addItem(result){
    const base={id:`p-${Date.now()}`,inPalette:true,itext:"",organizeText:"",queryText:result.title||""};
    let newItem;
    if(result.type==="text") newItem={...base,label:"ltext",title:result.title,creator:result.subtitle||"",year:""};
    else if(result.type==="image") newItem={...base,label:"limage",src:result.src,title:result.title};
    else newItem={...base,label:"lvideo",src:result.src,thumb:result.thumb,videoId:result.videoId,title:result.title};
    if(scope==="folder"&&openFolder) setItems(prev=>prev.map(i=>i.id===openFolder.id?{...i,items:[...(i.items||[]),newItem]}:i));
    else setItems(prev=>[...prev,newItem]);
    setQuery(""); setShowSearch(false);
  }
  function addDirect(){if(!query.trim())return;setItems(prev=>[...prev,{id:`p-${Date.now()}`,label:"ltext",title:query.trim(),creator:"",year:"",itext:"",organizeText:"",inPalette:true,queryText:""}]);setQuery("");setShowSearch(false);}
  function updateItem(updated){setItems(prev=>prev.map(i=>i.id===updated.id?updated:i));}
  function deleteItem(id){setItems(prev=>prev.filter(i=>i.id!==id));}
  function handleDrop(targetId){const fromId=dragIdx.current;if(!fromId||fromId===targetId)return;dragIdx.current=null;setItems(prev=>{const from=prev.find(i=>i.id===fromId),target=prev.find(i=>i.id===targetId);if(!from||!target)return prev;if(target.label==="lfolder")return [...prev.filter(i=>i.id!==fromId),{...target,items:[...(target.items||[]),from]}].filter(i=>i.id!==fromId||(i.id===fromId&&i.id===targetId));const folder={id:`f-${Date.now()}`,label:"lfolder",title:"",items:[target,from],itext:"",organizeText:"",inPalette:true,queryText:""};return [...prev.filter(i=>i.id!==fromId&&i.id!==targetId),folder];});}

  const hasResults=results.text.length||results.image.length||results.video.length;
  const scopeOptions=openFolder?[{label:"ANY",value:"any"},{label:"PALETTE",value:"palette"},{label:"FOLDER",value:"folder"}]:[{label:"ANY",value:"any"},{label:"PALETTE",value:"palette"}];

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",overflow:"hidden",position:"relative",background:c.bg}}>
      <div style={{padding:"12px 16px",flexShrink:0,zIndex:10}}>
        <div style={{display:"flex",alignItems:"center",gap:8,background:"#fff",borderRadius:24,border:c.border,padding:"8px 14px",boxShadow:"0 1px 4px rgba(0,0,0,0.06)"}}>
          <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="search your influences..."
            style={{...serif,flex:1,border:"none",outline:"none",fontSize:13,color:c.text,fontStyle:"italic",background:"transparent"}}/>
          <button onClick={addDirect} style={{background:"none",border:"none",cursor:"pointer",fontSize:22,color:c.textLight,lineHeight:1,padding:"0 2px",fontWeight:300}}>+</button>
          <div style={{display:"inline-flex",border:c.border,borderRadius:4,overflow:"hidden"}}>
            {scopeOptions.map(opt=>(
              <button key={opt.value} onClick={()=>setScope(opt.value)}
                style={{...mono,fontSize:8,letterSpacing:"0.08em",padding:"4px 9px",border:"none",cursor:"pointer",background:scope===opt.value?"#111":"transparent",color:scope===opt.value?"#fff":c.textLight,transition:"all 0.12s"}}>
                {opt.label}
              </button>
            ))}
          </div>
          <BinaryBar options={[{label:"LINEAR",value:"linear"},{label:"MIX",value:"mix"}]} value={mode} onChange={setMode}/>
          {mode==="linear"&&(
            <div style={{display:"inline-flex",border:c.border,borderRadius:4,overflow:"hidden"}}>
              {["text","image","video"].map(t=>(
                <button key={t} onClick={()=>setMediaType(t)}
                  style={{...mono,fontSize:8,letterSpacing:"0.08em",padding:"4px 9px",border:"none",cursor:"pointer",background:mediaType===t?SPACE_COLORS.PALETTE:"transparent",color:mediaType===t?"#fff":c.textLight,transition:"all 0.12s"}}>
                  {t}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      <div style={{flex:1,overflow:"hidden",position:"relative"}}>
        {openFolder&&<FolderView folder={openFolder} onClose={()=>{setOpenFolderId(null);setScope(s=>s==="folder"?"any":s);}} onUpdate={updateItem} onDelete={id=>{deleteItem(id);setOpenFolderId(null);}} notify={notify}/>}
        {!openFolder&&showSearch&&hasResults&&(
          <div style={{height:"100%",overflowY:"auto"}}>
            {results.text.map(item=>(
              <div key={item.id} style={{position:"relative"}}>
                {item.inPalette&&<span style={{position:"absolute",left:8,top:"50%",transform:"translateY(-50%)",display:"inline-block",width:7,height:7,borderRadius:"50%",background:SPACE_COLORS.PALETTE,zIndex:2}}/>}
                <TextResult item={item} onAdd={addItem}/>
              </div>
            ))}
          </div>
        )}
        {!openFolder&&showSearch&&!hasResults&&searching&&<div style={{padding:24,...mono,fontSize:11,color:c.textLight,letterSpacing:"0.1em"}}>searching...</div>}
        {!openFolder&&!showSearch&&(
          <div style={{height:"100%",overflowY:"auto",padding:16,display:"flex",flexWrap:"wrap",gap:10,alignContent:"flex-start"}}>
            {items.length===0&&<p style={{...serif,fontSize:13,color:c.textLight,fontStyle:"italic",paddingTop:8}}>Search for influences, or type and press + to add directly.</p>}
            {items.map(item=>(
              item.label==="lfolder"?(
                <FolderTile key={item.id} folder={item} onOpen={id=>{setOpenFolderId(id);setScope("folder");}} onUpdate={updateItem} onDelete={deleteItem} notify={notify}/>
              ):(
                <div key={item.id} onDragOver={e=>{e.preventDefault();}} onDrop={()=>handleDrop(item.id)}>
                  <PaletteItem item={item} notify={notify} onUpdate={updateItem} onDelete={deleteItem} onDragStart={()=>{dragIdx.current=item.id;}} onDragOver={()=>{}} onDrop={()=>handleDrop(item.id)}/>
                </div>
              )
            ))}
          </div>
        )}
      </div>
      <style>{`@keyframes paletteDrop{0%{opacity:0;transform:scale(0.5) translateY(-20px)}100%{opacity:1;transform:scale(1) translateY(0)}}`}</style>
    </div>
  );
}

// ── FRAME overlay ─────────────────────────────────────────────────────────────
const BASE_TEXTS = {
  guide: {
    classic: `Guide answers questions, helps with tasks, and responds conversationally. It uses first person, offers opinions, validates your ideas, and behaves like a standard AI assistant.`,
    signified: `Guide does not speak unless spoken to. Guide does not use first person. Guide never appeals to the user. Guide does not deliver verdicts or validate. Guide opens questions rather than closing them.`,
  },
  connections: `No connections are active. Guide operates independently with no access to your spaces unless you turn connections on.`,
  unsignified: `No words are currently marked as undefined.`,
  manifesto: `No manifesto has been written.`,
};

function FrameTextBox({ value, onChange, locked, onLock, onResetBase, onResetLast, baseText, showFolder }) {
  const [showReset,setShowReset]=useState(false);
  return (
    <div style={{position:"relative",marginTop:12}}>
      <div style={{border:`1px solid ${locked?"#d0d0d0":"#999"}`,borderRadius:4,background:"#fff"}}>
        <textarea value={value} onChange={e=>onChange(e.target.value)} readOnly={locked} rows={4} placeholder="add your own notes..."
          style={{width:"100%",border:"none",outline:"none",padding:"12px 14px 6px",...serif,fontSize:12,color:c.text,lineHeight:1.75,resize:"none",background:"transparent",cursor:locked?"default":"text"}}/>
        {baseText&&<>
          <div style={{height:1,background:"#e8e4dc",margin:"0 14px"}}/>
          <textarea value={baseText} onChange={e=>onChange(e.target.value,"base")} readOnly={locked} rows={4}
            style={{width:"100%",border:"none",outline:"none",padding:"8px 14px 12px",...serif,fontSize:11,color:c.textMid,lineHeight:1.7,resize:"none",background:"transparent",fontStyle:"italic",cursor:locked?"default":"text"}}/>
        </>}
      </div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"flex-end",marginTop:4,gap:8}}>
        {showFolder&&<FolderBtn onClick={()=>{}}/>}
        <div style={{position:"relative"}}>
          <button onClick={()=>setShowReset(s=>!s)} style={{...mono,fontSize:8,letterSpacing:"0.1em",background:"none",border:c.border,padding:"3px 8px",cursor:"pointer",color:c.textMid}}>RESET</button>
          {showReset&&(
            <div style={{position:"absolute",bottom:"100%",right:0,marginBottom:4,background:"#fff",border:c.border,borderRadius:4,overflow:"hidden",zIndex:10,whiteSpace:"nowrap"}}>
              <button onClick={()=>{onResetBase();setShowReset(false);}} style={{...mono,fontSize:9,display:"block",width:"100%",padding:"7px 14px",border:"none",borderBottom:c.border,background:"none",cursor:"pointer",color:c.textMid,textAlign:"left"}}>RESET BASE</button>
              <button onClick={()=>{onResetLast?.();setShowReset(false);}} style={{...mono,fontSize:9,display:"block",width:"100%",padding:"7px 14px",border:"none",background:"none",cursor:"pointer",color:c.textMid,textAlign:"left"}}>RESET LAST</button>
            </div>
          )}
        </div>
        <LockBtn locked={locked} onToggle={onLock}/>
      </div>
    </div>
  );
}

function ConnRow({ k, dest, frame, upF }) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:12}}>
      <Toggle on={!!frame[k]} onChange={v=>upF(k,v)} label={dest}/>
    </div>
  );
}

function FrameOverlay({ onClose, frame, setFrame, currentUser, onSignIn, onSignOut, notify }) {
  const upF=(k,v)=>setFrame(f=>({...f,[k]:v}));
  const [guideBase,setGuideBase]=useState("signified");
  const [guideUserText,setGuideUserText]=useState("");
  const [guideBaseText,setGuideBaseText]=useState(BASE_TEXTS.guide.signified);
  const [guideLocked,setGuideLocked]=useState(false);
  const [connText,setConnText]=useState(BASE_TEXTS.connections);
  const [connLocked,setConnLocked]=useState(false);
  const [unsigText,setUnsigText]=useState("");
  const [unsigLocked,setUnsigLocked]=useState(false);
  const [manifestoLocked,setManifestoLocked]=useState(false);
  const [view,setView]=useState("idle");
  const [name,setName]=useState("");

  function switchGuideBase(v){setGuideBase(v);setGuideBaseText(BASE_TEXTS.guide[v]);}

  const groups=[
    {header:<span style={{...mono,fontSize:9,color:c.textLight,letterSpacing:"0.12em"}}>COMPASS</span>,rows:[
      {k:"cf",dest:"↔ FIELD"},{k:"cpa",dest:"↔ PALETTE"},{k:"cpr",dest:"↔ PROJECTS"},
      {k:"fc",dest:"FIELD sees Compass"},{k:"pac",dest:"PALETTE sees Compass"},{k:"prc",dest:"PROJECTS see Compass"},
    ]},
    {header:<span style={{...mono,fontSize:9,color:c.textLight,letterSpacing:"0.12em"}}>SPACES</span>,rows:[
      {k:"paf",dest:"Palette → Field"},{k:"fpa",dest:"Field → Palette"},
      {k:"papr",dest:"Palette → Projects"},{k:"prpa",dest:"Projects → Palette"},
      {k:"fpr",dest:"Field → Projects"},{k:"prf",dest:"Projects → Field"},
    ]},
  ];

  function sec(title,content,desc){
    return (
      <div style={{borderTop:c.border,paddingTop:32,marginTop:32}}>
        <SectionHead title={title}/>
        {desc&&<p style={{...serif,fontSize:12,fontStyle:"italic",color:c.textLight,lineHeight:1.7,marginBottom:16}}>{desc}</p>}
        {content}
      </div>
    );
  }

  return (
    <div style={{position:"absolute",inset:0,zIndex:200,background:c.bg,overflowY:"auto",display:"flex",flexDirection:"column"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 32px",height:56,borderBottom:c.border,flexShrink:0,background:"#fff"}}>
        <span style={{...bbs,fontSize:20,letterSpacing:"0.24em",color:FRAME_COLOR}}>FRAME</span>
        <button onClick={onClose} style={{background:"none",border:"none",fontSize:22,color:c.textLight,cursor:"pointer",lineHeight:1}}>×</button>
      </div>
      <div style={{flex:1,overflowY:"auto"}}>
        <div style={{maxWidth:760,margin:"0 auto",padding:"48px 40px 100px"}}>
          <div style={{marginBottom:40}}>
            <p style={{...bbs,fontSize:28,letterSpacing:"0.08em",color:c.text,lineHeight:1.1,marginBottom:10,fontStyle:"italic"}}>All the world's a stage...</p>
            <p style={{...serif,fontSize:13,color:c.textMid,lineHeight:1.8}}>Every setting here shapes how <S size={13}/> works with you.</p>
          </div>

          {/* PERSONA */}
          <div>
            <SectionHead title={<span style={{...bbs,fontSize:22,letterSpacing:"0.14em",color:c.text}}>PERSONA</span>}/>
            <div style={{marginBottom:24}}>
              {currentUser?(
                <div>
                  <p style={{...serif,fontSize:13,color:c.text,marginBottom:12}}>ID: <strong>{currentUser}</strong></p>
                  <button onClick={onSignOut} style={{...mono,fontSize:10,letterSpacing:"0.1em",background:"none",border:c.border,padding:"6px 14px",cursor:"pointer",color:c.textMid}}>SIGN OUT</button>
                  <span style={{...mono,fontSize:8,color:"#f39c12",border:"1px solid #f39c12",padding:"1px 5px",borderRadius:2,marginLeft:8}}>WIP — persistence by dev</span>
                </div>
              ):(
                <div>
                  {view==="idle"&&<div style={{display:"flex",gap:8,alignItems:"center"}}>
                    <button onClick={()=>setView("create")} style={{...mono,fontSize:10,letterSpacing:"0.1em",background:c.text,color:"#fff",border:"none",padding:"7px 16px",cursor:"pointer"}}>CREATE ACCOUNT</button>
                    <button onClick={()=>setView("login")} style={{...mono,fontSize:10,background:"none",border:c.border,padding:"7px 16px",cursor:"pointer",color:c.textMid}}>SIGN IN</button>
                    <span style={{...mono,fontSize:8,color:"#f39c12",border:"1px solid #f39c12",padding:"1px 5px",borderRadius:2}}>WIP</span>
                  </div>}
                  {(view==="create"||view==="login")&&<div style={{maxWidth:280}}>
                    <input value={name} onChange={e=>setName(e.target.value)} placeholder="ID"
                      style={{...serif,width:"100%",border:c.border,padding:"8px 12px",fontSize:13,color:c.text,outline:"none",background:"#fff",marginBottom:8}}/>
                    <div style={{display:"flex",gap:8}}>
                      <button onClick={()=>{if(name.trim()){onSignIn(name.trim());setView("idle");setName("");}}} style={{...mono,fontSize:10,background:c.text,color:"#fff",border:"none",padding:"7px 16px",cursor:"pointer"}}>{view==="create"?"CREATE":"SIGN IN"}</button>
                      <button onClick={()=>{setView("idle");setName("");}} style={{...mono,fontSize:9,background:"none",border:"none",color:c.textLight,cursor:"pointer"}}>cancel</button>
                    </div>
                  </div>}
                </div>
              )}
            </div>
            <div style={{marginTop:8}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
                <p style={{...mono,fontSize:9,letterSpacing:"0.14em",color:c.textLight}}>KALEIDOSCOPE</p>
                <span style={{...mono,fontSize:8,color:"#f39c12",border:"1px solid #f39c12",padding:"1px 5px",borderRadius:2}}>WIP</span>
              </div>
              <div style={{border:c.border,borderRadius:4,padding:"12px 14px",background:"#fafafa"}}>
                <p style={{...serif,fontSize:12,color:c.textLight,fontStyle:"italic"}}>Connected accounts. <span style={{...mono,fontSize:9,color:"#f39c12"}}>API integration by developer.</span></p>
              </div>
            </div>
          </div>

          {/* STUDIO */}
          {sec(
            <span style={{...bbs,fontSize:22,letterSpacing:"0.14em",color:c.text}}>STUDIO <span style={{...serif,fontSize:11,fontStyle:"italic",fontWeight:400,letterSpacing:0,color:c.textLight}}>in progress</span></span>,
            <div style={{border:c.border,borderRadius:4,padding:"12px 14px",background:"#fafafa"}}><p style={{...serif,fontSize:12,color:c.textLight,fontStyle:"italic"}}>Visual customization — colors, fonts, themes. Coming soon.</p></div>
          )}

          {/* GUIDE */}
          {sec(
            <span style={{...bbs,fontSize:22,letterSpacing:"0.14em",color:c.text}}>GUIDE</span>,
            <div>
              <p style={{...serif,fontSize:12,fontStyle:"italic",color:c.textLight,lineHeight:1.7,marginBottom:16}}>Choose how <S size={12}/> responds.</p>
              <BinaryBar options={[{label:"CLASSIC",value:"classic"},{label:"SIGNIFIED",value:"signified"}]} value={guideBase} onChange={switchGuideBase}/>
              <FrameTextBox value={guideUserText} onChange={v=>setGuideUserText(v)} baseText={guideBaseText} locked={guideLocked} onLock={()=>setGuideLocked(l=>!l)} onResetBase={()=>setGuideBaseText(BASE_TEXTS.guide[guideBase])} onResetLast={()=>setGuideLocked(true)}/>
            </div>,
            "CLASSIC behaves like standard AI. SIGNIFIED is constrained for creative discovery."
          )}

          {/* CONNECTIONS */}
          {sec(
            <span style={{...bbs,fontSize:22,letterSpacing:"0.14em",color:c.text}}>CONNECTIONS</span>,
            <div>
              <p style={{...serif,fontSize:12,fontStyle:"italic",color:c.textLight,lineHeight:1.7,marginBottom:20}}>Each connection makes data from one space available in another.</p>
              <div style={{display:"flex",gap:40,alignItems:"flex-start",marginBottom:20,flexWrap:"wrap"}}>
                <div style={{flex:1,display:"flex",flexDirection:"column",gap:20,minWidth:200}}>
                  {groups.map((group,gi)=>(
                    <div key={gi}>
                      {gi>0&&<div style={{borderTop:c.border,marginBottom:16}}/>}
                      <div style={{marginBottom:12}}>{group.header}</div>
                      <div style={{display:"flex",flexDirection:"column",gap:10,paddingLeft:4}}>
                        {group.rows.map(row=><ConnRow key={row.k} k={row.k} dest={row.dest} frame={frame} upF={upF}/>)}
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{width:180,height:180,border:c.border,borderRadius:8,background:"#fafafa",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:8,flexShrink:0}}>
                  <SineSymbol size={28} color={Object.values(frame).filter(v=>v===true).length>0?"#111":"#ccc"} sw={1.4}/>
                  <span style={{...mono,fontSize:9,color:c.textLight,letterSpacing:"0.1em"}}>{Object.values(frame).filter(v=>v===true).length} active</span>
                </div>
              </div>
              <FrameTextBox value={connText} onChange={v=>setConnText(v)} locked={connLocked} onLock={()=>setConnLocked(l=>!l)} onResetBase={()=>setConnText(BASE_TEXTS.connections)} onResetLast={()=>{setConnText(BASE_TEXTS.connections);setConnLocked(true);}} showFolder/>
            </div>,
            "All connections are passive — they inform, they don't act."
          )}

          {/* UNSIGNIFIED + MANIFESTO */}
          <div style={{borderTop:c.border,paddingTop:32,marginTop:32}}>
            <div style={{display:"flex",gap:32,flexWrap:"wrap"}}>
              <div style={{flex:1,minWidth:200}}>
                <SectionHead title={<span style={{...bbs,fontSize:22,letterSpacing:"0.14em",color:c.text}}>UNSIGNIFIED</span>}/>
                <p style={{...serif,fontSize:12,fontStyle:"italic",color:c.textLight,lineHeight:1.7,marginBottom:8}}>Words added here are always treated as undefined. Guide will ask what you mean — never assume.</p>
                <FrameTextBox value={unsigText} onChange={v=>setUnsigText(v)} locked={unsigLocked} onLock={()=>setUnsigLocked(l=>!l)} onResetBase={()=>setUnsigText("")} onResetLast={()=>{setUnsigText(frame.unsignified||"");setUnsigLocked(true);}} showFolder/>
              </div>
              <div style={{flex:1,minWidth:200}}>
                <SectionHead title={<span style={{...bbs,fontSize:22,letterSpacing:"0.14em",color:c.text,fontStyle:"italic"}}>manifesto</span>}/>
                <p style={{...serif,fontSize:12,fontStyle:"italic",color:c.textLight,lineHeight:1.7,marginBottom:8}}>Always available to Guide. Add notes, intentions, principles — anything essential to your creativity.</p>
                <FrameTextBox value={frame.manifesto||""} onChange={v=>upF("manifesto",v)} locked={manifestoLocked} onLock={()=>setManifestoLocked(l=>!l)} onResetBase={()=>upF("manifesto","")} onResetLast={()=>{upF("manifesto",frame.manifesto||"");setManifestoLocked(true);}} showFolder/>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

// ── Frame border animation ────────────────────────────────────────────────────
function FrameBorder({ height }) {
  const [dims,setDims]=useState({W:800,H:height});
  const [animate,setAnimate]=useState(false);
  const containerRef=useRef(null);
  useEffect(()=>{
    const W=containerRef.current?.parentElement?.offsetWidth||window.innerWidth;
    setDims({W,H:height});
    const t=setTimeout(()=>setAnimate(true),20);
    return()=>clearTimeout(t);
  },[]);
  const {W,H}=dims,pad=14,r=7,cx=W/2;
  const rPath=`M${cx},${pad} L${W-pad-r},${pad} Q${W-pad},${pad} ${W-pad},${pad+r} L${W-pad},${H-pad-r} Q${W-pad},${H-pad} ${W-pad-r},${H-pad} L${cx},${H-pad}`;
  const lPath=`M${cx},${pad} L${pad+r},${pad} Q${pad},${pad} ${pad},${pad+r} L${pad},${H-pad-r} Q${pad},${H-pad} ${pad+r},${H-pad} L${cx},${H-pad}`;
  const approxLen=(W/2-pad)+(H-2*pad)+(W/2-pad)+20;
  const lineStyle=animate?{strokeDasharray:approxLen,strokeDashoffset:0,transition:`stroke-dashoffset 0.9s cubic-bezier(0.4,0,0.2,1)`}:{strokeDasharray:approxLen,strokeDashoffset:approxLen};
  return (
    <svg ref={containerRef} width="100%" height={H} style={{position:"absolute",top:0,left:0,pointerEvents:"none",zIndex:0,overflow:"visible"}}>
      <path d={rPath} fill="none" stroke={FRAME_COLOR} strokeWidth={1.4} strokeLinecap="round" style={lineStyle}/>
      <path d={lPath} fill="none" stroke={FRAME_COLOR} strokeWidth={1.4} strokeLinecap="round" style={lineStyle}/>
    </svg>
  );
}

// ── About overlay ─────────────────────────────────────────────────────────────
function AboutOverlay({ onClose, onOpenCompass }) {
  return (
    <div style={{position:"absolute",inset:0,zIndex:200,background:c.bg,overflowY:"auto",display:"flex",flexDirection:"column"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 32px",height:56,borderBottom:c.border,flexShrink:0}}>
        <span style={{...bbs,fontSize:18,letterSpacing:"0.24em",color:c.textLight}}>SIGNIFIED</span>
        <button onClick={onOpenCompass} style={{background:"none",border:"none",cursor:"pointer",padding:4}}><SineSymbol size={22} color={c.text}/></button>
        <button onClick={onClose} style={{background:"none",border:"none",fontSize:22,color:c.textLight,cursor:"pointer",lineHeight:1}}>×</button>
      </div>
      <div style={{maxWidth:640,margin:"0 auto",padding:"72px 32px 120px"}}>
        <div style={{marginBottom:16}}>
          <span style={{...bbs,fontSize:80,lineHeight:0.9,color:c.text,display:"block",letterSpacing:"0.04em"}}>SIGNIFIED</span>
        </div>
        <div style={{marginBottom:56}}>
          <p style={{...serif,fontSize:14,color:c.textMid,lineHeight:1.7,fontStyle:"italic"}}>...here on the ground</p>
          <p style={{...serif,fontSize:14,color:c.textMid,lineHeight:1.7,fontStyle:"italic"}}>a healthy approach to AI...</p>
        </div>
        {["The world awaits the verdict that tomorrow's technology brings—but we do not. Artificial Intelligence: a project that has ascended humankind's imago. In turn, we are left to balance as uncertain subjects on unstable ground. Everything evolves, and everything is in question. SIGNIFIED creates opportunities for people to discover and experience meaning in flux.",
          "Together, we develop research methodologies, theories, and practices that ground our human experience and inform AI interfaces that favor us, the people—not the business, not institutions of power, and not an enigmatic algorithm—the real human beings. Our first interface, SINE, is a muse that guides anyone through their unique experience of creativity, self-discovery, and self-creation.",
          "To adapt and maintain leaves us with the bare minimum. To scale and accelerate leaves us always wanting more. SIGNIFIED is the home that carries us where we go and where we have always been."
        ].map((p,i)=><p key={i} style={{...serif,fontSize:16,lineHeight:1.9,color:c.text,marginBottom:24,textAlign:"justify"}}>{p}</p>)}
        <div style={{borderTop:c.borderDark,marginTop:56,paddingTop:48}}>
          <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:28}}>
            <SineSymbol size={64} color={c.text} sw={1.2}/>
          </div>
          {["Protects Creative Liberty","Provides Creative Guidance","Evokes Creative Experience"].map((item,i)=>(
            <div key={i} style={{display:"flex",alignItems:"baseline",gap:16,marginBottom:16,borderBottom:c.border,paddingBottom:16}}>
              <span style={{...mono,fontSize:11,color:c.textLight,flexShrink:0}}>{i+1}.</span>
              <span style={{...serif,fontSize:18,color:c.text,fontStyle:"italic"}}>{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── ROOT ──────────────────────────────────────────────────────────────────────
export default function SIGNIFIED() {
  const [space,setSpace]             = useState("FIELD");
  const [compassOpen,setCompassOpen] = useState(false);
  const [showAbout,setShowAbout]     = useState(false);
  const [showFrame,setShowFrame]     = useState(false);
  const [projects,setProjects]       = useState([]);
  const [fieldTitle,setFieldTitle]   = useState("");
  const [fieldText,setFieldText]     = useState("");
  const [library,setLibrary]         = useState([]);
  const [media,setMedia]             = useState([]);
  const [frame,setFrame]             = useState(DEFAULT_FRAME);
  const [notification,setNotification] = useState(null);
  const [troubleshoot,setTroubleshoot] = useState(false);
  const [currentUser,setCurrentUser]   = useState(null);

  const compass = useChatBot(COMPASS_RULES);

  function getContext(overrideFrame) {
    const f=overrideFrame||frame;
    const effective=troubleshoot?{...f,fc:true,pac:true,prc:true}:f;
    return buildContext({space,fieldTitle,fieldText:fieldText.replace(/<[^>]+>/g,"").trim(),library,frame:effective});
  }
  function notify(msg){ if(compassOpen) compass.send("__NOTIFICATION__:"+msg,getContext()); else setNotification(msg); }
  function saveToProjects(doc){ setProjects(prev=>{const idx=prev.findIndex(p=>p.id===doc.id);if(idx>=0){const u=[...prev];u[idx]=doc;return u;}return[doc,...prev];}); }
  function openTroubleshoot(){
    setTroubleshoot(true);setCompassOpen(true);
    setTimeout(()=>{const ctx=buildContext({space,fieldTitle,fieldText:fieldText.replace(/<[^>]+>/g,"").trim(),library,frame:{...frame,fc:true,pac:true,prc:true}});compass.send("__TROUBLESHOOT__",ctx);},80);
  }
  function openPossibilities(){ setCompassOpen(true); setTimeout(()=>compass.send("__WHATS_POSSIBLE__",getContext()),80); }
  useEffect(()=>{ if(compassOpen&&notification){compass.send("__NOTIFICATION__:"+notification,getContext());setNotification(null);} },[compassOpen]);

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:c.bg,color:c.text,fontFamily:"'Libre Baskerville',serif",position:"relative",overflow:"hidden"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Space+Mono:ital,wght@0,400;0,700;1,400&family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        ::-webkit-scrollbar{width:2px;}
        ::-webkit-scrollbar-thumb{background:#ccc;}
        input::placeholder,textarea::placeholder{color:#bbb;font-style:italic;}
        [contenteditable]:focus,button:focus{outline:none;}
        @keyframes sineFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
      `}</style>

      {showAbout&&<AboutOverlay onClose={()=>setShowAbout(false)} onOpenCompass={()=>setCompassOpen(true)}/>}
      {showFrame&&<FrameOverlay onClose={()=>setShowFrame(false)} frame={frame} setFrame={setFrame} currentUser={currentUser} onSignIn={n=>setCurrentUser(n)} onSignOut={()=>setCurrentUser(null)} notify={notify}/>}

      {/* Top bar */}
      <div style={{flexShrink:0,background:"#fff",position:"relative",zIndex:10}}>
        <FrameBorder key={space} height={92}/>
        <div style={{display:"grid",gridTemplateColumns:"1fr auto 1fr",alignItems:"center",padding:"0 20px",height:44,position:"relative"}}>
          <div style={{display:"flex",alignItems:"center"}}>
            <button onClick={()=>setShowAbout(true)} style={{background:"none",border:"none",cursor:"pointer",padding:"4px 6px"}}>
              <span style={{...bbs,fontSize:15,letterSpacing:"0.22em",color:c.text}}>SIGNIFIED</span>
            </button>
          </div>
          <button onClick={()=>setShowFrame(f=>!f)} style={{background:"none",border:"none",cursor:"pointer",padding:"4px 10px"}}>
            <span style={{...bbs,fontSize:17,letterSpacing:"0.26em",color:FRAME_COLOR}}>FRAME</span>
          </button>
          <div style={{display:"flex",alignItems:"center",justifyContent:"flex-end"}}>
            <div style={{flex:1,display:"flex",justifyContent:"center"}}>
              <style>{`@keyframes chromeSheen{0%{background-position:-200% center}100%{background-position:200% center}}.chrome-text{background:linear-gradient(90deg,#555 0%,#999 18%,#eee 32%,#fff 50%,#eee 68%,#999 82%,#555 100%);background-size:200% auto;-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;animation:chromeSheen 3.5s linear infinite;display:inline-block;font-family:'Libre Baskerville',serif;font-style:italic;font-weight:400;}`}</style>
              <button onClick={openPossibilities} style={{background:"none",border:"none",cursor:"pointer",padding:"4px 8px",lineHeight:1}}>
                <span className="chrome-text" style={{fontSize:11,letterSpacing:"0.01em"}}>possibilities</span>
              </button>
            </div>
            <SINEButton open={compassOpen} onClick={()=>setCompassOpen(o=>!o)} notification={notification}/>
          </div>
        </div>
        <div style={{display:"flex",justifyContent:"center",alignItems:"center",height:48,position:"relative"}}>
          <nav style={{display:"flex",gap:4}}>
            {SPACES.map(s=>(
              <button key={s} onClick={()=>setSpace(s)} style={{...bbs,border:"none",padding:"6px 16px",height:40,borderRadius:6,fontSize:15,letterSpacing:"0.18em",cursor:"pointer",color:space===s?"#fff":SPACE_COLORS[s],background:space===s?SPACE_COLORS[s]:"none",transition:"all 0.18s"}}>{s}</button>
            ))}
          </nav>
        </div>
      </div>

      {/* Space content */}
      <div style={{flex:1,overflow:"hidden",display:"flex",flexDirection:"column",position:"relative",zIndex:5}}>
        {space==="PALETTE"&&<PaletteSpace library={library} setLibrary={setLibrary} media={media} setMedia={setMedia} notify={notify}/>}
        {space==="FIELD"&&<FieldSpace title={fieldTitle} setTitle={setFieldTitle} fieldText={fieldText} setFieldText={setFieldText} onSave={saveToProjects} notify={notify}/>}
        {space==="PROJECTS"&&<ProjectsSpace projects={projects} onOpen={()=>setSpace("FIELD")} notify={notify}/>}
      </div>

      {/* ? button */}
      <button onClick={openTroubleshoot} style={{position:"fixed",bottom:12,right:12,background:"none",border:"none",cursor:"pointer",padding:0,lineHeight:1,zIndex:500}}>
        <svg width="36" height="36" viewBox="0 0 44 44">
          <defs><mask id="qmask"><rect width="44" height="44" fill="white"/><text x="22" y="33" textAnchor="middle" fontFamily="'Times New Roman',serif" fontWeight="900" fontSize="30" fill="black">?</text></mask></defs>
          <circle cx="22" cy="22" r="21" fill="#111" mask="url(#qmask)"/>
        </svg>
      </button>

      {/* Compass window */}
      <FloatingWindow
        title={<span style={{display:"inline-flex",alignItems:"center",gap:6}}>
          <SineSymbol size={20} color="#fff" sw={1.4}/>
          {troubleshoot&&<span style={{...mono,fontSize:8,letterSpacing:"0.1em",color:"rgba(255,255,255,0.6)",display:"inline-flex",alignItems:"center",gap:5}}>
            · TROUBLESHOOT
            <button onClick={()=>setTroubleshoot(false)} style={{background:"rgba(255,255,255,0.15)",border:"none",color:"#fff",cursor:"pointer",fontSize:8,padding:"1px 5px",borderRadius:2,...mono}}>EXIT</button>
          </span>}
        </span>}
        bot={compass} open={compassOpen} onClose={()=>setCompassOpen(false)}
        placeholder="stirrings still..." accentColor="#111" bottomRight={{bottom:20,right:60}} getContext={getContext}/>
    </div>
  );
}
