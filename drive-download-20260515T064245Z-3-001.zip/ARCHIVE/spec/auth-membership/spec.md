# Auth + Membership

## Purpose

Auth + Membership SHALL handle user authentication, session management, membership state (free / active), BYOK encryption on desktop, and Stripe checkout for paid membership. RLS-scoped, cloud-authoritative.

## Requirements

### Requirement: Supabase Auth (email/password + OAuth)

Authentication SHALL use Supabase Auth. Web uses the browser Supabase client (`apps/web/src/lib/supabase.ts`); session lives in the client; JWT attaches to every `user_data` / `user_profiles` query; RLS scopes rows by `auth.uid()`.

### Requirement: Auth gate at `main.tsx`

`main.tsx:93-94` (or current equivalent) SHALL show `<AuthScreen />` when there's no session, otherwise the full app.

### Requirement: Server endpoints verify session via service-role

Server endpoints (`api/*`, repo-root) SHALL verify the session with a service-role admin client (`api/_lib/supabase-admin.ts`) before serving data.

*Updated 2026-04-24 per D-206 (path correction: spec previously said `apps/web/api/*` but the actual paths are repo-root `/api/*` and `api/_lib/supabase-admin.ts`).*

### Requirement: Feature 1 triage — login-after-signup bug (priority 1)

The login-after-signup bug SHALL be fixed as **Phase 0** priority (D-80, pulled forward from end-of-walkthrough deferral). Blocks demo AND build-loop.

Full Feature 1 Auth triage SHALL land in Phase 0:
- Login-after-signup bug
- `auth-relogin.spec.ts` functional test + logout-button testid (D-54 approved)

### Requirement: Membership states

`user_profiles.membership` SHALL hold one of:
- `free`
- `active`
- `expired`

(`none` is retained as a pre-profile UI-only transient state.)

Written ONLY by the Stripe webhook after migration 00003 (RLS lockdown) is applied. Migration 00003's check constraint permits `('free', 'active', 'expired')`; the webhook writes `"expired"` in production.

*Updated 2026-04-24 per D-207. Aligns spec to migration 00003 + webhook + `MembershipStatus` type.*

### Requirement: RLS lockdown migration 00003

`supabase/migrations/00003_rls_lockdown.sql` SHALL be applied to production BEFORE any external tester touches the system. Until applied, any authenticated user can self-promote `membership='active'` via DevTools — unacceptable for soft launch.

### Requirement: Stripe checkout deferred to pre-ship

Stripe checkout + `SubscriptionScreen.tsx` SHALL ship in the **pre-MVP-ship batch** (D-51 defer; D-164 soft-launch gates Stripe off; D-164 is in-MVP but the checkout surface lands pre-publicization).

### Requirement: Soft launch scope

Soft launch SHALL ship with (D-164):
- 2-3 testers
- NO open registration
- Stripe gated off

### Requirement: BYOK on desktop via OS keychain

Desktop (Tauri) BYOK SHALL use the OS keychain (J-3). Master key `BYOK_MASTER_KEY_V{N}` rotates annually per `docs/byok-master-key-rotation.md` playbook.

### Requirement: BYOK encryption required before web launch

BYOK encryption (F-1 / D-15 / D-63) SHALL be implemented BEFORE web BYOK is enabled. Web BYOK DISABLED until this lands.

### Requirement: BYOK J-picks ratified

D-169 J-picks SHALL drive the AES-GCM encryption flow. Build queue unblocked.

### Requirement: Web path does not transmit client apiKey

Web client SHALL NOT send `apiKey` on the chat request path. Server (`apps/web/api/chat.ts` + `chat-stream.ts`) SHALL ignore any inbound `apiKey` field on the web path. Web BYOK is server-only via the `BYOK_MASTER_KEY_V1` flow; raw client API keys are never transmitted.

*Added 2026-04-24 per D-229.*

### Requirement: Observability MVP

Observability MVP scope (D-147):
- **Sentry** — error reporting
- **Log drain** — server logs

Deferred post-MVP:
- PostHog
- Datadog
- LogRocket

### Requirement: `/api/chat` security

Allowlist domain reconciled to **`localhost`** (dev) and **`signified.eiluz.com`** (current production host) — supersedes earlier `signified.ai` reference. `*.vercel.app` previews 403'd.

`CHAT_API_SECRET` is reclassified as **DROPPED** — it was previously listed as REQUIRED but never read in code (`.env.example` notes "Reserved (unused today)"); presence-gate semantics never landed. Spec drops the requirement; the `.env.example` line may stay as a reserved placeholder but is not enforced.

*Updated 2026-04-24 per D-208. Supersedes the earlier `localhost` + `signified.ai` + REQUIRED-secret framing in this Requirement and in `compass/spec.md`.*

### Requirement: Search proxy auth (D-64)

Server-side search proxy endpoints SHALL verify auth (P-16). Free-tier providers run client-side; keyed-tier providers (Discogs, Google Books) route server-side with auth verification.

### Requirement: Branch protection + Vercel auto-deploy

Per D-161:
- `main` branch protected
- Vercel auto-deploy wired to `main`

### Requirement: Biome lint CI (disabled pending cleanup)

Biome lint in CI SHALL remain disabled pending codebase cleanup (D-162). Focus on NEW errors, not the pre-existing ~517.

### Requirement: `@divergence`-tagged Playwright tests

Four pre-existing red Playwright tests SHALL stay tagged `@divergence` (D-163) — known-red, deferred. CI excludes these from the gating set.

### Requirement: Observability — ErrorBoundary

`ErrorBoundary` SHALL `console.error` in MVP (observability MVP per D-147). Sentry wiring is the MVP addition beyond `console.error`.

### Requirement: Rate limiting — chat-only carve-out

A6 rate limiting SHALL be skipped for soft launch (D-26) for all endpoints EXCEPT `/api/chat`, which retains a 20-requests-per-60-seconds in-memory IP+user limiter as cheap protection. All other endpoints unlimited until open registration. Revisit broader rate limiting before open registration.

*Updated 2026-04-24 per D-209. Acknowledges the chat-only limiter that already exists in code.*

### Requirement: CSP strict per-domain allowlist

SEC-5 CSP SHALL use a strict per-domain allowlist (D-11 approved).

### Requirement: Onboarding deferred

Onboarding (Mission 8, D-45) SHALL be deferred to the pre-MVP-ship batch.

### Requirement: Environment variables

`apps/web/.env` SHALL require:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `ANTHROPIC_API_KEY`
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `STRIPE_PRICE_ID`
- `GOOGLE_BOOKS_API_KEY`
- `DISCOGS_TOKEN` (or `DISCOGS_KEY` + `DISCOGS_SECRET`)
- `BYOK_MASTER_KEY_V1` (base64-encoded 32 bytes; generate with `openssl rand -base64 32`)

(`CHAT_API_SECRET` removed from required list per D-208 — reclassified as dropped.)

`.env.example` SHALL be kept in sync. The earlier "three keys currently missing from `.env.example`" note is removed — `CHAT_API_SECRET`, `DISCOGS_KEY`, `DISCOGS_SECRET` were already added; `BYOK_MASTER_KEY_V1` SHALL be appended next.

*Updated 2026-04-24 per D-208 / D-210.*
