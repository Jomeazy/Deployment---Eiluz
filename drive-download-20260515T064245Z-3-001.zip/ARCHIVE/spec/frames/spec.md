# Frames

## Purpose

Frames SHALL be visual containers on the field representing epistemic contexts — groups of field entities that share a context modifier, render citizenship rings on their members, and participate in connection context flow.

## Requirements

### Requirement: Frame ownership

A Frame SHALL own:
- position (x, y)
- size (width, height)
- color (from 8 warm swatches; default V1 warm gold `rgb(140,115,70)`)
- **priority rank** (integer, 1 = innermost)
- **membership list** (entity IDs)
- **definition** (authored via the shared Signified component, per D-186 D-14 and renamed per D-188)

Frames do NOT have a signify window. Frame settings live in the Frame window (D-166). This supersedes V5 4-slot back-face research.

*Updated 2026-04-24 per D-188.*

### Requirement: Citizenship

Entities SHALL be **citizens** of a frame when they are contained within the frame's bounds (per frame bounds + citizenship resolution). An entity can be a citizen of multiple frames simultaneously. Membership is explicit, ordered, and queryable by the context builder.

#### Scenario: Entity enters a frame
- **WHEN** a field entity is dropped into or dragged into a frame's bounds
- **THEN** the entity becomes a citizen of that frame
- **AND** citizenship ring for that frame fades in on the entity within 180 ms

#### Scenario: Entity leaves a frame
- **WHEN** a field entity is dragged out of a frame's bounds
- **THEN** the entity leaves that frame's membership list
- **AND** the ring fades out within 180 ms

### Requirement: Citizenship rings — zoom-adaptive band

Citizenship rings SHALL render thin colored rings around each citizen entity's bounding box:
- ONE ring per frame the entity is a citizen of
- Color matches the frame's color
- Band width: `clamp(6, 14, 10 * zoom)` canvas-constant (D-154, D-173 K5)
- Stacking: **priority-1 innermost**, higher priority outside (D-156 / D-173 K3 "full band no adaptation")
- 0.5 px universal hairline between ring pairs (D-173 K4)
- `pointer-events: none` (rings pass click through to the entity, per K6 hoverable-only)
- 180 ms opacity fade on show/hide; `prefers-reduced-motion` uses instant branch (D-157 K7)
- Rings are ADDITIVE to the entity's selection/focus ring, not replacements

### Requirement: Corner-dot fallback for small entities

Entities whose rendered min-dimension < 120 px SHALL use a corner-dot fallback instead of full rings (D-155). Hover / focus on the entity expands to full rings. Adaptive-width rendering retains as a fallback when full band won't fit (K8 deferred to Mission A per D-160).

### Requirement: Frame color palette (Mission L V2)

Frames SHALL pick from the 8 warm swatches palette (V2 per D-159). Default color V1 = `rgb(140,115,70)`. Picker UI V1 geometry includes a custom-RGB "+" escape pulled into MVP (PR-6). Custom-RGB panel UX details deferred to impeccable aesthetic audit.

### Requirement: Frame window (bottom pull-up panel)

Frame settings SHALL live in the Frame window — the bottom pull-up panel from `FrameStrip` (D-166, verbatim spec at `.claude/specs/frame-no-signify-bottom-panel.md`).

The Frame window SHALL show content **through the frame / connection lens**:
- a frame's own settings
- a connection's own settings
- an entity **as-part-of-a-frame/connection-relationship** (never raw entity settings)

Entity settings themselves live in the entity's Context.

### Requirement: Frame definition (direct Signified)

Frame settings SHALL author the frame's `definition` directly via the shared Signified primitive — **no** clarifying-question scaffold, **no** Manifesto-anchored "what is this frame's purpose?" prompt on top.

*Updated 2026-04-24 per D-196 (ratified by D-220). Supersedes D-185 DC-13.*

### Requirement: No dual SCB stack

`FrameTextBox.tsx` and any "dual SCB stack" scaffolding SHALL be deleted (D-158). Frame definition routes to the shared Signified component (D-186 D-14, renamed per D-188).

*Updated 2026-04-24 per D-188.*

### Requirement: Frame tie-breaker via per-object context-hierarchy ordering

When context-priority resolution produces a tie between multiple frames claiming default slot, tie-breaking SHALL resolve through the context hierarchies inside each object's signify window — the user orders frames there, and that ordering resolves the tie implicitly. **No separate tie-break UI at the frame level**; the prior "user pins default frame at conflict-time" prompt is killed.

*Updated 2026-04-24 per D-204. Supersedes D-186 D-17.*

### Requirement: Shared-frame adaptive geometry (basic)

When two field entities are citizens of the SAME frame, that frame's outline SHALL adapt to a single continuous shape that still hugs each entity individually, adapting live as the entities move (D-174 basic, verbatim spec at `.claude/specs/shared-frame-adaptive-geometry.md`).

3+ member topologies, size disparity, zoom behavior, perf, nested-frame interaction, and member-crossing edge cases are deferred to the R-shared-frame-adaptive research mission — see `signified-vision/openspec/specs/shared-frame-edge-cases/spec.md`.

### Requirement: Frame nesting (IN MVP)

Frame nesting SHALL be **IN MVP** — frames may contain other frames. Mechanics owed:
- parent/child resolution rules
- citizenship propagation (does a citizen of a child-frame automatically become a citizen of the parent-frame? — design-pending)
- ring stacking when nested frames share citizens
- Compass-context representation

A design pass on these mechanics SHALL land before nesting work can queue.

*Updated 2026-04-24 per D-195. Supersedes P-13 / D-61 deferral.*

### Requirement: Frames contribute to Compass context

The `buildContext()` assembler in `packages/core/src/context.ts` SHALL include frame membership (per-frame member names, not just count), frame definition text, and frame priority (frame-level attribute) in the Compass system-prompt slice.

Frame citizens are **not ranked** — citizenship is a flat membership relation. Frame `priority` remains a frame-level attribute (used for context resolution / tie-break elsewhere), not a per-citizen rank.

`buildContext()` SHALL also emit explicit **cross-frame overlap data**: when an entity belongs to multiple frames (e.g., entity X is a citizen of both Frame A and Frame B), the prompt builder grows a cross-frame-overlap section listing shared citizens. Compass is told about overlaps directly.

(Compass prompt text remains FROZEN per D-161; this is a data-layer requirement only.)

*Updated 2026-04-24 per D-266. Supersedes prior "rank + members suffice" framing.*
