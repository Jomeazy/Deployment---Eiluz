# Compass

## Purpose

Compass SHALL be the field-entity AI conversation surface. It is the primary AI interaction point in the product. Pulls context from whatever it's connected to; streams Claude responses; observes the Compass silence rule; and carries a FROZEN system prompt.

## Requirements

### Requirement: Compass is field-entity-only

Compass SHALL exist ONLY as a field entity (a Compass window). The top-level singleton in `packages/app/src/components/Compass.tsx` (plus `CompassHeader.tsx`, `CompassBody.tsx`, `CompassSettings.tsx`) is legacy and SHALL be deleted. The always-present edge-of-screen chrome slot is owned by **Notifications-as-popout-message** via the global top-right Compass Collaborator (DC-10), NOT by Compass.

The legacy `"\n\nUSER NOTES:\n" + compassNotes` system-prompt concat at `useCompassSend.ts:93` and legacy `Compass.tsx:137` SHALL be removed — user notes flow via the `signified` slot in `buildContext`, never via system-prompt string concat. (Compass prompt text remains FROZEN per D-161; this is plumbing only.)

*Updated 2026-04-24 per D-188.*

### Requirement: Compass signify-window contents (split-signified shell)

A Compass window's signify window SHALL use the **split-signified shell** (per D-191):
- **TOP half empty** — user Signified
- **BOTTOM half** — default compass base description
- **System-prompt base selector** — options `compass` / `classic` (renamed from `claude` per D-192, ratified by D-217). The base prompt lives inside the compass signify window.
- **Context hierarchy** (dynamic slot model)

There is **NO separate "Settings" block** (per D-191). The Compass Collaborator button lives on the **front face** of the Compass window per D-190 universal placement, NOT inside the signify-window slot list. **Reset-base** action (grouped with the Reset button on the Signified primitive) restores ONLY the bottom half.

One Signified is sufficient (universal-read subsumes the prior "additional SCB for system prompt" path).

*Updated 2026-04-24 per D-188 / D-190 / D-191 / D-192. Supersedes the prior 5-item Compass Context list.*

### Requirement: Compass system prompt is FROZEN

`packages/core/src/prompts/compass.ts` text SHALL NOT be edited (D-161). Scope of freeze:
- The string templates interpolated into the system prompt sent to the Anthropic API
- Any future file that composes Compass system-prompt text

What IS allowed:
- Reading the prompt to understand context
- Bug fixes to interpolation plumbing (e.g., D-94 `compassMode` → `compassModes` key-name fix)
- Streaming plumbing changes (Mission H)
- Incremental render changes
- Silence rule transport/UI changes
- Context-builder changes — the DATA fed into the prompt can evolve

What is KILLED:
- `#38` system-prompt refinement sprint
- Any A/B-variant prompt experiments

### Requirement: Compass streaming

Compass responses SHALL stream from `/api/chat` via Mission H streaming plumbing (PRs 1-3). Blank-state spinner during generation (D-52 onDelta wire + spinning-compass loading idea).

### Requirement: Compass silence rule

Compass SHALL observe the silence rule (D-98, spec drop at `.claude/specs/compass-silence-rule.md`):
- Keep the user message
- Suppress the assistant-side message entirely when Compass intentionally doesn't reply (e.g., greetings that shouldn't render)

### Requirement: Compass three-part context rule (retained)

Compass SHALL observe the three-part context hierarchy rule (D-109, ratified by D-225; spec drop at `.claude/specs/compass-context-rule.md`):
1. **Silent awareness** of what else lives in the field — Compass knows frames/connections/priority but does NOT narrate them unprompted
2. **On-demand detail pull** when the conversation calls for it — when the user references a specific entity/frame/connection, Compass pulls the referenced detail into the reply
3. **Connections read live entity content** for anything connected to the active entity — connection context payload wires to the live field-entity data, not to static connection metadata

Prompt-build path keeps this three-layer context shape. Phase 1 connection-formatter (joins live entity content) and inbound-resolver work align with this rule.

*Updated 2026-04-24 per D-225 (ratifies D-109).*

### Requirement: Compass reads own Signified via signified slot

Per `context-direction/spec.md` (D-186 D-4, slot kind renamed per D-188), Compass SHALL read its Signified via the `signified` slot — not a separate `compassNotes` path. Dead `CompassNotes` append is removed.

Compass notes SHALL collapse into the same signified slot every other field object uses. The legacy `USER NOTES:` system-prompt concat at `useCompassSend.ts:93` and `Compass.tsx:137` is ripped; notes route through the signified slot of `buildContext` (Phase 1 items 12 + 13).

*Updated 2026-04-24 per D-188 / D-226.*

### Requirement: Compass keyword-gating rebuilt in `compass-reply.ts`

Keyword-gating in `compass-reply.ts` SHALL be retained AND **rebuilt** as a short-circuit (D-186 D-7, rebuilt per D-227). Not every Compass prompt call hits the model.

Implementation:
- Add `shouldCallModel(text, frame): boolean` to `compass-reply.ts`
- Wire `Compass.tsx` (pre-deletion) AND `useCompassSend.ts` to call `shouldCallModel` BEFORE `sendChat`
- Final extraction location (compass-reply.ts vs context.ts) remains a Phase 5 dev-judgment hand-off

Phase 1 item 48 implements this default. Q46 (duplicate of Q16) is consolidated under D-227 / D-257.

*Updated 2026-04-24 per D-227 (consolidates Q16 + Q46).*

### Requirement: Prompt-key interpolation fixed

`packages/core/src/prompts/compass.ts` references to `"compassMode"` vs actual field `"compassModes"` SHALL be fixed (D-94). This is a plumbing bug, NOT a prompt-text edit.

### Requirement: Compass cross-session save — interim removed

Save button for cross-session Compass memory SHALL be removed in the interim (D-100 / D-185 DC-16, isolated packet). The Save button at `CompassHeaderButtons.tsx` (~lines 89–102) and its `saveConversation` wiring in both `useCompassSend.ts` and legacy `Compass.tsx` SHALL be deleted. Full save/export deferred post-MVP — see `signified-vision/openspec/specs/cross-session-memory/spec.md`.

### Requirement: Compass-to-field binding

Compass replies SHALL be able to bind to specific field entities via `canonical-connection.ts` — P-06 wire (D-55 approved).

### Requirement: BYOK on desktop, platform key on web

- **Desktop (Tauri):** BYOK via OS keychain (J-3, part of BYOK encryption flow). Encrypted at rest with master key `BYOK_MASTER_KEY_V{N}` (rotates annually; playbook at `docs/byok-master-key-rotation.md`).
- **Web:** platform Anthropic API key for paid members. Web BYOK DISABLED until BYOK encryption lands (F-1 / D-15 / D-63 / D-169).

### Requirement: Golden-path flake eliminated

P-01 Compass golden-path flake SHALL be eliminated via a testid path with cleanup verification (D-50).

### Requirement: `/api/chat` origin allowlist

`/api/chat` SHALL allow only `localhost` (dev) and `signified.eiluz.com` (current production host) origins. `*.vercel.app` previews SHALL be 403'd. `CHAT_API_SECRET` is **dropped** (reclassified per D-208) — never read in code; not enforced; the placeholder may remain in `.env.example` but is not required.

*Updated 2026-04-24 per D-208. Supersedes the earlier `signified.ai` + REQUIRED-secret framing.*

### Requirement: Compass Collaborator integration

Every Compass window SHALL expose a Compass Collaborator button on its **front face** (per D-190 universal placement). The button is the same compass-symbol used everywhere else on the interface; "Assistant" and "Collaborator" are synonyms — standardize on "Collaborator" in prose. "Assistant Compass" remains the name of a Collaborator hosted on a Compass window. See `compass-collaborator/spec.md`.

*Updated 2026-04-24 per D-190.*

### Requirement: Assistant Compass

An Assistant Compass SHALL be the name of a Compass Collaborator hosted on a Compass window (D-170 IN MVP). Same code path as every other Collaborator (per DC-11).
