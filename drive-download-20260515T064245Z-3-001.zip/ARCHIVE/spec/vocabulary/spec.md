# Vocabulary — canonical ontology

## Purpose

Vocabulary SHALL be the single source of truth for what each load-bearing term in the signified interface means. Every spec, proposal, change, or agent must check here before naming any domain concept. Shape/type mismatches are load-bearing — surface them, do not work around.

## Architectural principle

> "A system of hierarchies that balance each other out in order to determine functions."

Context flows across the interface as a network — Signified + context hierarchies + connections + frames are one system. Every capability that touches any of them must respect that it plugs into this balancing network.

## Requirements

### Requirement: Field

The Field SHALL be the 2D canvas/workspace — a spatial surface with pan and zoom, populated with windows and objects, framed by frames, linked by connections. Multiple fields may exist; saving one produces a project. A field has camera state (pan + zoom).

#### Scenario: Naming surface
- **WHEN** a spec or component references the main workspace
- **THEN** the term SHALL be "field"
- **AND** "canvas" is acceptable only as a rendering-primitive synonym (the `<canvas>` element / HTML canvas API)

### Requirement: Field entity — Windows vs Objects

Field entities SHALL be partitioned into two kinds per v2 drop (2026-04-20):
- **Windows** — pages, tool windows, compass windows. Primary working surfaces.
- **Objects** — images and boxes. Smaller, more passive items.

Frames and connections are NOT field entities; they are their own categories.

#### Scenario: Applying the union term
- **WHEN** referring to the union of windows and objects
- **THEN** prefer "field entity"
- **AND** "object" as a blanket union term is legacy — avoid in new docs except where it reads cleanly

### Requirement: Project is a saved desk

A project SHALL be a saved field — the complete state of a field including its entities, frames, connections, camera state, plus interface-memory "desk" state (selection, focus, scroll, signify-open set).

A project is NOT a field entity.

### Requirement: Deprecated terms

The following terms SHALL NOT appear in new docs, new code, or new decisions:
- **Space** / **SPACE_COLORS** — DEPRECATED. No more spaces.
- **Backlinks** — KILLED. Subsumed by Connections slot of context hierarchy.
- **Backside hedge** — RENAMED to **Temporary warning** (image-backside disclaimer).
- **Smoke** (frame / connection aesthetic) — KILLED. Aesthetic walk owed.
- **Audience Finder** — UI label RENAMED to **Audience** (code identifier `audienceFinder` may stay until migration pass).
- **Direction** (as the textarea-primitive name) — RENAMED to **Signified** app-wide (per D-188, ratified by D-212). All consumers — `vocabulary/spec.md`, `context-direction/spec.md`, every downstream spec, all Shared/SCB component files, Palette/Audience search wire, tool windows, Compass window, frame definition field — reference the Signified primitive going forward. Phase 1 Block A vocabulary rename queue items are unblocked. "Direction" survives only as the name of the connection-flow code field (and that field itself renames to `flowMode` per D-203 / D-215).
- **Dialog** (preset tool name) — RENAMED back to **Dialogue** per D-193.
- **claude** (Compass base-prompt selector option) — RENAMED to **classic** per D-192.

*Updated 2026-04-24 per D-188 / D-192 / D-193 / D-203.*

### Requirement: Rename SCB → Signified primitive; keep "signify window" back-face name (supersedes D-186 D-2)

The codebase SHALL rename:
- "SCB" → **Signified** (UI label and primitive name; code identifier `SCB` may persist until migration pass). Alt label: "signified box."
- The `signify` slot kind in `ContextSourceType` and the context hierarchy → `signified` (per D-188 cascade); see `context-direction/spec.md`.

The back-face / meaning-layer reveal SHALL keep its existing name — **signify window** (retained per D-213). It is NOT renamed to "Context" — "context" is overloaded across the codebase (context hierarchy, context payload, context builder) and a rename would collide. This overrides the D-186 D-2 "signify → Context" half.

The semiotic term **Signified** intentionally collapses with the primitive name: "Signified" does double duty as (a) the meaning-layer half of the Signifier/Signified pair and (b) the canonical textarea primitive. This is load-bearing.

Legacy aliases SHALL remain recognized in source docs until the rename packet lands.

#### Scenario: Authoring a new spec
- **WHEN** a spec references the meaning-layer reveal of a field entity
- **THEN** the term SHALL be "signify window" (NOT "Context")
- **AND** the textarea primitive SHALL be called "Signified" (not "SCB", not "Direction")

#### Canonical clarification (Lukas, 2026-04-25, verbatim)

> "signify window" -- the window that accompanies every field entity; "signified" -- the text box with universal read and buttons (save/reset/lock). "SCB" and "Direction" -- outdated terms for "signified"

*Updated 2026-04-25 with verbatim air-clearing from Lukas. Updated 2026-04-24 per D-188 (overrides D-186 D-2 partial).*

### Requirement: Frame

A Frame SHALL be a visual container on the field representing an epistemic frame (epistemic "context"). A frame:
- groups entities via **citizenship** (entities belong to frames that contain them)
- **modifies** the items within it
- plays a major role in **connections**
- has a color from the 8 warm swatches (D-159, default `rgb(140,115,70)`)
- has a **priority rank** (D-152)
- renders **citizenship rings** on each member entity, inside-out by priority (D-156), at a zoom-adaptive band width (D-154/155/157)

Frames are controlled from the **Frame window** (bottom pull-up panel), NOT via a Context / signify window.

### Requirement: Connection

A Connection SHALL be a directed or bidirectional functional relationship between two field entities. Its primary job is to control **context flow (data access)** between endpoints. Three direction options: `A→B`, `B→A`, `A↔B`.

Compass windows and tools interact with their counterparts by pulling context via connections; Signified + context hierarchies are the balancing mechanism.

This is the most important feature of the entire interface.

### Requirement: signify window contents

The signify window of a field entity SHALL be the back-face / meaning-layer reveal — the "signified" face. ("signify window" is the surface name; the textarea primitive that lives inside it is the **Signified**.)

Universal contents on every signify-window surface (per M1):
- **Signified** (the canonical textarea primitive)
- **Context hierarchy**

Non-tool / non-compass entities additionally carry:
- **Title slot** (text + image; boxes exempt — a box IS its own title)
- **`+` metadata affordance** (slides out; items click-to-add or drag-to-add; metadata routes into the `content` slot of the context hierarchy, NOT the `signified` slot — see `context-direction/spec.md`)

Tool + Compass windows' signify face SHALL use the **split-signified shell** (per D-191): TOP half empty (user Signified), BOTTOM half default system-prompt description. Reset-base affects bottom half only. There is no separate "Settings" block on Compass; the Compass base-selector and Collaborator button live on the front face of the window, not inside the signify-window slot list.

Compass signify window additionally carries:
- **System-prompt base selector** — options `compass` / `classic` (per D-192; "claude" renamed to "classic")

Frames do NOT have a signify window — frame settings live in the Frame window (D-166).

*Updated 2026-04-24 per D-188 / D-191 / D-192.*

### Requirement: Signified (canonical textarea) — three controls

Signified SHALL be the canonical textarea primitive inside a signify window. THREE controls (reduced from five per D-189):
1. **Folder** — save / load / delete / reorder of `savedItems`
2. **Reset** — optional `ResetDefault` dropdown (preset tools + Compass base only)
3. **Lock** — visual indicator that the user's input is in use (NOT an edit-prevention switch)

KILLED (no longer present):
- **Help** — replaced by Compass Collaborator (which surfaces help inline wherever the user is)
- **Validation error** — killed outright; if validation surfacing is needed it routes through the Collaborator popout

Reads on the **universal-read** basis (see next requirement). Primary signified-authoring surface for an entity — what the user writes becomes the entity's contribution to context flow through connections.

*Updated 2026-04-24 per D-188 (rename) and D-189 (control reduction). Supersedes D-186 five-control spec.*

### Requirement: Universal read (AI-driven Signified semantic routing)

Universal read SHALL be the AI-driven semantic interpretation of Signified contents at runtime. The AI decides whether user text in a Signified is:
- **Context payload** to include in downstream prompts, OR
- **Instructions for system-prompt modification**

This mechanism is what makes Signified unified across all entity kinds. UNRESOLVED — research owed before dependent work can close.

*Updated 2026-04-24 per D-188 (rename Direction → Signified).*

### Requirement: Context hierarchy

A Context hierarchy SHALL be an ordered list inside each signify window (and each frame settings, and global interface settings) that determines how the entity's available context sources weigh and feed downstream.

Base slots per M1: **signified** (= Signified textarea read), **content** (= primary entity text + metadata "+" items + title), **frame**, **connection**, **sequencing**.

The list is dynamic, not fixed — multiple frames add multiple frame slots; multiple connections add multiple connection slots. The architecture is a network of hierarchies that balance each other across connected entities; the whole network determines which context reaches any given AI call. Hierarchies exist because prompts have a context budget.

Drag-and-drop reorderable with iOS-home-screen physics. Default order from the user's global interface-settings hierarchy; per-window overrides killed for MVP per D-186 D-3.

*Updated 2026-04-24 per D-188 (slot rename `signify` → `signified`; metadata routes through `content` slot, not `signified`).*

### Requirement: Signifier / Signified (namesake)

The app's namesake semiotic pair SHALL be preserved:
- **Signifier** = front face — what's readable at-a-glance (document text, box text, tool/compass chrome).
- **Signified** = meaning layer — the entity's role, context, interpretation as the user set it (Signified textarea contents, context hierarchy, metadata, connections, frame citizenship).

Flip animation bridges the two; the Context is the signified face.

### Requirement: Palette (surface)

The Palette SHALL be the left side panel with two modes per v2 drop:
- **SEARCH** (bar at top) — palette search. Extras strip: `recs` toggle + `api` icon tray. The search bar is a plain input (per D-201; the prior "search bar IS a Signified" requirement was killed — conversational interpretation moved to Compass Collaborator).
- **COLLECTION** (bar at bottom) — user's cross-project saved items. Selection exposes four actions: Delete / Add to field / Populate recs / View signified.

### Requirement: Audience

Audience SHALL be a pre-field entity parallel to a palette item, but for target-receivers rather than reference material. An audience represents an **opportunity** — a person, community, scene, or platform. Sourced from audience search.

Lives in the Audience region of the Projects panel (right side panel, top bar). UI label is "Audience" (not "Audience Finder"). When promoted to the field, it becomes a field entity with origin tag `"audience"` and inherits the full Context vocabulary.

### Requirement: Panel symmetry

Left (Palette) and Right (Projects) panels SHALL share the primitive `[switch | bar | compass]`. Handedness mirrors — Palette: switch left edge / compass right; Projects: compass left / switch right. Compass buttons always face inward to the field.

Modes per panel:
- **Palette:** top bar = SEARCH (palette search), bottom bar = COLLECTION
- **Projects:** top bar = AUDIENCE search, bottom bar = LIST of saved projects

Both top-bar search surfaces are search-only. Conversational / vague-query interpretation is handled by the Compass Collaborator on each panel (per D-200 / D-201). The prior "fall back to AI chat with its own system prompt" wiring is killed.

*Updated 2026-04-24 per D-200 / D-201.*

### Requirement: Tool window

A Tool window SHALL be a field entity representing a callable tool (distinct from Compass). Its signify window uses the **split-signified shell** (per D-191): TOP half empty (user Signified), BOTTOM half tool's classic base description. Its signify window carries:
- Signified as split-signified shell — user Signified on top, tool base description on bottom (D-191)
- Context hierarchy
- Per-tool additions: Feedback = feedback-type options / Machine = media-type switch (text only for MVP) / Prompt = none / Dialogue = character section (renamed from Dialog per D-193)

The Compass Collaborator button lives on the **front face** of the tool window (per D-190 universal placement), not inside the signify-window slot list.

Custom tools use the same split-signified shell with NO base description and NO Reset-base; user Signified IS the system prompt (universal-read Route B).

*Updated 2026-04-24 per D-188 / D-190 / D-191 / D-193.*

### Requirement: Compass window

A Compass window SHALL be a field entity representing the AI conversation surface. Its signify window uses the **split-signified shell** (per D-191): TOP half empty (user Signified), BOTTOM half default compass base description. Its signify window carries:
- Signified as split-signified shell (TOP user / BOTTOM compass base)
- Context hierarchy
- System-prompt base selector — options `compass` / `classic` (per D-192)

There is NO separate Settings block (per D-191). The Compass Collaborator button lives on the **front face** of the Compass window (per D-190 universal placement), not in the signify-window slot list. The Compass-branded prompt is **FROZEN** per D-161. Streaming responses; silence rule (D-98).

Compass is field-entity-only. The top-level singleton in `packages/app/src/components/Compass.tsx` is legacy — cleanup owed. The always-present edge-of-screen chrome slot is owned by Notifications-as-popout-message (via global top-right Collaborator), not Compass.

*Updated 2026-04-24 per D-188 / D-190 / D-191 / D-192.*

### Requirement: Compass Collaborator

The Compass Collaborator SHALL be the universal side-assistant primitive. Per D-190 it surfaces on **every** signify window, **every** panel (Palette, Projects, settings), the **front face** of every Compass window and every tool window, and the **global top-right** of the interface. Same compass-symbol button across all surfaces.

"**Assistant**" and "**Collaborator**" are synonyms; standardize on "Collaborator" in prose. **Assistant Compass** remains the name of a Collaborator hosted on a Compass window. Same code path, same button.

NO stacking cap (DC-5 killed per D-190). Collaborators open freely. Flipping a host to its signify face does NOT close the Collaborator (DC-6 killed per D-190). Close-with-host strict: host closes → collaborator closes (DC-14 retained).

*Updated 2026-04-24 per D-190.*

### Requirement: Citizenship rings

Frame membership SHALL render visually as thin colored rings around each member entity's bounding box — one ring per frame, color matching the frame. Rings stack inside-out by frame priority (priority-1 innermost). Band width zoom-adaptive via `clamp(6, 14, 10 * zoom)` canvas-constant (D-154). Corner-dot fallback under 120 px min-dim with hover/focus expanding rings (D-155). `pointer-events: none`; 180 ms opacity fade on show/hide; `prefers-reduced-motion` instant branch (D-157). K6: hoverable-only (click passes through).

### Requirement: Temporary warning

Image-based field entities SHALL carry a one-line backside disclaimer: *"field functions read the signified, not the image."* Data-driven via `imageVisionRead` flag. "Temporary" because it disappears once vision-read support lands (post-MVP — see `signified-vision`).

### Requirement: Save slot

The Signified Folder control SHALL save the current Signified text with a title and allow load / delete / reorder. The Folder saves **Signified contents only** (not the base description; for tool/compass windows, the bottom-half base is restored independently via the Reset-base action grouped with the Reset button — never inside the Folder). Semantics per entity kind:
- **Object Signifieds** (files / pages / boxes / palette-items / audiences): saves are independent per entity; each has its own save pool.
- **Tool-window Signifieds**: saves are shared per **tool TYPE** (per D-202; supersedes earlier "shared across all tool windows"). MACHINE windows share one pool, FEEDBACK another, DIALOGUE another, PROMPT another. Custom tools share per custom-tool-definition-id. New tool-window instances always populate with the appropriate base description.
- **Compass Signifieds**: shared across compass windows; new instances always populate with the compass base description.

All saved-slot names SHALL be renamable app-wide.

*Updated 2026-04-24 per D-188 (rename) and D-202 (per-tool-type pool scoping).*

### Requirement: Overlap rules (v2 drop, 2026-04-20)

Stacking invariants SHALL hold on the field:
1. **Contexts (signify windows) and Compass Collaborators always render over everything.** They float, they do not modify or obscure-without-intention.
2. **Contexts and Collaborators never overlap each other.** Adaptive-population engine coordinates placement.
3. **Object-over-window invariant.** Objects (images, boxes) always render over windows (pages, tools, compass). Dragging a window onto an object keeps the object on top.
4. **Drop-in affordance.** Holding an object over a window offers drop-into; behavior varies per window type.
5. **Object-over-object.** Overlapping objects expose user-controlled bring-forward / send-backward.

### Requirement: Adaptive population

The placement engine SHALL keep Contexts, Collaborators, and newly spawned windows/objects from overlapping each other. When multiple candidates compete for the same screen region, the engine picks positions avoiding collision with (a) existing Contexts, (b) existing Collaborators, (c) incoming spawns. Algorithm not yet specified — research track open.

### Requirement: Kaleidoscope

Kaleidoscope SHALL be the part of Settings where the user manages OAuth APIs and configures how APIs are used on the interface. Current MVP API surface: Palette search + Audience (early, free-tier only). Full OAuth batch (Zotero / Perplexity / Are.na / 11 others) deferred to post-MVP — see `signified-vision/openspec/specs/kaleidoscope-oauth/spec.md`.

### Requirement: Notifications

Notifications SHALL surface as popout-message via the global top-right Collaborator (DC-8, DC-10). The standalone notifications popout is killed; `notify()` call sites take a `source: SourceTag` param (DC-9) and route through the Collaborator.

Vocabulary Entry 21 closed per D-185 DC-8.

### Requirement: 3D field — parked vision musing

A 3D field is **parked vision musing**, NOT a real MVP / near-term target. No 3D-field work is scheduled.

*Added 2026-04-24 per D-273.*
