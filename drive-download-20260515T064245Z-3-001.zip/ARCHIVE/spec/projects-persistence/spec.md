# Projects + Persistence (Interface Memory "Desk" model)

## Purpose

A project SHALL be a **saved desk** — not a document. The complete state of a field-as-the-user-left-it, including entities, frames, connections, camera, plus interface-memory state (selection, focus, scroll, signify-open set).

The persistence tier model SHALL handle every local durable state ("everything stays until user changes it") across LS / IDB / cloud.

## Requirements

### Requirement: Three-tier persistence

Persistence SHALL use a three-tier model (D-187 D-BL2-1):
- **LocalStorage** — UI-state cache (fast, ephemeral, re-derivable)
- **Hybrid (LS + IDB)** — content (files, Signified saves, sizeable state)
- **Cloud (Supabase)** — authoritative for projects + user preferences

### Requirement: Projects — cloud-authoritative + LS most-recent-N cache

Projects SHALL be cloud-authoritative (Supabase `user_data`) with a LocalStorage most-recent-N cache for fast open / recent-list (D-187 D-BL2-2).

### Requirement: Audience DB — cloud user-added, local seed

Audience DB SHALL cloud-sync user-added entries (D-187 D-BL2-3). Seed data stays local; user-added entries sync per `user_data` jsonb.

### Requirement: `userStore` extraction (before slot 076c)

A `userStore` SHALL be extracted BEFORE slot 076c ships (D-187 D-BL2-5). Scope:
- `connectedServices`
- global `contextPriority` default

### Requirement: `uiStore` + `signified4_ui` scaffolding

A `uiStore` + `signified4_ui` LS key SHALL consolidate the 16 `App.tsx` `useState` hooks (D-187 D-BL2-4). Scope includes every transient UI state that should persist across reload but NOT across devices.

### Requirement: Signified save-slot Folder CRUD — hybrid for all 7 consumers

The Signified Folder SHALL wire CRUD (save / load / delete / reorder) hybrid-persisted (LS + cloud) for ALL 7 consumers (D-187 D-BL2-6):
- Closes D-119 save-slot-stubbed-across-7-consumers
- Unstubs the save-slot store
- Semantics per entity kind per `vocabulary/spec.md` Requirement "Save slot"
- V11 no-op save-slot code path is killed

### Requirement: Selection in desk snapshot

Project save SHALL capture selection state (D-187 D-BL2-7):
- `selectedIds` (set)
- `focusedFileId`
- `focusedToolId`
- `signifyOpenIds` (set of entities whose Context is currently open)

On project load, selection state restores. "Everything stays until user changes it."

### Requirement: Scroll position capture

Project save SHALL capture scroll positions for scrollable windows. Compass conversation scroll position is first priority (D-187 D-BL2-8).

### Requirement: Quota-full UX

When LocalStorage quota is exceeded, the app SHALL surface a toast AND auto-migrate LS content to IndexedDB (D-187 D-BL2-9). No data loss, no user interruption beyond the toast.

### Requirement: Conflict resolution — implicit last-write-wins

Conflict resolution SHALL be deferred (D-187 D-BL2-10). Last-write-wins is implicit. Collaborative / multi-device sync (D-138) is post-MVP — see `signified-vision/openspec/specs/collaboration-sync/spec.md`.

### Requirement: Projects shape migration

The `projectsStore` SHALL retype from `SignifiedItem[]` to `SavedField[]` (shape: `{ title, id, lastEdited, fullFieldState }`). Supabase `projects` table schema migration follows. `Projects.tsx` row reflects saved-field metadata, not document metadata (Vocabulary Entry 3 cleanup, D-135 round-trip spec updates).

`persistence-supabase.ts` + `SupabaseAdapter` wiring at `main.tsx:17-27` follow.

The user-experience invariant is that **everything the user left is preserved exactly on reload** (selection, focus, scroll, signify-open set, etc.); the `SavedField` shape is an internal representation chosen to uphold that invariant. Per Lukas: "Everything should be saved and remain as it is by the user."

*Updated 2026-04-24 per D-211.*

### Requirement: Slot 076c SavedField migration

Slot 076c SHALL land the SavedField persistence migration. Blocked on Phase 1 stores (userStore + uiStore + slot model) landing first.

### Requirement: Cleanup (persistence-adjacent)

The following persistence-adjacent cleanups SHALL ship:
- Exclude `ToolWindow.compassLoading` from save payload (transient)
- Decide `fieldStore.selectedId` fate (merge into `selectedIds`)
- Delete `signified4_compass` if orphaned (confirm no consumer)

### Requirement: Interface memory prevents regressions

Spec `openspec/specs/projects-persistence/design.md` (or `.claude/specs/interface-memory-desk.md`) SHALL document the interface-memory contract to prevent future ephemeral-useState regressions.

### Requirement: RLS migration 00003 applied before tester touch

Supabase migration `00003_rls_lockdown.sql` SHALL be applied to production before any external tester touches the system. Until applied, any authenticated user can self-promote `membership='active'` via DevTools.

### Requirement: SupabaseAdapter jsonb-per-store

`SupabaseAdapter` SHALL upsert each Zustand store's state as a jsonb blob keyed by `(user_id, store_key)` on every debounced change. On sign-in, the adapter hydrates stores from the last-saved blob.

Desktop uses a parallel `TauriAdapter` that writes to a local file (off by default until Tauri reactivates).

### Requirement: Round-trip verification

The Supabase round-trip (edit → sign out → sign in elsewhere → state restored) SHALL be verified by a dedicated Playwright pass (D-135 approved).

### Requirement: Unsafe coercion removal

`ProjectsPanel` + `store-actions.ts` SHALL have unsafe coercion removed (D-136 approved for build-execute).
