# Audience

## Purpose

Audience SHALL be the epistemic-output counterpart to Palette. Where Palette brings reference material IN (input sources), Audience surfaces OPPORTUNITIES OUT — people, communities, scenes, or platforms where the user's work could surface or matter.

UI label is "Audience" (not "Audience Finder" — renamed per v2 drop).

## Requirements

### Requirement: Lives in Projects panel (right side, top bar)

Audience SHALL live in the AUDIENCE region of the Projects panel — the right-side panel, top bar (per panel-symmetry primitive `[switch | bar | compass]`).

### Requirement: Audience search is search-only (plain input)

The audience search bar SHALL be a plain input — NOT a Signified primitive. No folder, no save-slot pool, no system-prompt mounting. The earlier "search bar IS a Direction/Signified" requirement (D-186 D-16) is **killed**. Conversational interpretation, vague-query handling, and any chat-style fallback are owned by the **Compass Collaborator** on the Projects panel. Search remains search.

*Updated 2026-04-24 per D-200 (ratified by D-233). Supersedes D-186 D-16 for audience.*

### Requirement: Audience seed categories (MVP)

The MVP audience surface SHALL draw from seed data across these categories (`packages/app/src/lib/audience-seed/`):
- anthologies / art / theater / etc. (16 seed files total)

Audience sources additionally feed from **Kaleidoscope** — Kaleidoscope connections are a live input source for audience discovery (per D-235). User-connected APIs (the same set Kaleidoscope tracks for palette search) contribute to audience discovery, subject to the external-integration research mission. Kaleidoscope is a cross-interface setting (per D-201); audience is one of its surfacings/consumers.

The seed-category breakdown is **deferred pending external-integration research** — the file structure may compress, expand, or be replaced by dynamic source discovery per MCP / API / file / URL connectors (see `signified-vision/openspec/specs/external-integration/spec.md`).

*Updated 2026-04-24 per Lukas A "audience seed categories" + D-201 (Kaleidoscope cross-interface scope) + D-235 (Kaleidoscope feeds audience discovery).*

### Requirement: Audience matching — search-by-default; matching engages on user designation

Audience defaults to **plain search behavior** — typing in the bar performs a search.

Matching against field content engages **only** when the user explicitly invokes one of two paths:
- **(a) Compass Collaborator** — user invokes the Collaborator on the audience surface to interpret intent, OR
- **(b) Selected entity match** — user selects specific field object(s) / window(s) and asks "find an audience for these"

There is **no always-on background matching** — the audience matcher does NOT scan the full field unprompted. Phase 1 audience scope work re-targets to these two invocation paths.

D-129's seed-data match still runs (against the user's typed query); the change is that field-content matching is gated on explicit user designation.

*Updated 2026-04-24 per D-234. Supersedes prior framing of audience matching as always-on with restricted entity-kind scope.*

### Requirement: Audience Lane G scrape + opportunities

Audience Lane G SHALL be in MVP scope (D-130): scrape pipeline + opportunities table + Vercel cron. Design work owed.

### Requirement: Bottom-half-of-Projects layout

The Audience bottom-half-of-Projects layout (#72) SHALL be in MVP scope ASAP (D-131); design pending.

### Requirement: Audience as field entity

When the user promotes an audience to the field, it SHALL become a field entity with:
- full signify-window vocabulary (Signified + context hierarchy + title slot + `+` metadata affordance)
- visual treatment as "OPPORTUNITY" (per `CollapsedFileIcon.tsx` heuristic)
- default spawn size 300×200 screen-px (D-126, interim text-era)

The `origin` tag (e.g. `"audience"`) is no longer a first-class dedicated field — it lives as one of the **`+` metadata options** alongside other metadata items. The dedicated `itemOrigin` field is **deprecated**; `+` metadata options gain an audience-origin entry. UI branching that was previously keyed off `origin: "audience"` SHALL pull from `+` metadata going forward.

*Updated 2026-04-24 per D-236.*

### Requirement: Audience chat fallback — KILLED

The audience AI-chat fallback is **killed** per D-200. Audience search remains a search surface only. Conversational / vague-query interpretation is owned by the **Compass Collaborator** on the Projects panel. The audience-specific "own system prompt" path is dropped.

*Killed 2026-04-24 per D-200.*

### Requirement: MenuBar audience button — KILLED

The audience button on the field MenuBar is **killed** per D-200. Audience is reached **only** via the Projects panel's AUDIENCE region; there is no MenuBar audience entry point.

*Killed 2026-04-24 per D-200. Supersedes D-128 placement intent.*

### Requirement: Tsc schema-drift bugs fixed; remove `@ts-nocheck`

Audience `AudienceFinderResults.tsx` tsc schema-drift bugs (D-127) SHALL be fixed as approved for build-execute.

Additionally, `@ts-nocheck` SHALL be removed from `AudienceFinder.tsx` / now `Audience.tsx`; run `pnpm -w exec tsc --noEmit`; fix surfaced schema-drift errors (Phase 1 item 25).

*Updated 2026-04-24 per D-237.*

### Requirement: Vercel cron pipeline for audience refresh — ship now

`apps/web/api/audience-refresh.ts` + `vercel.json` `crons` block SHALL ship now. Audience opportunity refresh runs on cron schedule. Polish later.

*Added 2026-04-24 per D-238.*

### Requirement: EILUZ email submission deferred

Audience `#68 EILUZ` email submission (D-132) SHALL be deferred post-MVP — see `signified-vision/openspec/specs/eiluz-email-submission/spec.md`.
