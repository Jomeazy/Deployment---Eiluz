# Field Canvas

## Purpose

The Field Canvas SHALL be the 2D spatial workspace where all signified activity happens — pan, zoom, spawn, selection, camera state — a surface populated by windows, objects, frames, and connections.

## Requirements

### Requirement: Pan and zoom

The field SHALL support pan (translate) and zoom (scale) as continuous camera operations.

Zoom range: `0.25×–4×` (reaffirmed D-105), enforced by user-resize guardrail.

#### Scenario: Panning the field
- **WHEN** the user drags empty field, or uses modifier-drag, or trackpad-pan
- **THEN** the camera translates continuously
- **AND** all entities / frames / connections translate together

#### Scenario: Zooming the field
- **WHEN** the user scrolls (no modifier), pinch-zooms, or uses zoom shortcut
- **THEN** the camera scales between 0.25 and 4
- **AND** zoom centers on cursor position
- **AND** the zoom-level indicator updates (D-65)

### Requirement: Adaptive spawn — hybrid cascade reset

Spawn placement SHALL use a **hybrid cascade reset** rule (D-106, supersedes D-83).

Cascade state lives in `field.ts` with `cascadeState`, `resetCascade()`, `advanceCascade()`. Placement is routed through `place-new-object.ts` via `nextSlot(trigger)`. Existing spawn handlers MUST NOT hold a module-level counter.

Cascade resets under ANY of these triggers:
- **Time** — 500 ms since last spawn
- **Pan** — 80 px of pan movement
- **Zoom** — one zoom tick
- **Escape** keypress
- **Empty field** — no entities present

#### Scenario: Rapid sequential spawn
- **WHEN** the user adds three entities within 500 ms with no pan or zoom
- **THEN** each entity spawns stepped from the prior by the kind's cascade step
- **AND** the cascade sequence does NOT reset between them

#### Scenario: Cascade reset on pan
- **WHEN** the user pans more than 80 px between spawns
- **THEN** the cascade state resets
- **AND** the next spawn starts at the default slot, not continuing the prior cascade

### Requirement: Cascade step per kind

Cascade step SHALL be kind-aware via `cascadeStepForKind` in `place-new-object.ts` (D-108):
- **box / source / tool / audience / compass** = 24 screen-px
- **page** = 96 screen-px

### Requirement: Spawn sizes — canvas default + screen floor

Entity spawn sizes SHALL use hybrid policy: canvas default + enforced screen-space floor (D-93, reaffirmed by D-112).

- `CANVAS_DEFAULTS[box]` = 300×300 (square) / `SCREEN_FLOORS[box]` = 260×260
- `CANVAS_DEFAULTS[page]` = 720×960 (Letter-ish) / live-resize floor 200×200
- `FileWindow.tsx` clamp SHALL be kind-aware
- `file-handlers-spawn.ts` SHALL migrate to `placeNewObject`

Design rule: **boxes square, pages Letter-ish**.

### Requirement: Camera on spawn — zoom-to-legibility-floor

Spawning an entity SHALL zoom the camera to a legibility floor when needed so the new entity is legible (D-96). Shift held at spawn opts out (D-97).

### Requirement: Per-page Ctrl-scroll coupling

Pages (and only pages) SHALL expose a per-page Ctrl-scroll coupling gated on focus + cursor-in-window (D-101). Other entity kinds do NOT participate.

### Requirement: Box auto-grow

Box entities SHALL auto-grow when text content exceeds current bounds (per D-263). Auto-grow extends **down and right**; the top-left corner stays fixed. 4-corner `growAnchor` and `2.5× height` width floor (D-110 / D-111) are deferred post-MVP.

*Updated 2026-04-24 per D-263. Supersedes D-110 / D-111 (deferred).*

### Requirement: Resize handle hit-area

Resize handle hit-area SHALL clamp to a hybrid with screen-floor 6 px / screen-cap 14 px (D-99, reaffirmed by D-264).

### Requirement: Adaptive-population for signify-window / Collaborator / spawn

The adaptive-population engine SHALL avoid overlap between (a) open signify windows, (b) open Collaborators, and (c) incoming new spawns (D-184 + Vocabulary Entry 27).

Joints (D-184):
- **J1** — signify window stays fullscreen modal (no re-flow needed)
- **J2** — last-arrived candidate moves when two would overlap
- **J3** — Collaborator open/closed state persisted; position re-derived from host
- **J4** — Collaborator is a transient overlay, NOT a field entity for overlap-rule-3
- **J5** — tie-break order: S3 > S1 > S2 (screen-space-most-available > current-slot > kind-preferred)
- **J6** — off-screen S3 handled by stacking cap (NOTE: stacking cap killed per D-190; collaborators open freely — overflow handling design-pending)

A first-pass algorithm SHALL ship now and iterate from real-use feedback (per D-265). The D-82 research mission re-scopes from gate to iteration-input — research informs refinement after first-pass ships, not a precondition.

*Updated 2026-04-24 per D-188 (signify-window terminology) / D-190 (stacking-cap kill flag) / D-265 (first-pass-then-iterate; supersedes D-82 research-first framing).*

### Requirement: Focus ring (screen-space)

Focus ring SHALL render in screen space via `filter: drop-shadow()` (D-133), not canvas-space, so it remains constant thickness under zoom.

### Requirement: Minimap

The field SHALL expose a minimap with a draggable viewport rect (D-146). Dragging the rect pans the main camera.

### Requirement: Context menu (hover-reveal)

Hovering a field entity SHALL expose the canonical menu (positioned familiarly to other desktop / canvas apps). Three universal options for **every** entity kind:
- **Signify** (unified — flip to signify face)
- **Collapse / Expand**
- **Delete**

Right-click is no longer the canonical trigger. Duplicate / Frame / Download / per-kind tier-2 entries are **set aside** until explicitly re-opened by Lukas.

*Updated 2026-04-24 per D-197. Supersedes D-20 right-click canonical menu.*

### Requirement: Snap alignment guides

Snap SHALL expose alignment guides during drag + resize (D-53). Primary edges / centers / gutters highlight when another entity's edge or center aligns within threshold.

### Requirement: Canvas virtualization deferred post-MVP

Canvas virtualization (BL-4) SHALL stay deferred post-MVP; revisit only when perf is felt under real use.

*Added 2026-04-24 per D-262 (ratifies D-84 deferral).*

### Requirement: Empty-state — blank white

An empty field SHALL render **blank white**. No warm-gray palette, no serif descriptions, no "add a page or text to begin" copy. A toggle for a help / about overlay MAY remain, but NOT as an empty-field-specific affordance.

*Updated 2026-04-24 per D-198. Supersedes D-24.*
