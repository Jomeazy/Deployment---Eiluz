# Compass Collaborator

## Purpose

The Compass Collaborator SHALL be the **universal** side-assistant primitive (per D-190). It surfaces almost everywhere on the interface: every signify window, every panel (Palette, Projects, settings), the front face of every Compass window, the front face of every tool window, and the global top-right of the screen. Same compass-symbol button across all surfaces. One primitive, many hosts. Subsumes the standalone notifications popout, the troubleshoot popout, and the killed Help control on the Signified primitive (per D-189).

"Assistant" and "Collaborator" are synonyms. Standardize on "Collaborator" in prose. "Assistant Compass" remains the name of a Collaborator hosted on a Compass window.

## Requirements

### Requirement: Primitive + Assistant Compass naming

The Collaborator SHALL be the primitive (DC-11). An **Assistant Compass** is the name of a Collaborator hosted on a Compass window. Same code path, same button. "Assistant" == "Collaborator" — standardize on Collaborator in prose.

*Updated 2026-04-24 per D-190.*

### Requirement: DC-1 — consolidate = field edit + pinned transcript

Collaborator consolidate SHALL merge its memory into the host by:
- appending to the host's field-level edit context
- pinning a transcript reference on the host

### Requirement: DC-2 — custom tool promote

On a custom Tool window, the Collaborator SHALL offer "revise then promote to definition" — the user refines in the Collaborator, then promotes the refined state to the custom tool's definition.

### Requirement: DC-3 — Compass window consolidate = mergeBack only

On a Compass window, the Collaborator consolidate action SHALL be `mergeBack` only (no alternate modes for MVP).

### Requirement: DC-4 — signify-face scope (file entities) + front-face on tool/compass + universal expansion

The signify face SHALL host a Collaborator button on every file-entity signify window (boxes, pages, images). Tool and Compass entities expose their Collaborator button on the FRONT face. In addition (per D-190), the Collaborator surfaces on every panel (Palette, Projects, settings, audience, interface settings) and at the global top-right of the screen.

Exact button placement on each surface is design-pending (pending Impeccable audit).

*Updated 2026-04-24 per D-190.*

### Requirement: DC-5 — KILLED (no stacking cap)

The 3-hard stacking cap is **killed** per D-190 (ratified by D-221: "no cap"). Collaborators open freely; no count limit. The compact-icon-strip fallback is dropped.

Overlap rule #2 ("Collaborators don't overlap Collaborators") applies without numeric cap.

*Killed 2026-04-24 per D-190 / D-221. Supersedes earlier "DC-5 = 3 hard + compact strip" requirement.*

### Requirement: DC-6 — KILLED (signify flip does NOT close Collaborator)

The flip-close behavior is **killed** per D-190. When the user flips a host to its signify face, any Collaborator hosted on that entity SHALL stay open.

*Killed 2026-04-24 per D-190. Supersedes earlier "signify flip closes Collaborator" requirement.*

### Requirement: DC-7 — Collaborator placement is an aesthetic-audit call

Collaborator placement / population surfaces SHALL be **aesthetic-pass concerns**, not now-decisions. Per Lukas: "this distinction is just about where the collaborator populates, which should be in the hands of the aesthetic decisions."

The hybrid routing question for Direction/Signified helptext (inline for Floating Signs / Manifesto / Compass base vs Collaborator popout elsewhere) is reframed: the Phase 4 Impeccable / aesthetic audit owns Collaborator placement design. DC-7 hybrid routing is NOT finalized as a product-spec rule; it is treated as a visual-design output.

The popout IS the Collaborator — there is NO separate MiniCompass primitive. The standalone "Help" control on the Signified primitive is killed (per D-189) — Collaborator replaces it.

Validation does NOT route to the Collaborator popout — validation is folded into the Lock control's visual state on the Signified primitive (per D-219).

A running inventory (see Requirement "Surface inventory") tracks the locations the audit considers.

*Updated 2026-04-24 per D-189 / D-190 / D-219 / D-222 (Collaborator placement is aesthetic-audit call). Supersedes prior DC-7 hybrid-routing-as-now-decision framing.*

### Requirement: Surface inventory (dedicated file)

A running inventory of three surface classes SHALL live in a **dedicated file**: `spec/specs/compass-collaborator/surface-inventory.md` (new file owed; D-223 ratified).

The inventory tracks:
1. **Collaborator locations** — every place the compass-symbol Collaborator button surfaces
2. **signify-window locations** — every place a signify window can open
3. **Context-hierarchy locations** — every place the context-hierarchy renders (per `context-direction/spec.md` Requirement "Dynamic slot model")

The inventory is a living document; updated as new surfaces are added. It is a **prerequisite for the four-chart charter** (D-274) — chart 3 (Signified location) and chart 2 (Collaborator location) overlap directly.

Phase 1 item 77 produces this file.

*Updated 2026-04-24 per D-190 / D-223.*

### Requirement: DC-8 + DC-9 — Notifications-as-popout-message

Notifications SHALL surface as popout-messages via the global top-right Collaborator (DC-8). This supersedes the standalone notifications popout framing (D-145 killed).

`notify()` call sites (16 known) SHALL take a `source: SourceTag` param (DC-9) so the Collaborator can route to the appropriate host or the global top-right when no host is specified.

Vocabulary Entry 21 closes — Notifications = messages surfaced by appropriate popout Compass.

### Requirement: DC-10 — global Collaborator = top-right universal history

A global Collaborator SHALL live in the top-right of the screen as the universal notification history. User clicks to open the full history of Notifications / Collaborator output across all hosts.

### Requirement: DC-12 — Collaborators inherit universal interface settings

Collaborators SHALL **abide by universal settings** configured globally in interface settings. Per Lukas: "collaborates should abide by universal settings that we put in the interface settings."

- NO per-Collaborator settings UI is built.
- Collaborators do NOT inherit from frame-level defaults.
- Interface settings panel gains a Collaborator settings section.

*Updated 2026-04-24 per D-224. Supersedes prior DC-12 framing (Q13 default was "frame-level inherit"; Lukas chose universal interface-settings inheritance instead).*

### Requirement: DC-13 — KILLED (frame definition is direct Signified, no clarifying-question scaffold)

The clarifying-question model in frame settings is **killed** per D-196. Frame definition is authored **directly** via the shared Signified primitive — no Manifesto-anchored clarifying-question scaffolding, no "what is this frame's purpose?" prompt. See `frames/spec.md` Requirement "Frame definition (direct Signified)."

*Killed 2026-04-24 per D-196. Supersedes D-185 DC-13.*

### Requirement: DC-14 — close-with-host strict (flip does NOT close)

When a host window closes, every Collaborator hosted on it SHALL close. Strict: no orphan Collaborators.

NOTE: **Flipping** a host to its signify face does NOT close the Collaborator (DC-6 killed per D-190). Only host *closure* triggers close-with-host.

*Updated 2026-04-24 per D-190 (clarification of flip vs close).*

### Requirement: DC-15 — blocks on `uiStore` extraction

Collaborator build SHALL be blocked on `uiStore` + `signified4_ui` extraction (per projects-persistence/spec.md D-BL2-4). Build order:
1. `userStore` extraction
2. `uiStore` scaffolding
3. D-100 interim save-button removal (DC-16 isolated)
4. Mission H streaming PRs 1-3
5. D-109 context rule patch
6. Collaborator button extract across 6 surfaces
7. Collaborator core component
8. Consolidate handlers
9. Notifications migration (DC-8 + DC-9)
10. Assistant Compass finalize

### Requirement: DC-16 — D-100 save-button removal isolated

D-100 interim save-button removal SHALL ship as an isolated packet — separate from the Collaborator packet (DC-16).

### Requirement: Search parent conversation (Assistant Compass scope)

An Assistant Compass SHALL be able to search the parent Compass's conversation — find a specific earlier message without disrupting the main chat flow. (Current code at `packages/app/src/components/tools/CompassParentConversation.tsx` is a seed — collapsible inline panel; full side-extend chrome + search + two-way dialogue + consolidate is not yet built.)

### Requirement: Two-way dialogue

Two open Collaborators SHALL be able to optionally "see each other" and converse.

### Requirement: Consolidate memory

At the end of a session, the user SHALL be able to merge the memory of two Compasses (host + Collaborator) into one, or pick a part of one to fold into the other.

### Requirement: Collaborator is a transient overlay (not a field entity)

Per D-184 J4, the Collaborator SHALL be a transient overlay — NOT a field entity for overlap-rule-3 (object-over-window invariant). The Collaborator is in the "floats over everything with no obscure" class alongside Contexts.

### Requirement: Validation never routes to Collaborator (Lock-as-validator)

Validation surfacing on the Signified primitive SHALL **never** route to the Collaborator popout. Validation is folded into the **Lock control's visual state** on the Signified primitive itself (e.g., locked + green outline = valid; visual treatment pending aesthetic audit).

There is no Validation popout, no validation-to-Collaborator handoff, and no separate Validation control. See `context-direction/spec.md` Requirement "Lock control dual-purposes as validation indicator" for the canonical definition.

*Added 2026-04-24 per D-219.*

### Requirement: Chain legibility folded into Phase 4 connections aesthetic

Chain legibility surfaces (Inspector, staleness indicator, CONNECTIONS header for tool-chain context) SHALL be folded into the Phase 4 connections aesthetic pass and designed in concert with connection visuals — NOT shipped as a separate now-build through the Collaborator (per D-252).

See `tool-system/spec.md` Requirement "Chain legibility — folded into Phase 4 connections aesthetic pass."

*Added 2026-04-24 per D-252.*

### Requirement: Open walkthrough items

Open questions 1-8 from `.claude/specs/compass-collaborator.md` consolidation doc SHALL be resolved at variation-sheet stage per aesthetic-tight-loop rule (not front-loaded into this spec).
