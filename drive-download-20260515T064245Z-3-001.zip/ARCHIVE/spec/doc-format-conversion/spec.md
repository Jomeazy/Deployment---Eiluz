# Doc Format Conversion + Export

## Purpose

Doc Format Conversion SHALL let the user reformat page-like content between supported format presets (APA / MLA / Chicago / screenplay / playwriting / plain) with clear UX around lossy conversions. Export SHALL produce correctly-formatted output with citation wiring.

## Requirements

### Requirement: Full format matrix (D-181 Q1)

Conversion SHALL support (D-181 Q1 ratified):
- **Same-family** conversions (APA ↔ MLA ↔ Chicago): SHIP
- **Screenplay ↔ Playwriting**: SHIP
- **Cross-family**: REFUSE with explicit user message
- **Box / imported PDF / DOCX**: via-edit column only (not direct conversion)

Supersedes D-165 (narrower matrix).

### Requirement: In-place preset-picker prompt (D-181 Q2)

When the user requests in-place reformatting, the preset-picker SHALL show three options:
- **[Convert in sibling]** — spawn a sibling entity with the new format, preserving the original (default, per D-181 Q3)
- **[Convert in place]** — overwrite current entity
- **[Just switch preset]** — change format tag without reformatting content

### Requirement: Sibling default (D-181 Q3)

Default conversion action SHALL be "Convert in sibling" (D-181 Q3). Matches D-113's Edit-as-Doc / Edit-PDF sibling pattern.

### Requirement: PageFormat extended to 6 values (D-181 Q4)

`PageFormat` type SHALL be extended to 6 values (D-181 Q4):
- `apa` / `mla` / `chicago` / `screenplay` / `playwriting` / `plain`

Screenplay + playwriting become first-class (read Fountain AST).

### Requirement: MD → Page gated on D-115

Markdown → Page conversion SHALL be gated on D-115 install approval (remark + rehype + unified toolchain; D-181 Q5). Auto-fallback to defer if install slips.

### Requirement: Box + PDF / DOCX via Edit-as-Doc (D-181 Q6)

Box entities + imported PDF / DOCX SHALL route conversion via the Edit-as-Doc column (D-181 Q6). Subsumes under Edit-as-Doc flow.

### Requirement: `format-convert.ts` module

A new module SHALL ship: `packages/app/src/lib/format-convert.ts`. Houses:
- Conversion routing logic (matrix per Q1)
- Sibling spawn wiring
- Never-refusal whitelist enforcement

### Requirement: `format-presets.ts` extended to 6 values

`packages/app/src/lib/format-presets.ts` SHALL extend to the 6 PageFormat values.

### Requirement: Reversible `reformat()` in `cite-format.ts`

`reformat()` in `packages/app/src/lib/cite-format.ts` SHALL be reversible within a family (e.g., APA → MLA → APA yields the same canonical output).

### Requirement: Preset-picker UI

A new preset-picker UI component SHALL surface the three options from Q2 when the user triggers in-place reformatting.

### Requirement: Tests — ship-cells + never-refusals

Test coverage SHALL include:
- **Ship-cells** — positive cases per Q1 matrix (same-family + screenplay↔playwriting convert successfully)
- **Never-refusals** — negative cases (cross-family refuses with the explicit message, no silent garbage output)

### Requirement: Citation formatting at export (D-142a)

Export SHALL format citations at export-time per the entity's citation data (D-142 part a, BL-1 approved for build).

Touches:
- `packages/app/src/lib/cite-format.ts`
- `packages/app/src/lib/export.ts`
- `packages/app/src/lib/to-html.ts`

### Requirement: Per-object export matrix (D-31, expanded by D-271)

Per-object Page export SHALL produce type-aware downloads. Available export formats:
- **Spec format presets** — plain / APA / MLA / Chicago / screenplay / playwriting (per `PageFormat`)
- **HTML**
- **PDF**
- Markdown
- plain text
- `.doc` (HTML fallback)
- binary passthrough for sources

HTML and PDF remain available as page export options alongside the spec format set. `export.ts` `getFormatsFor` and `ActionButtons.tsx` SHALL be reconciled to the expanded set (Phase 1 item 60).

*Updated 2026-04-24 per D-271. Supersedes prior "remove HTML + PDF; UI matches spec" framing.*

### Requirement: Edit-as-Doc only for PDFs (MVP scope)

PDF entities SHALL ship with **Edit-as-Doc only** for MVP — convert to editable document format.

**Edit-PDF** (in-place annotation / fillable fields / markup) is deferred post-MVP. PDF library pick (pdfjs-dist annotation editor vs alt) remains a Phase 5 dev hand-off when Edit-PDF is reopened.

*Updated 2026-04-24 per D-245. Supersedes D-113 two-button framing for MVP.*

### Requirement: DOCX view fidelity via docx-preview (D-114)

DOCX entities SHALL view via `docx-preview@0.3.7` (install approved per D-114).

### Requirement: Markdown toolchain swap (D-115)

Markdown SHALL swap from `marked` → `remark + rehype + plugins` toolchain (D-115 approved). Gates MD→Page conversion.

### Requirement: Scanned PDF without OCR (D-116)

Scanned PDFs without OCR text SHALL render via canvas with a banner offering an OCR affordance (D-116).

### Requirement: Export markdown detail — KILLED WITHOUT PREJUDICE

D-143 "markdown detail (C-6)" is killed without prejudice. Original intent unrecoverable; export-markdown path already works in code; carrying an ambiguous PENDING entry was decision-log noise.

Re-open only if a concrete need (frontmatter handling, heading-level granularity, or other) surfaces with a real use case.

*Updated 2026-04-24 per D-272. Supersedes D-143 PENDING status.*

### Requirement: TipTap per-format presets

Each of the 6 `PageFormat` values SHALL map to a TipTap per-format preset in `apps/web` / `packages/app` TipTap config. Preset defines typography, spacing, heading levels, citation style.

### Requirement: Project-level export deferred

Project-level export (#86 per D-137) SHALL be deferred post-MVP — see `signified-vision/openspec/specs/project-export/spec.md` (to be created alongside vision specs).
