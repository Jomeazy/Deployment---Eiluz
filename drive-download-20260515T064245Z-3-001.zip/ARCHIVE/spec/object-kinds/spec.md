# Object Kinds

## Purpose

Object Kinds SHALL enumerate the field entity kinds, their spawn defaults, their per-kind Context contents, and per-kind interaction rules.

"Object" here is used in the legacy blanket sense (= union of windows + objects per v2 vocabulary). Prefer "field entity" where it reads cleanly.

## Requirements

### Requirement: The seven kinds

Field entity kinds SHALL be (revised per D-194 — "Source" killed; PDF/DOCX/MD/.doc are all Pages; Image is its own kind):
- **Box** — object (small, passive, text-primary; a box IS its own title)
- **Page** — window (primary writing surface; TipTap + per-format presets). PDF / DOCX / MD / .doc imports are all Pages — format differs only at export.
- **Clip** — object (URL-fetched snippet via `api/clip.ts`)
- **Image** — object (raster/vector image; see image-specific rules)
- **Audience** — object (pre-field entity promoted to field; origin metadata under `+`, not first-class tag)
- **Tool window** — window (preset tools MACHINE / FEEDBACK / DIALOGUE / PROMPT + Custom; renamed from DIALOG per D-193)
- **Compass window** — window (AI conversation surface)

The `TextFile` discriminator in `packages/core/src/types.ts` SHALL reflect this seven-kind taxonomy.

Frames and connections are NOT entities.

*Updated 2026-04-24 per D-193 / D-194 (ratified by D-242).*

### Requirement: Spawn defaults (canvas + screen floor)

Per field-canvas/spec.md Requirement "Spawn sizes":
- `box` = 300×300 canvas / 260×260 screen floor
- `page` = 720×960 canvas / 200×200 screen floor (covers PDF / DOCX / MD / .doc imports — all Pages per D-194)
- `clip` = box-like default
- `audience` = 300×200 landscape card (D-126)
- `tool` / `compass` = per-tool defaults (to be specified per tool)

(`source` removed — Source is no longer a kind per D-194.)

These ship as **starting numbers, not final** (per D-243). The demo run is the trigger to revisit any number that feels wrong; "demo-revisit" is the next checkpoint.

*Updated 2026-04-24 per D-194 / D-243.*

### Requirement: Every non-frame entity has a signify window

Every field entity EXCEPT a frame SHALL have a signify window (back-face / meaning-layer reveal). Frame settings live in the Frame window (D-166), not a signify window.

#### Scenario: Flipping to signify window
- **WHEN** the user triggers Signify on any field entity
- **THEN** the entity flips to its signify face
- **AND** the signify-window contents follow the per-kind requirements below

*Updated 2026-04-24 per D-188.*

### Requirement: Universal signify-window contents

Every signify window SHALL include:
- **Signified** (canonical textarea primitive — three controls per D-189)
- **Context hierarchy**

See `context-direction/spec.md` for the full Signified + hierarchy spec.

Every signify window AND every panel additionally hosts a **Compass Collaborator button** (universal per D-190); on tool/compass windows the button lives on the front face per `compass-collaborator/spec.md` DC-4.

*Updated 2026-04-24 per D-188 / D-190.*

### Requirement: Non-tool / non-compass signify-window additions

Non-tool / non-compass signify windows SHALL additionally include:
- **Title slot** (text + image; boxes exempt — a box IS its own title)
- **`+` metadata affordance** (slides out; items click-to-add or drag-to-add; metadata routes through the `content` slot of the context hierarchy per D-188)

*Updated 2026-04-24 per D-188.*

### Requirement: Tool window signify-window additions (split-signified shell)

Tool windows SHALL use the **split-signified shell** in their signify window (per D-191):
- **TOP half empty** — user Signified
- **BOTTOM half** — tool's classic base description (rendered from `tool-descriptions.ts`; not sent to model)
- **Reset-base** action restores ONLY the bottom half; lives grouped with the Reset button (NOT inside Folder; per D-189 / D-191)
- **Context hierarchy**
- **Per-tool additions:**
  - **MACHINE** — media-type segmented control (order: **text > image > video > audio**; text enabled; image/audio/video "coming soon") (D-183 local D-7)
  - **FEEDBACK** — section-filter chips (D-183 local D-4); dual-mode (window-mode + inline) per D-182 TP-5
  - **DIALOGUE** — character section `{name, era?, mode?, firstPersonRegister?}` (D-182 TP-7); body bar moves into signify window with label `context:` (D-183 local D-5; renamed per D-193)
  - **PROMPT** — no additions beyond universal + split-signified shell

The Compass Collaborator button is on the **front face** of the tool window (per D-190 universal placement), not inside the signify-window slot list.

*Updated 2026-04-24 per D-188 / D-190 / D-191 / D-193 / D-194.*

### Requirement: Custom tool signify-window

Custom tools SHALL use the same split-signified shell with:
- NO base description (user Signified IS the system prompt via universal-read Route B)
- NO Reset-base action

Custom-tool Signified saves SHALL share the same save-slot pool as preset-tool Signified saves of their tool-type; pools are per-custom-tool-definition-id (per D-202). All Signified save slots are renamable app-wide.

*Updated 2026-04-24 per D-188 / D-191 / D-202.*

### Requirement: Compass window signify-window additions

Compass windows SHALL use the **split-signified shell** in their signify window (per D-191):
- **TOP half empty** — user Signified
- **BOTTOM half** — default compass base description
- **System-prompt base selector** — options `compass` / `classic` (renamed from `claude` per D-192)
- **Context hierarchy**

There is **NO separate Settings block** (per D-191). The Compass Collaborator button is on the **front face** of the Compass window (per D-190), not inside the signify-window slot list. One Signified is sufficient (universal-read subsumes the prior "additional SCB for system prompt").

*Updated 2026-04-24 per D-188 / D-190 / D-191 / D-192.*

### Requirement: Box signifier transparency

Box entities' signifier face SHALL be transparent over the field (D-60 keeps radius 0px; design rule "a box IS its own title").

### Requirement: Image entity — Temporary warning (gated on vision-read test)

A vision-read test SHALL run against `/api/chat` first to confirm Claude vision is actually insufficient before adding the Temporary warning disclaimer.

If the test confirms vision is insufficient, image entities SHALL carry a one-line disclaimer on the back face: *"field functions read the signified, not the image."* Data-driven via `imageVisionRead` flag. Disappears once vision-read lands (post-MVP; see `signified-vision`).

If the test shows vision is sufficient, the disclaimer does NOT ship.

*Updated 2026-04-24 per D-244.*

### Requirement: PDF Page entity — Edit-as-Doc only (MVP)

PDF Pages (no longer "Source entities" — Source kind is killed per D-194) SHALL expose **Edit-as-Doc only** for MVP — converts to editable document format.

**Edit-PDF** (PDF-native in-place annotation / fillable fields / markup) is deferred post-MVP. PDF library pick (pdfjs-dist annotation editor vs alt) remains a Phase 5 dev hand-off when Edit-PDF is reopened.

DOCX Pages view uses `docx-preview` (D-114, install approved). DOCX, MD, and .doc are also Pages per D-194.

Scanned PDFs without OCR SHALL render via canvas with a banner offering an OCR affordance (D-116).

*Updated 2026-04-24 per D-194 / D-245. Supersedes D-113 two-button framing for MVP.*

### Requirement: Collapsed icon formula

Collapsed entity icons SHALL use the adaptive-spawn collapsed-icon overlay formula (D-104 reaffirms D-33 unchanged). Collapsed-icon strokes render in warm gray per D-21.

### Requirement: Kept image editor

Of the four "medium editors" addressed in D-40, only **ImageEditor** SHALL be kept. AudioEditor / VideoEditor / ScreenwritingEditor are orphan-deleted in the cleanup commit.

### Requirement: Tool kinds MVP batch (D-141 / D-183)

The MVP tool batch SHALL ship T-1, T-2, T-3, T-4:
- **T-1 MACHINE** — media-type conversion (text enabled)
- **T-2 FEEDBACK** — section-filter-chip feedback
- **T-3 DIALOGUE** — conversational character tool (absolutely necessary per D-141; renamed from DIALOG per D-193)
- **T-4 PROMPT** — prompt-template tool
- **Custom** — user-authored tool via Tool Creator
- **Tool Creator** — 4-pack hardening (streaming + three-tier parser + 4/4 progress + name-collision warn + Playwright) per D-183 local D-11

Tool-Signified save-slot pools SHALL be **per tool TYPE** (per D-202; supersedes D-183 local D-12 "shared across all tool windows"). MACHINE / FEEDBACK / DIALOGUE / PROMPT each have their own shared pool. Custom tools share per custom-tool-definition-id. All save-slot names are renamable app-wide.

*Updated 2026-04-24 per D-193 / D-202.*

### Requirement: Tool chaining

Tool chaining SHALL use strategy research landed at `.claude/research/custom-tool-chaining/strategy.md` (D-172 closed). Chain legibility: inspector + staleness + CONNECTIONS header (D-183 local D-13). Chain depth: user-controlled, unlimited (D-172). Interim (TP-8): Option A — passive last-output + prompts-only + Mission G inspector + staleness flag.
