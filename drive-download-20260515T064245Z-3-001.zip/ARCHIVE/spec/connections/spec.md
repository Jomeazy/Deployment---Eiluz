# Connections

## Purpose

Connections SHALL be directed or bidirectional functional relationships between two field entities. Their primary job is to control **context flow (data access)** between endpoints. This is the most important feature of the entire interface.

## Requirements

### Requirement: Three direction modes

Every Connection SHALL expose three direction options:
- **A→B** — A feeds context to B only
- **B→A** — B feeds context to A only
- **A↔B** — bidirectional exchange

User picks the direction on creation; direction is editable later.

### Requirement: Connection determines context flow

Compass windows, Tool windows, and Assistant Compass SHALL pull context from their connected counterparts according to the connection's `flowMode`. **Signifieds** (the textarea contents on each endpoint) participate in context-flow resolution alongside `flowMode`, context hierarchies, and frame citizenship — the four together form the balancing network that determines what context actually reaches any given AI call.

*Updated 2026-04-24 per D-188 / D-203. Signified added as a flow-resolution input per Lukas A.2.*

### Requirement: ObjectConnection flow-mode field renamed (collision fix)

`ObjectConnection.direction` (code field — the arrow direction A→B / B→A / A↔B) SHALL be renamed to **`flowMode`** to avoid collision with the canonical textarea primitive that was renamed Direction → Signified per D-188. (The textarea primitive UI label is "Signified"; the connection code field UI/data label is "flow mode.")

Touches: `types.ts`, `context.ts`, `tool-context-helpers.ts`, `canonical-connection.ts`, every `buildContext` emit.

*Updated 2026-04-24 per D-203 (concretized by D-215). Supersedes the earlier "ObjectConnection.direction distinct from Direction primitive" framing.*

### Requirement: Connection visuals communicate direction (multi-strand-as-dimensions KILLED)

The multi-strand-as-context-dimensions metaphor is **killed**. Connection visuals SHALL communicate **direction** (one-way A→B / B→A / bidirectional A↔B) — not strand-count-to-context-dimension mapping.

Bidirectionality MAY render as two opposite-direction strands; specific visual realization is an aesthetic call deferred to impeccable audit. Strand-count semantics are removed from spec — strands no longer correspond to "context dimensions."

*Updated 2026-04-24 per D-230. Supersedes P-09 / D-57 multi-strand-dimensions framing.*

### Requirement: No aesthetic locked in (deferred)

The visual treatment of connections SHALL be deferred to impeccable aesthetic audit. "Smoke" as a connection aesthetic is KILLED. Flow animation (D-177 / D-178 / D-179 / D-180) belongs to the audit — see `aesthetic/spec.md`.

### Requirement: Connection Smoke dead code removed

`ConnectionSmoke` and any "smoke" CSS artifact SHALL be removed (D-58). Frame-selection `.frame-selection` CSS gradient artifact that introduced the term SHALL be revised in the impeccable walk.

### Requirement: Compass sees connection context (BL-3 fix)

`buildContext()` in `packages/core/src/context.ts` SHALL include:
- `ObjectConnections`
- `flowMode` per connection
- `contextPriority` per slot
- `FieldFrame` citizenship data

BL-3 fix — prior state: `buildContext()` ignored these; Compass couldn't see them.

### Requirement: Connection flow modes align between Tools and Compass

Connection flow modes SHALL be aligned — Tools and Compass use the same direction semantics and the same context pull logic. Prior state: flow modes implemented for Tools but not Compass.

### Requirement: Conditional connections deferred — gated on chart

Conditional connections (#63 per D-85) SHALL be deferred post-MVP — see `signified-vision/openspec/specs/conditional-connections/spec.md`.

The conditional-connections decision is additionally gated on the **connection-possibilities-and-functions chart** (per D-274 chart 1). The chart enumerates what kinds of connections exist and what each does; conditional-connection scope reopens once the chart lands.

*Updated 2026-04-24 per D-231 (extends D-85 deferral with chart gate).*

### Requirement: Connection endpoint is a field entity

Both endpoints SHALL be field entities (windows OR objects). Frames are NOT endpoints. A connection endpoint cannot be another connection.

### Requirement: Connection is NOT a field entity

A Connection SHALL be its own primitive — not a field entity. Overlap rules (Vocabulary Entry 26) apply to windows/objects, not to connections.

### Requirement: `canonical-connection.ts` is the canonical rendering module

`packages/app/src/components/canonical-connection.ts` SHALL be the **canonical rendering module** for connections. The data model is **`ObjectConnection`** in `packages/core/src/types.ts` — the two are distinct layers:
- **Data model** — `ObjectConnection` in `types.ts` (`flowMode`, endpoints, etc.)
- **Canonical rendering module** — `canonical-connection.ts` (visual rendering hand-off; subject to aesthetic deferral)

`ConnectionFlow.tsx` handles rendering invocation (subject to aesthetic deferral).

*Updated 2026-04-24 per D-232 (disambiguates the two layers).*

### Requirement: Neighbor-signified context flow — local + connection-triggered

Signifieds (the textarea contents on each endpoint) SHALL operate **locally** by default — each entity's signified is read into its own context, not auto-flattened into neighbors.

A connection MAY specify a **functional relationship** that triggers cross-use of the connected entities' signifieds. When connected objects are considered together (e.g., by Compass), their signifieds are read as **separate-but-linked** — distinct items annotated with the connection metadata. They are NOT merged into a single combined stream.

`buildContext()` SHALL NOT auto-flatten neighbor signifieds into the active entity's context. Compass prompt formatting represents linked signifieds as distinct items with connection metadata.

The connection-functional-relationship spec needs definition; this overlaps with **D-274 chart 1** (connection possibilities and their functions).

*Added 2026-04-24 per D-256. Supersedes prior "yes, neighbor signified flows through" framing.*
