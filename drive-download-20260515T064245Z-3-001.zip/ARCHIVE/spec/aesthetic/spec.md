# Aesthetic Rules

## Purpose

The Aesthetic Rules SHALL define the warm gray token system, color palette, motion grammar, ring-band geometry, and connection-flow animation. Most aesthetic work runs through the **impeccable aesthetic audit** — a variation-sheets + minute-scale-loops + smallest-unit-commits process, not a front-loaded spec.

## Requirements

### Requirement: Warm gray design system

The app SHALL use a warm gray design system. No cream / gold regressions on any surface unless the surface explicitly requires accent gold (per Mission L default frame color).

### Requirement: Token migration to @theme

All design tokens SHALL migrate to the Tailwind v4 `@theme` block at `packages/app/src/index.css` (D-7 / D-8). `@theme` already exists with `--font-*` and `--color-*` tokens. Migration is incremental — files that get touched for other work migrate their inline values to token reads (D-8 standing rule, not a queueable build).

### Requirement: Object states

Field entity state styling SHALL follow D-21 (deferred to aesthetic walkthrough for verification):
- radius = 3 px (design rule, except boxes per D-60 = 0 px)
- focus ring = warm gray (screen-space via `filter: drop-shadow()` per D-133)
- flipped-side "keeps current" treatment (no cream/gold regression)
- collapsed-icon strokes = warm gray

### Requirement: Panel treatments

Per D-22:
- **FrameStrip** = warm gray treatment
- **Compass / Footer / FrameOverlay** = keep current panel treatment

### Requirement: Auth + Settings surfaces

Per D-23:
- Warm token migration
- White backgrounds
- NO cream

### Requirement: Canvas empty-state

Canvas empty-state SHALL follow D-24:
- toggle UI
- serif descriptions

### Requirement: Ring-band geometry (Mission K, deferred to impeccable)

Ring-band per Frames spec SHALL use:
- **K1** 10 px band width (canvas-constant, zoom-clamped `clamp(6, 14, 10*zoom)`)
- **K2** `+N` badge for frame overflow count (override of dedupe-first)
- **K3** full band, no adaptation (collapsed icons render full 10 px)
- **K4** 0.5 px universal hairline between ring pairs
- **K5** clamp `10*zoom` clamped canvas-constant
- **K6** hoverable-only (click passes through rings to entity)
- **K7** add/remove: 180 ms opacity fade; `prefers-reduced-motion` uses instant branch
- **K8** deferred to Mission A (adaptive-width fallback)

D-154 / D-155 / D-157 / D-173 all deferred to impeccable aesthetic audit.

### Requirement: Mission L — frame colors (deferred to impeccable)

Per D-159:
- Palette V2 — 8 warm-dominant swatches
- Default V1 warm gold `rgb(140,115,70)`
- Picker V1 geometry + custom-RGB "+" escape pulled into MVP (PR-6)
- Custom-RGB panel UX details = follow-up walk (impeccable audit sub-item)

### Requirement: Mission A — signify surface (deferred to impeccable)

Per D-160 partial picks:
- **D-M2** metadata-panel side-slide from right (changes TBD)
- **D-M4** `rotateX` flip axis with spring overshoot (replaces `rotateY` baseline) per D-86
- **D-M7** sheet-03 is outdated — refresh owed
- Open: D-M1 / M3 / M5 / M6 / M10, type-flex variants, K8

Deferred to impeccable aesthetic audit.

### Requirement: Connection flow animation (deferred to impeccable)

Connection flow animation per D-177 / D-178 / D-179 / D-180:
- **D-177** spec saved verbatim at `.claude/specs/connection-flow-animation.md`; broken into 7 pieces
- **D-178** P2 steady-state: bezier drift / amp 6 / speed 0.6 Hz / period 2 / warm gray
- **D-179** P3 establish: parallel / ease-in-out / 600 ms / cross-fade / soft fade
- **D-180** bidirectional = two copies of unidirectional flow

Deferred to impeccable aesthetic audit (subsumes the earlier handoff-bidirectional.md brief).

### Requirement: Card radius policy

Card (= file / box / page / tool / compass frame) radius SHALL remain 0 px (D-60). Box-specific "a box IS its own title" design rule enforces this.

### Requirement: Gear icon keyframes

Per D-67 approved. Gear icon has keyframed motion on hover / active states.

### Requirement: Settings panel visibility

Per D-68 — settings panel must not be invisible. Approved visibility fix.

### Requirement: A11y — unlabeled buttons

Per D-69 — remaining 5 axe button-name violations SHALL be fixed. MVP partial a11y (D-149) — WCAG partial scope.

### Requirement: Font picker

Per D-66 — option A but expanded family list.

### Requirement: Zoom level indicator

Per D-65 — on-screen zoom level indicator present.

### Requirement: Interface-v2 drop deferred

The 2026-04-20-interface-v2-drop spec SHALL be deferred to impeccable aesthetic audit (interface-v2 is UI/interaction work, not declarative behavior).

### Requirement: D-M2 metadata off-page deferred

`research/d-m2-metadata-off-page-spec` folds into D-160 Mission A aesthetic bundle, deferred to impeccable.

### Requirement: Impeccable aesthetic audit process

Aesthetic work SHALL run through the impeccable audit:
- Variation sheets (dense, multi-variation, NOT sparse single files)
- Minute-scale loops
- Smallest-unit commits
- Trivial reverts
- NO comprehensive plans
- Every aesthetic decision is tied to the function it expresses

Mockup deliverables SHALL isolate concrete decisions from exploratory variants — decisions disappear into visual noise otherwise.

### Requirement: Killed aesthetic items

- **"Smoke" (frame + connection aesthetic)** — KILLED 2026-04-20. Frame visual needs a richer direction than the current two-line treatment — aesthetic walk owed.
- **Back-face paper texture** (D-92) — KILLED.
- **Slide-in menubar** (#113 + #161 per D-144) — KILLED.
- **Conversation sequence toggle** (#171 per D-102) — KILLED.
