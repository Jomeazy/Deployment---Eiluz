# Context + Signified (dynamic-slot hierarchy)

## Purpose

Context + Signified SHALL be the core mechanism by which every field entity contributes meaning to AI calls. Signified is the canonical textarea primitive where the user writes (renamed from "Direction" per D-188). The signify window is the back-face surface where the Signified lives. The context hierarchy is the prioritization network that decides what reaches any given AI prompt.

This is the most load-bearing subsystem in the product. D-186 (local D-1..D-20) is the prior pass; D-188 / D-189 / D-191 / D-204 update the primitive name, control set, shell shape, and frame tie-break model.

## Requirements

### Requirement: Signified primitive — three controls (Folder / Reset / Lock)

Every Signified instance SHALL carry exactly THREE controls (reduced from five per D-189, ratified by D-218):
1. **Folder** — save / load / delete / reorder of `savedItems`
2. **Reset** — with optional `ResetDefault` dropdown (preset tools + Compass base only); the Reset-base action lives here, grouped with Reset (NOT inside Folder)
3. **Lock** — dual-purpose: lock state + validation indicator

KILLED:
- **Help** — replaced by Compass Collaborator (which surfaces help inline via the Collaborator primitive on every signify window and panel; D-190)
- **Validation error** — no separate Validation control. Validation is **folded into the Lock control's visual state**, not killed outright (per D-219).

SCB.tsx + ~11 consumers strip the Help button.

*Updated 2026-04-24 per D-188 / D-189 / D-218 (ratifies). Supersedes D-186 five-control spec.*

### Requirement: Lock control dual-purposes as validation indicator

The Lock control SHALL double as the validity signal for the Signified input. Its visual state communicates whether the input is valid (e.g., locked + green outline = valid). There is **no separate Validation control**, and validation **never** routes to the Collaborator popout.

The specific visual treatment of the valid / invalid state is an aesthetic-audit call. Aesthetic audit owes a visual treatment for the valid / invalid state of Lock, on top of locked / unlocked.

*Added 2026-04-24 per D-219. Supersedes the portion of O-2 that read "Validation error killed outright" — validation is folded into Lock visual state, not killed.*

### Requirement: Universal Signified across entities (one primitive everywhere)

Every entity signify window (non-frame) SHALL use a single shared Signified component — NOT per-kind bespoke textareas (D-17 / D-73 independence constraint, ratified by D-254). One textarea primitive used everywhere; not per-kind custom. Foundational, already implied by Q1 + Q7.

*Updated 2026-04-24 per D-188 (rename Direction → Signified) / D-254 (universal primitive ratified).*

### Requirement: Dynamic slot model

The context hierarchy SHALL be a dynamic `{kind, refId}[]` list per entity (D-186 D-1), NOT a fixed 5-tuple. This replaces the `store-invariants.spec.ts:116-123` 5-tuple enforcement.

Base slot kinds (per D-188 rename of slot kind `signify` → `signified`, concretized by D-214):
- **signified** — Signified textarea read only (the canonical primitive's contents). The slot kind in `ContextSourceType` + `buildContext` hierarchy + emits is `signified` (renamed from `signify`); affects `packages/core/src/types.ts`, `packages/core/src/context.ts`.
- **content** — the entity's primary text content + metadata "+" items + title (metadata routes here, NOT into `signified`, per D-188)
- **frame** — per frame the entity is a citizen of (one slot per frame; ordered)
- **connection** — per connection the entity is an endpoint of (one slot per connection; ordered)

Additional slots under D-186:
- **sequencing** — promoted to canonical (D-186 D-11)

Context-hierarchy SURFACES enumerated (per D-188 / Lukas A5):
- (a) every signify window on field
- (b) every frame settings (in the Frame window — frames have no signify window)
- (c) global, in interface settings

Items-per-hierarchy vary by what AI can consider as context for/from/to the host.

*Updated 2026-04-24 per D-188 (slot rename + metadata routing + surface enumeration).*

### Requirement: Per-entity context priority override (load-bearing)

Each entity SHALL define **its own context priority order** — per-entity override is the load-bearing model. Single global priority is NOT the rule.

Interface settings MAY host a global default (in `userStore`), but the per-entity override on the entity itself takes precedence. This aligns with O-17 / D-204 (frame tie-break via per-object context-hierarchy ordering): per-object context-priority storage extends `FieldFrame` priority + per-object Context hierarchy ordering.

Phase 1 item 16 revises: userStore holds the default; the per-entity override lives on the entity.

*Updated 2026-04-24 per D-261. Supersedes D-186 D-3 ("kill per-object override; single global default applies") and prior "single global priority" framing of Q50 default.*

### Requirement: Compass Signified-read slot

Compass SHALL read its own Signified via the `signified` slot (D-186 D-4, renamed per D-188), not a separate `compassNotes` path. Dead `CompassNotes` system-prompt append removed (D-186 D-9, slot 093). Dead `ToolWindow.compassNotes` deleted (D-186 D-10).

*Updated 2026-04-24 per D-188.*

### Requirement: Manifesto + Floating Signs treated as signified content

Manifesto and Floating Signs SHALL be treated as **signified content** (not a separate slot type). They live in the `signified` slot like every other Signified instance, scoped to user-level. They are **one-of-each** (no save-pool, no `savedItems` participation).

*Updated 2026-04-24 per D-188 / D-255 (treated as signified content, one-of-each at user-level). Supersedes D-186 D-5 + D-186 D-19.*

### Requirement: Neighbor-Signified context wire

`ConnectedFileContext.signifyText` SHALL be wired as a live dead-wire fix (D-186 D-8) — neighboring connected entities' Signified text feeds the current entity's connection slot context.

*Updated 2026-04-24 per D-188.*

### Requirement: Keep Compass keyword-gating

Compass keyword-gating SHALL stay (D-186 D-7). Gating logic in `compass-reply.ts` is retained. See `compass/spec.md` for the rebuild details (D-227).

### Requirement: Delete dead FrameState shadow stores

Dead `FrameState` shadow / custom stores SHALL be removed (D-186 D-6, ratified by D-258). One frame-state store is correct; duplicate shadow stores are deleted. No hidden per-frame state that duplicates frame store.

Code cleanup pass ships in Phase 1.

*Updated 2026-04-24 per D-258.*

### Requirement: Remove Space type + ContextInput.space

`Space` type, `SPACE_COLORS`, and `ContextInput.space` SHALL be removed from code (D-186 D-12). "Space" is deprecated (Vocabulary Entry 4).

### Requirement: Frame definition uses shared Signified primitive

Frame definition SHALL use the shared Signified component (D-186 D-14, renamed per D-188; ratified by D-259), not a custom textarea. The custom textarea in `FrameDetailView` SHALL be replaced with the shared Signified primitive. Frame definition is authored **directly** via the shared Signified — no clarifying-question scaffold on top (D-196, kills D-185 DC-13).

Phase 1 item 28 unblocked; the `FrameTextBox.tsx` scaffold (Phase 1 item 17) is deleted.

*Updated 2026-04-24 per D-188 / D-196 / D-259.*

### Requirement: BacklinksSection → connections slot

`BacklinksSection` SHALL be deleted (D-186 D-15). Inbound-link context is covered by the `connection` slot. "Backlinks" is a killed term.

### Requirement: Palette + Audience search bars are plain inputs

Palette-search bar and Audience-search bar SHALL be plain inputs (per D-200 / D-201). The earlier "search bar IS a Signified primitive" requirement (D-186 D-16) is **killed** — conversational interpretation is owned by the Compass Collaborator on each panel; search remains search. No Folder, no save-pool, no per-surface system prompt on the search bar itself.

*Updated 2026-04-24 per D-200 / D-201. Supersedes D-186 D-16.*

### Requirement: Frame tie-breaker resolved via per-object context-hierarchy ordering

When multiple frames tie for default context-priority slot, tie-breaking SHALL be expressed through the context hierarchies inside each object's signify window — the user orders frames there, and that ordering resolves the tie implicitly. **No separate tie-break UI at the frame level**; the prior "user pins default frame at conflict-time" prompt is killed.

*Updated 2026-04-24 per D-204. Supersedes D-186 D-17.*

### Requirement: Signified save-slot pool scoping

Save-slot pools SHALL scope as follows (per D-260; extends O-15 / D-202):

- **Entity Signifieds** (boxes, pages, frames, audience, etc.): **per-entity** save slots — each entity has its own slot pool.
- **Tool windows**: **per-tool-type** shared pool — DIALOGUE pool, MACHINE pool, FEEDBACK pool, PROMPT pool. Custom tools share per `custom-tool-definition-id`.
- **Compass windows**: **per-compass-type** shared pool.

Save-slot store schema keys by `(scope, scopeId)` where `scope ∈ {entity, toolType, compassType}`.

Signified Folder SHALL be wired across all consumers (D-186 D-18 + D-187 D-BL2-6, Phase 1 items 53 + signified-primitive save-slot wiring). Closes D-119. The save-slot store ships **now** with cloud-authoritative persistence (LS cache + cloud authoritative); all signified surfaces wire through it. All save-slot names are renamable app-wide.

*Updated 2026-04-24 per D-188 (rename) / D-202 / D-260 (extends pool scoping to per-entity for non-tool/non-compass surfaces and per-compass-type pool).*

### Requirement: Universal-read semantic routing

Signified content SHALL be routed by AI-driven universal-read (see `vocabulary/spec.md` Requirement "Universal read") to either:
- **Route A — context payload** (appended to downstream prompts)
- **Route B — system-prompt modification** (user-authored instructions that tune the entity's AI behavior)

Universal-read implementation is gated on a dedicated research mission. Until it lands, Signified content routes via heuristic or explicit flag.

*Updated 2026-04-24 per D-188.*

### Requirement: Interface Settings walk (scheduled)

Interface Settings — the UI where the user manages global `contextPriority` default, Signified defaults, and hierarchy grammar — SHALL be walked as walk mark #10 (D-186 D-20 + D-185 DC-12). Not yet scoped.

*Updated 2026-04-24 per D-188.*

### Requirement: Context build order

`packages/core/src/context.ts` `buildContext()` SHALL assemble the system-prompt slice in slot order derived from the user's global `contextPriority`, reading from `signified` / `content` / `frame` / `connection` / `sequencing` slots in turn. Context budget truncation applies at the slot-list tail.

*Updated 2026-04-24 per D-188 (slot rename).*

### Requirement: Context emit semantics (spec owed)

After D-186 D-1/D-4/D-5/D-7 land, a dedicated spec `openspec/specs/context-direction/design.md` or `.claude/specs/context-emit-semantics.md` SHALL capture the exact emit format for each slot kind, so implementations across Compass / Tool / Chain agree.
