# Tool System

## Purpose

The Tool System SHALL be the set of preset + custom AI-callable tools the user mounts on the field to transform context through connections. Preset tools: MACHINE / FEEDBACK / DIALOGUE / PROMPT (DIALOG renamed → DIALOGUE per D-193). Plus Custom tools authored via the Tool Creator. Plus tool chaining.

Preset-tool prompts are **live** (not frozen like Compass) per D-182.

## Requirements

### Requirement: MVP batch — T-1..T-4 + Custom + Tool Creator

MVP SHALL ship (D-141 + D-183):
- **T-1 MACHINE** — media-type conversion
- **T-2 FEEDBACK** — section-filter-chip feedback (window + inline modes)
- **T-3 DIALOGUE** — conversational character tool (**absolutely necessary** per D-141; renamed from DIALOG per D-193)
- **T-4 PROMPT** — prompt-template tool
- **Custom** — user-authored tool via Tool Creator
- **Tool Creator** — hardened 4-pack

*Updated 2026-04-24 per D-193 (ratified by D-216).*

### Requirement: DIALOG → DIALOGUE rename (D-216 ratified)

The preset tool DIALOG SHALL be renamed DIALOGUE across:
- user-facing label
- code enum
- prompt key in `lab.ts`
- `tool-window.ts`
- file rename: `DialogWindow.tsx` → `DialogueWindow.tsx`

*Added 2026-04-24 per D-216 (ratifies O-6 / D-193).*

### Requirement: Per-tool prompt addition parked

MVP tool prompts SHALL use **only the 4 shared clauses** (chain / medium / signify / truncation). NO per-tool prompt addition is shipped for MVP.

The per-tool-prompt-addition decision is parked for post-MVP revisit.

*Added 2026-04-24 per D-246.*

### Requirement: Split-signified shell (universal across tool windows + Compass)

Every Tool window's signify-window face SHALL use the **split-signified shell** (per D-191; same shell used on Compass windows):
- TOP half empty — user Signified
- BOTTOM half — tool's classic base description

Base is a basic human-readable description of the tool's system prompt, NOT the raw prompt text. Bottom-half base description is rendered from `tool-descriptions.ts`; this map is NOT sent to the model.

Custom tools use the same shell with NO base description and NO Reset-base (D-183 local D-10).

*Updated 2026-04-24 per D-191. Supersedes D-183 local D-1 "split-with-base, stacked" framing (same shape, generalized to "split-signified shell").*

### Requirement: Reset-base grouped with Reset button (NOT inside Folder)

Reset-base SHALL live grouped with the **Reset** button on the Signified primitive (per D-189 control set + Lukas A8 clarification) — restores the bottom-half base, NOT the user top-half. Reset-base is the only mode-specific control. The Folder control saves Signified contents only (not the base).

*Updated 2026-04-24 per D-189 / D-191. Supersedes D-183 local D-3 "inside SCB Reset ResetDefault dropdown" framing (same affordance, clarified placement: with Reset button, not inside Folder).*

### Requirement: Tool base descriptions (Claude drafts, Lukas approves once)

Per-tool base descriptions SHALL be drafted by Claude (4 descriptions for T-1..T-4), approved by Lukas once (D-183 local D-2). **Content drop owed.**

A separate `tool-descriptions.ts` map SHALL render on the Signified bottom-half; this map is NOT sent to the model (D-182 TP-2).

### Requirement: DP-01 — Machine shared clauses

MACHINE prompts SHALL include shared clauses (D-182 TP-4) across chain / medium / signify / truncation, conditional and inert when not applicable.

### Requirement: DP-02 — Feedback dual-mode

Feedback SHALL ship dual-mode (D-182 TP-5):
- **window mode** — opens as a Tool window
- **inline mode** — DP-02-inline, later, gated on Mission G

### Requirement: DP-03 — Dialogue variant E

Dialogue SHALL use variant E (D-182 TP-9):
- asterisk-wrap guidance for action / thought
- 4 shared clauses
- preserve "a bird does not use words" verbatim clause

*Updated 2026-04-24 per D-193 (DIALOG → DIALOGUE) / D-247 (variant E ships as described).*

### Requirement: DP-04 — Custom scaffold + Tool Creator hardening

A new `custom-scaffold.ts` SHALL wrap custom prompts via `wrapCustomPrompt` (D-182 TP-3). `CustomToolWindow.tsx:27` SHALL switch to this scaffold.

Tool Creator hardening 4-pack (D-183 local D-11, D-182 TP-11):
- Streaming swap (Anthropic streaming API)
- Three-tier parser (name / description / body, robust to partial streams)
- 4/4 progress indicator
- Name-collision warn
- Playwright coverage

### Requirement: DP-05a — PROMPT dead-code cull

The PROMPT tool SHALL have dead-code removed (D-182 TP-10). Any-time, unblocked.

### Requirement: TP-1 — Retire LAB_SYSTEM.feedback dead code

`LAB_SYSTEM.feedback` dead code INSIDE `lab.ts` prompt SHALL be retired (D-182 TP-1). Compatible with Lab-folder un-kill — this is DEAD PROMPT TEXT inside the prompt file, not the Lab UI.

### Requirement: TP-6 — Feedback-type as conditional parameter (single template)

Feedback tool SHALL use a **single template with a type parameter** (D-182 TP-6, ratified by D-248). The hard-coded list of feedback types (STRUCTURE / LANGUAGE / GAPS / ...) is dropped. Feedback type is a conditional parameter on the one prompt template, not per-type prompt variants.

**Content drop owed from Lukas: feedback-type values for the type parameter.**

*Updated 2026-04-24 per D-248.*

### Requirement: TP-7 — Dialogue character shape

Dialogue character SHALL be shaped `{ name, era?, mode?, firstPersonRegister? }` (D-182 TP-7, approved by D-249). Dialogue tool consumers use this shape.

*Updated 2026-04-24 per D-193 / D-249.*

### Requirement: TP-8 — Chain architecture (Option A passive lastOutput + staleness)

Chain architecture MVP SHALL use **Option A** (D-182 TP-8, ratified by D-250):
- Passive `lastOutput` per ToolWindow
- Prompts-only (no fork intermediate artifacts)
- Staleness flag when inputs drifted
- Inspector deferred (visual surfaces folded into Phase 4 connections aesthetic per D-252)

*Updated 2026-04-24 per D-250.*

### Requirement: TP-12 — Goldenfile + Playwright discipline (adopted)

`lab.ts` / `tool-creator.ts` / `custom-scaffold.ts` SHALL maintain **goldenfile tests + Playwright coverage** (D-182 TP-12, adopted by D-251). Any prompt-text change updates the goldenfile AND gets a Playwright scenario. Test discipline is locked across tool-prompt evolution.

*Updated 2026-04-24 per D-251.*

### Requirement: D-1..D-15 local tools-project picks

Ratified in D-183 (2026-04-21); updates noted per D-189 / D-191 / D-193 / D-202:
- **D-1** split-with-base = stacked → reframed as **split-signified shell** (same shape) per D-191
- **D-2** Claude drafts 4 base-descriptions, Lukas approves once
- **D-3** Reset-base — moved from "inside SCB Reset ResetDefault dropdown" to **grouped with Reset button** per D-189 / D-191
- **D-4** FEEDBACK section-filter chips only (MVP)
- **D-5** Dialogue body bar → signify window with label `context:` (DIALOG renamed → DIALOGUE per D-193)
- **D-6** character-type = free-text (MVP); picker post-MVP (see `signified-vision/openspec/specs/dialog-character-picker/spec.md`)
- **D-7** MACHINE media-type segmented (text enabled, image/audio/video "coming soon"); order **text > image > video > audio**
- **D-8** MACHINE MEDIUM clause UI-only (MVP)
- **D-9** delete `promptType` + `typeInstruction` (pairs with TP-10a)
- **D-10** custom tool split-signified shell = same shell, no base, no Reset-base
- **D-11** Tool Creator hardening 4-pack
- **D-12** Tool-Signified save-slot pool: now **per tool TYPE** (per D-202; supersedes "shared across all tool windows"). MACHINE / FEEDBACK / DIALOGUE / PROMPT each have their own pool; Custom tools share per custom-tool-definition-id.
- **D-13** chain legibility independent of D-172 (inspector + staleness + CONNECTIONS header)
- **D-14** chain depth unblocks via landed custom-tool-chaining `strategy.md`
- **D-15** inline FEEDBACK `lastOutput` = `one_line` summary (dormant under D-4=A)

*Updated 2026-04-24 per D-189 / D-191 / D-193 / D-202.*

### Requirement: Tools folder (lab dissolved)

The folder is `packages/app/src/components/tools/` (already exists). Legacy `packages/app/src/components/lab/` preset content SHALL be **replaced**: drop the old preset content; keep only the new MACHINE / FEEDBACK / DIALOGUE / PROMPT / Custom / Tool Creator surfaces. The earlier Shape A / Shape B / Lab-rename mini-research mission is **dissolved** per D-199 — the question is answered ("just call it tools, replace old shit").

*Updated 2026-04-24 per D-199. Supersedes prior "Lab folder un-killed, pending rename" requirement.*

### Requirement: Preset-tool prompts are live (not frozen)

Preset-tool prompts (`lab.ts`, `tool-creator.ts`, new `custom-scaffold.ts`) SHALL be tuneable. Compass prompt freeze (D-161) does NOT apply.

### Requirement: Chain depth unlimited (user-controlled)

Custom tool chain depth SHALL be unlimited, user-controlled (D-172). Research landed at `.claude/research/custom-tool-chaining/strategy.md`.

### Requirement: Chain legibility — folded into Phase 4 connections aesthetic pass

Chain legibility surfaces (Inspector panel + Staleness indicator + CONNECTIONS header) SHALL **NOT** ship as a separate now-build. They are folded into the **Phase 4 connections aesthetic work** and designed in concert with connection visuals.

Phase 1 chain-inspector + CONNECTIONS-header work re-scopes to **data-only / behind-flag**; visible surfaces are gated on Phase 4 connection aesthetic. The visual brief for chain legibility owes consistency with the connection visual brief.

*Updated 2026-04-24 per D-252. Supersedes D-183 local D-13 "ship Inspector + staleness + CONNECTIONS header now" framing.*

### Requirement: Tool-Signified save-slot pools — per tool TYPE

Tool-window Signified save slots SHALL use **per-tool-type** pools, not a single global pool. MACHINE windows share one pool; FEEDBACK windows share another; DIALOGUE another; PROMPT another. Custom tools share per custom-tool-definition-id. Active selection (`activeSlotId`) is per-window. All save-slot names are renamable app-wide.

*Updated 2026-04-24 per D-202. Supersedes D-183 local D-12 "shared across all tool windows".*

### Requirement: Golden-path testing

Every tool prompt change SHALL ship with a goldenfile update AND a Playwright scenario (TP-12 discipline).

### Requirement: OQ-1..OQ-8 parked

Orthogonal sub-questions OQ-1..OQ-8 from `.claude/specs/tools-project-consolidation-2026-04-20.md` remain **parked** (per D-253). No build action; they become future walkthrough rows if surfaced.

*Updated 2026-04-24 per D-253.*
