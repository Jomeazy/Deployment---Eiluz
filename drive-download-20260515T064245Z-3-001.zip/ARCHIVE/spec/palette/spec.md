# Palette

## Purpose

The Palette SHALL be the left side panel — the user's entry point for epistemic input. Search external sources, browse saved items, populate recommendations, and drag items onto the field as references.

## Requirements

### Requirement: Two modes — SEARCH (top) and COLLECTION (bottom)

Palette SHALL have two modes per v2 drop (2026-04-20):
- **SEARCH** — bar at TOP. Palette search input.
- **COLLECTION** — bar at BOTTOM. User's cross-project saved items.

Switching is via the left-edge switch (per panel-symmetry primitive `[switch | bar | compass]`).

### Requirement: Palette search is search-only (plain input)

The palette search bar SHALL be a plain input — NOT a Signified primitive. No folder, no save-slot pool, no system-prompt mounting. The earlier "search bar IS a Direction/Signified" requirement (D-186 D-16) is **killed**. Conversational interpretation, vague-query handling, and any chat-style fallback are owned by the **Compass Collaborator** on the Palette panel; users can populate the Collaborator from palette items or queries. Search remains search.

*Updated 2026-04-24 per D-201 (ratified by D-240). Supersedes D-186 D-16.*

### Requirement: SEARCH extras strip — Kaleidoscope clarified

SEARCH mode SHALL expose two extras:
- **recs** toggle (on/off) — enables recommendation mode
- **api** icon tray — horizontal row of API icons; tap toggles whether that logged-in API contributes to search/recs results (colored = on, grayscale = off).

**Kaleidoscope** is a cross-interface setting surface that appears in multiple places on the interface. The SEARCH api icon tray is **ONE** surfacing of that setting — it controls per-API participation in search/recs. Login + per-API Signified (system prompts) live in **global Settings / Kaleidoscope**, NOT in the SEARCH extras strip.

*Updated 2026-04-24 per D-201.*

### Requirement: Six free-tier search providers (MVP scope)

Palette search SHALL integrate 6 free-tier providers for MVP:
- Wikipedia
- Google Books
- OpenAlex
- Discogs (server proxy)
- TMDB
- MusicBrainz

Additional OAuth providers (Zotero / Perplexity / Are.na / 11 others) per D-121 / D-125 are deferred post-MVP — see `signified-vision/openspec/specs/kaleidoscope-oauth/spec.md`.

Search-providers shipped beyond these 6 (crossref / openLibrary / semanticScholar / notion / arena / trakt / lastfm / etc.) are **deferred pending the external-service integration research mission** — see `signified-vision/openspec/specs/external-integration/spec.md`.

### Requirement: Search falls back to Compass Collaborator (NOT chat)

The earlier "search falls back to AI chat" requirement is **killed** per D-201. Palette search remains a search surface only. When a query is vague or the user wants conversational interpretation, the **Compass Collaborator** on the Palette panel handles it; the user can populate the Collaborator from palette items or queries. The palette-search-specific "own system prompt" path is dropped.

*Killed/redirected 2026-04-24 per D-201.*

### Requirement: Recommendations

Palette recommendations SHALL return suggestions based on:
- the user's settings
- whatever the user types
- optionally, any currently-selected field entities (as additional input)

Recs UI wiring SHALL be verified as part of the external-integration research (D-120 / D-124 folded in).

### Requirement: Challenge-based AI recs (deferred)

Challenge-based AI recs (PA-3 per D-120) SHALL be scoped within the external-integration research mission and NOT built until it lands.

### Requirement: Result-card metadata transfer

Metadata from search-result cards SHALL transfer to palette/field entities on drag/add (D-124). Exact transfer matrix deferred to external-integration research.

### Requirement: COLLECTION — cross-project saved items

COLLECTION mode SHALL show the user's cross-project saved items (not just current-project). Items are selectable.

### Requirement: COLLECTION — adaptive action bar

When a COLLECTION item is selected, the bar SHALL become adaptive and expose four actions:
- **Delete** — remove from collection
- **Add to field** — spawn as a field entity
- **Populate recs** — move the item into the Compass Collaborator and switch the panel to SEARCH seeded by that item
- **View signified** — open the entity's default signify window as the user saved it; edits from this surface overwrite the default

*Updated 2026-04-24 per D-188 (terminology).*

### Requirement: COLLECTION recs gesture — right-click "Recommendations"

COLLECTION items SHALL expose a populate-recs gesture via **right-click → "Recommendations"** menu option. Drag-to-search-bar is rejected. Label is the concise "Recommendations" (NOT "Get recs from this").

*Added 2026-04-24 per D-239.*

### Requirement: Palette item (entity)

A Palette item SHALL be an entity sourced from one of the palette-search providers. Lives in either search results or the user's cross-project collection. When dragged to a field, becomes a field entity inheriting the full signify-window vocabulary.

The palette-item / field-entity distinction collapses on drop: once the object is on the field it is a regular field entity; the palette-item shape is no longer referenced.

Images are in scope as palette items.

*Updated 2026-04-24 per Lukas A "palette item" comment + D-188.*

### Requirement: Legacy palette UI deprecated (cleared for deletion)

The following surfaces SHALL NOT be used in new code AND are cleared for deletion (pending import grep): `PaletteSpace.tsx`, `PaletteGrid.tsx`, `PaletteToolbar.tsx`, `PaletteItemExpanded.tsx`, plus orphan tile/menu files (`FolderTile`, `FolderChildTile`, `ItemMenu`, `PlusMenu`, `RecommendationsBar`).

They are outdated pre-v2-drop surfaces. Current palette UI uses `PalettePanel` + `PalettePanelSearch` + `PalettePanelResultItem` + `palettePanelHelpers.ts`.

*Updated 2026-04-24 per Lukas A "legacy palette UI deprecated" comment.*

### Requirement: Fullscreen-expand

Palette panel SHALL support a fullscreen-expand toggle (D-90, part of #81). Expand covers the field; collapse returns to side panel.

### Requirement: API balancing — MVP-simple orchestrator

MVP search orchestrator SHALL be **parallel calls + de-dupe by stable identifier**. Real balancing (rate-limits, weighting, fallback) is deferred to the external-integration research mission.

Balancing multiple source APIs (Wikipedia / Google Books / OpenAlex / Discogs / TMDB / MusicBrainz + image sources) to produce a good search dynamic remains an open architectural problem; the research mission owes the balanced design.

*Updated 2026-04-24 per D-241.*
